import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  // `output: standalone` produces a self-contained server bundle used by the
  // Dockerfile. Opt in via env so normal builds (vercel / next start) are
  // completely unaffected.
  ...(process.env.DOCKER_BUILD === "1" ? { output: "standalone" } : {}),
  images: {
    remotePatterns: [
      {
        protocol: "https",
        hostname: "images.pexels.com",
      },
    ],
  },
};

export default nextConfig;
