# We Cares — Premium Herbal Wellness Storefront

**Nature's Care, With You**

A Pakistani herbal wellness e-commerce store built with Next.js (App Router),
PostgreSQL and Drizzle ORM. Dark forest green + warm cream + gold design,
mobile-first, with WhatsApp ordering throughout.

---

## Adding your product photos

Drop your 3 real product photos into `public/images/products/` with these exact
filenames:

| File | Product |
| --- | --- |
| `majoon-booster.jpg` | We Cares Majoon Booster |
| `joint-pain-relief-oil.jpg` | We Cares The Original Joint Pain Relief Oil |
| `the-original-8-men-oil.jpg` | We Cares The Original 8" Men Oil |

Square images work best (e.g. 1000 × 1000). Until a file exists, that product
automatically shows a dark-green botanical placeholder with the product name, so
nothing looks broken. No code changes are needed — just drop the file in.

---

## The catalogue

| Product | Net weight | Original | Sale |
| --- | --- | --- | --- |
| We Cares Majoon Booster | 250g | Rs. 7,500 | **Rs. 6,500** |
| We Cares The Original Joint Pain Relief Oil | 15ml | Rs. 1,999 | **Rs. 1,499** |
| We Cares The Original 8" Men Oil | 15ml | Rs. 2,999 | **Rs. 1,999** |

All amounts are stored in the database as integer **paisa** (Rs. 6,500 →
`650000`) and rendered as `Rs. 6,500` by `formatPkr()` in `src/lib/format.ts`.

**Prices are never trusted from the browser.** `POST /api/orders` re-reads every
price from the `products` table and recalculates subtotal, delivery and total
before writing the order.

### Delivery & payment

- Standard (2–4 working days): Rs. 250 — **free** on orders over Rs. 5,000
- Express (1–2 working days): Rs. 500
- Cash on Delivery (default) or Bank Transfer
- Prices are shown as inclusive of all applicable taxes (no tax line added)

### WhatsApp ordering

| Constant | Value |
| --- | --- |
| `WHATSAPP_NUMBER_RAW` | `03037307113` |
| `WHATSAPP_NUMBER_INTL` | `923037307113` (used for `wa.me` links) |
| `WHATSAPP_NUMBER_DISPLAY` | `0303 730 7113` |

Change these once in `src/lib/whatsapp.ts` and every button, the sticky float,
the footer and the cart all update.

Pakistani mobile numbers are validated with `/^03\d{9}$/` (11 digits) and both
`03001234567` and `923001234567` formats are accepted and normalised.

---

## Compliance: no medical claims

Product copy is deliberately neutral and defers to the pack label. Every product
carries a `disclaimer` field rendered on its detail page stating that the item is
a herbal preparation, is **not** intended to diagnose, treat, cure or prevent any
disease, and that a qualified healthcare professional should be consulted before
use.

When adding new products in `src/data/catalog.json`, keep descriptions to
verifiable facts: what it is, net weight, how it is prepared, how to use it, and
storage. Avoid efficacy claims, "guaranteed results", or disease references.

---

## Editing products

1. Edit `src/data/catalog.json`
2. Reseed (⚠️ `force=1` truncates products and collections):

   ```bash
   curl -X POST "http://localhost:3000/api/seed?force=1&token=$SEED_SECRET"
   ```

   Locally, with no `SEED_SECRET` set, the token is not required.

The store also self-seeds automatically on the first request if the `products`
table is empty.

---

## Admin panel — manage your store

Sign in at **`/admin`** to run the shop from a browser. No code or file editing
required.

```
Username:  value of ADMIN_USERNAME   (default: admin)
Password:  value of ADMIN_PASSWORD   (set in .env)
```

**Change these before going live.** If `ADMIN_PASSWORD` is empty or missing,
login is refused rather than left open. Sessions are signed HTTP-only cookies
valid for 12 hours, and every admin page plus all `/api/admin/*` routes are
checked server-side.

### What you can do

| Page | Actions |
| --- | --- |
| **Dashboard** `/admin` | Order count, total revenue, pending orders, product count, recent orders, low-stock alerts (≤ 10 units) |
| **Products** `/admin/products` | Search, add, edit, hide/show, delete. Hidden products stay in admin but vanish from the storefront. |
| **Edit product** `/admin/products/[id]` | Name, descriptions, usage, ingredients, highlights, prices, net weight, suitability, stock, display order, badges, and image upload |
| **Orders** `/admin/orders` | Every order with customer name, mobile, full address, city, items, total and notes. Filter by status, set status (pending → confirmed → dispatched → delivered, or cancelled), and one-tap WhatsApp or call the customer. |

### Changing a price

Open the product, type the new **Sale price** and optionally an **Original price**.
A live preview shows the crossed-out price and the "Save X%" badge as you type.

Prices are entered in **rupees** in the admin panel — the app stores them as
paisa internally, so `6500` becomes `650000`. The original price must be higher
than the sale price or the save is rejected.

### Uploading a product image

Open the product → **Product image** → **Upload image**. Files are validated
(JPG, PNG, WebP or AVIF, max 8 MB) and written to `public/images/products/`. The
stored filename defaults to the product's slug, so uploads stay tidy. You can
also paste a path manually instead of uploading.

### Deleting vs hiding

- **Hide** — reversible. The product disappears from the storefront immediately
  but stays in your admin list with its data intact. Best for out-of-stock items.
- **Delete** — permanent, with a confirmation prompt. Prefer **Hide** unless you
  are certain.

### Receiving orders

When a customer checks out, the order is written to the database and appears in
`/admin/orders` — refresh the page to see new ones. Each row shows the customer's
name, mobile, city, payment method and total; expand it for the full address,
items and any delivery notes.

WhatsApp and Call buttons open a chat or dialler with the customer's own number,
so you can confirm the order in one tap.

> **Tip:** orders do not currently push a notification to you. Keep
> `/admin/orders` open, or ask me to add email/WhatsApp alerts on new orders.

---

## Local development

```bash
npm install
cp .env.example .env      # set DATABASE_URL
npx drizzle-kit push      # create tables
npm run dev               # http://localhost:3000
```

```bash
npm run build       # production build
npm run typecheck   # tsc --noEmit
npm run start       # serve the production build
```

---

## Environment variables

| Key | Required | Purpose |
| --- | --- | --- |
| `DATABASE_URL` | ✅ | Postgres connection string |
| `SEED_SECRET` | recommended | Protects `POST /api/seed` |
| `NEXT_PUBLIC_SITE_URL` | optional | Canonical/OG URLs, sitemap |

---

## Publishing

### Vercel + managed Postgres (recommended)

1. Push to GitHub
2. Create a Postgres DB (Neon / Supabase / Vercel Postgres) and copy the pooled URL
3. Import the repo at [vercel.com/new](https://vercel.com/new)
4. Set `DATABASE_URL` (+ `SEED_SECRET`, `NEXT_PUBLIC_SITE_URL`)
5. Create tables: `DATABASE_URL="postgres://..." npx drizzle-kit push`
6. Seed: `curl -X POST "https://yourdomain.com/api/seed?token=$SEED_SECRET"`

### Docker

```bash
docker build -t we-cares .
docker run -p 3000:3000 -e DATABASE_URL="postgres://..." we-cares
```

`output: "standalone"` only activates when `DOCKER_BUILD=1` (set inside the
Dockerfile), so plain `npm run build` and `npm start` are unaffected. Health
check path: `/api/health`.

---

## Routes

| Route | Description |
| --- | --- |
| `/` | Hero, brand intro, featured products, why choose us, values, how to order, WhatsApp CTA |
| `/shop` | All products with filters and sorting |
| `/collections` · `/collections/[slug]` | Collection index and landing pages |
| `/products/[slug]` | Gallery, prices, usage, ingredients, disclaimer, buy box |
| `/checkout` | 3-step checkout with PKR and COD |
| `/orders/[orderNumber]` | Order confirmation read back from the database |
| `/api/health` | Database connectivity probe |

## Structure

| Path | Role |
| --- | --- |
| `src/db/schema.ts` | `collections`, `products`, `orders` (paisa integer amounts) |
| `src/data/catalog.json` | Source of truth for products and collections |
| `src/db/seed.ts` | Race-safe seeder (Postgres advisory lock) |
| `src/lib/format.ts` | PKR formatting, delivery math, mobile validation |
| `src/lib/whatsapp.ts` | WhatsApp number and deep-link message builders |
| `src/components/cart/*` | `localStorage`-persistent cart + slide-out drawer |
| `src/components/ProductImage.tsx` | Product photo with botanical fallback |
