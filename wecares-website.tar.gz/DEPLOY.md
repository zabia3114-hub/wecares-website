# Deploying We Cares to Vercel (free)

Gets you a live URL like **`https://wecares-store.vercel.app`** at no cost,
with no domain purchase.

Total time: about 15 minutes.

---

## Step 1 — Push the code to GitHub

```bash
git init
git add -A
git commit -m "We Cares ecommerce store"
git branch -M main

# Create an empty repo named wecares-store on github.com first, then:
git remote add origin https://github.com/<your-username>/wecares-store.git
git push -u origin main
```

> Make sure `.env` is **not** committed. It is already listed in `.gitignore`
> — verify with `git status` (`.env` should not appear).

---

## Step 2 — Create a free Postgres database

Pick one, all have free tiers:

| Provider | Where to copy the connection string |
| --- | --- |
| **Neon** (recommended) | neon.tech → project → Connection string → **Pooled connection** |
| Supabase | supabase.com → Project settings → Database → Connection string → URI |
| Vercel Postgres | vercel.com → Storage → Create Database → Postgres |

The string looks like:

```
postgresql://user:password@ep-xxx.aws.neon.tech/neondb?sslmode=require
```

Keep `?sslmode=require` on the end.

---

## Step 3 — Import the project into Vercel

1. Go to **vercel.com/new**
2. Authorise GitHub and select the **wecares-store** repository
3. **Important:** on the configure screen set the **Project Name** to exactly
   `wecares-store` — this is what produces `wecares-store.vercel.app`
4. Do **not** click Deploy yet — add the environment variables first (Step 4)

---

## Step 4 — Add environment variables

Vercel → Project → **Settings** → **Environment Variables**.
Add all of these (tick Production, Preview and Development):

| Name | Value | Required |
| --- | --- | --- |
| `DATABASE_URL` | your connection string from Step 2 | ✅ yes |
| `ADMIN_USERNAME` | `admin` (or whatever you prefer) | ✅ yes |
| `ADMIN_PASSWORD` | a long random password — **do not** reuse `wecares123` | ✅ yes |
| `NEXT_PUBLIC_SITE_URL` | `https://wecares-store.vercel.app` | recommended |
| `SEED_SECRET` | any long random string | recommended |
| `RESEND_API_KEY` | from resend.com (optional email alerts) | optional |
| `ALERT_EMAIL_TO` | your email address | optional |

Save, then go back to **Deployments** and click **Deploy**.

---

## Step 5 — Create the database tables

Run this once from your own machine, pointing at your production database:

```bash
npm install
DATABASE_URL="your-production-connection-string" npx drizzle-kit push --config=drizzle.prod.config.ts
```

This creates the `products`, `collections`, `orders`, `reviews`,
`notifications`, `settings` and `admin_users` tables.

The store also self-seeds the 3 products and sample reviews on the first page
load if the tables are empty, so no manual seeding is required.

---

## Step 6 — Verify

Open your URL and check:

| Check | Where |
| --- | --- |
| Storefront loads | `https://wecares-store.vercel.app` |
| Products show | `/shop` |
| Product page opens | `/products/majoon-booster` |
| Checkout reachable | `/checkout` |
| Admin login page | `/admin/login` |
| Admin dashboard (after login) | `/admin` |
| Health probe | `/api/health` → `{"ok":true}` |

Then do one real test order and confirm it appears in
**Admin → Orders**.

---

## Troubleshooting

**Build fails with `DATABASE_URL is not set`**
You deployed before adding the environment variable. Add it (Step 4), then
Deployments → ⋯ → **Redeploy**.

**Pages load but show no products**
The tables do not exist yet. Run Step 5.

**Cannot log in to the admin panel**
`ADMIN_PASSWORD` on Vercel must match what you type. Remember it is the
**environment variable** value, not `wecares123`, once you have changed it.
If the default-credentials warning banner is showing, you are still on
`wecares123`.

**504 / connection timeouts**
Some providers need the *pooled* connection string for serverless. With Neon,
use the **Pooled** connection string for `DATABASE_URL`.

**Emails not arriving**
`RESEND_API_KEY` or `ALERT_EMAIL_TO` is empty, or the domain is not verified at
resend.com. The in-app bell works regardless.

---

## What is already configured for Vercel

- Lazy Postgres pool — the build no longer fails when `DATABASE_URL` is absent
  during static generation, and TLS is enabled automatically for managed
  providers (`sslmode=require`)
- All money and stock logic runs server-side, so browser tampering cannot
  change totals
- Admin pages and every `/api/admin/*` route are verified server-side
- `robots.txt` blocks `/admin`, `/checkout`, `/orders/` and `/api/`
- Sitemap is generated dynamically from the database
- Responsive layouts are untouched; nothing was removed or redesigned

---

## After deploying

1. Change `ADMIN_PASSWORD` before telling anyone about the store
2. Add your real product photos to `public/images/products/`
3. Place one real order end to end and confirm it appears in the admin panel
