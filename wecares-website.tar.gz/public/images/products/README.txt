DROP YOUR 3 PRODUCT PHOTOS HERE, using these exact filenames:

  majoon-booster.jpg            -> We Cares Majoon Booster
  joint-pain-relief-oil.jpg     -> We Cares The Original Joint Pain Relief Oil
  the-original-8-men-oil.jpg    -> We Cares The Original 8" Men Oil

Square images work best (e.g. 1000 x 1000 px). JPG or PNG.

Until a file is present, that product card automatically shows a dark-green
botanical placeholder with the product name, so the site never looks broken.
