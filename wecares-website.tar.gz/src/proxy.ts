import { NextResponse, type NextRequest } from "next/server";

const COOKIE_NAME = "wecares_admin";

/**
 * Gate the whole /admin area. Page-level checks still run (defence in depth),
 * but this redirects unauthenticated visitors to the login screen instead of
 * flashing an error.
 */
export default function proxy(request: NextRequest) {
  const { pathname } = request.nextUrl;

  // Always let the login page and the auth API through.
  if (pathname === "/admin/login") return NextResponse.next();
  if (pathname.startsWith("/api/admin/auth")) return NextResponse.next();

  const token = request.cookies.get(COOKIE_NAME)?.value;
  if (token && token.split(".").length === 3) return NextResponse.next();

  const loginUrl = new URL("/admin/login", request.url);
  loginUrl.searchParams.set("next", pathname);
  return NextResponse.redirect(loginUrl);
}

export const config = {
  matcher: ["/admin/:path*"],
};
