/**
 * We Cares money helpers.
 * All amounts are stored and passed around as integer minor units (paisa).
 * Rs. 6,500.00 => 650000
 */

export function cn(...classes: Array<string | false | null | undefined>) {
  return classes.filter(Boolean).join(" ");
}

export function formatPkr(paisa: number) {
  const rupees = Math.round(paisa / 100);
  return `Rs. ${new Intl.NumberFormat("en-PK").format(rupees)}`;
}

export function formatDate(value: Date | string) {
  const date = typeof value === "string" ? new Date(value) : value;
  return new Intl.DateTimeFormat("en-PK", {
    day: "numeric",
    month: "short",
    year: "numeric",
  }).format(date);
}

export function discountPercent(price: number, compareAt?: number | null) {
  if (!compareAt || compareAt <= price) return 0;
  return Math.round(((compareAt - price) / compareAt) * 100);
}

/** Defaults; the real values come from admin settings and are passed in. */
export const DELIVERY_STANDARD_PAISA = 25000; // Rs. 250
export const DELIVERY_EXPRESS_PAISA = 50000; // Rs. 500
export const FREE_DELIVERY_THRESHOLD_PAISA = 500000; // Rs. 5,000

export type ShippingMethod = "standard" | "express";

export type ShippingRates = {
  standardPaisa: number;
  expressPaisa: number;
  freeOverPaisa: number;
};

/**
 * Calculates the shipping charge. Rates come from admin settings so the owner
 * can change them without a code change; the defaults match the originals.
 */
export function computeTotals(
  subtotalPaisa: number,
  shippingMethod: ShippingMethod = "standard",
  rates?: Partial<ShippingRates>,
) {
  const standardPaisa = rates?.standardPaisa ?? DELIVERY_STANDARD_PAISA;
  const expressPaisa = rates?.expressPaisa ?? DELIVERY_EXPRESS_PAISA;
  const freeOverPaisa = rates?.freeOverPaisa ?? FREE_DELIVERY_THRESHOLD_PAISA;

  let shippingPaisa = shippingMethod === "express" ? expressPaisa : standardPaisa;

  // Free standard delivery on larger orders (0 disables the threshold).
  if (
    shippingMethod === "standard" &&
    freeOverPaisa > 0 &&
    subtotalPaisa >= freeOverPaisa
  ) {
    shippingPaisa = 0;
  }

  // Retail prices are quoted inclusive of all applicable taxes.
  return {
    shippingPaisa,
    totalPaisa: subtotalPaisa + shippingPaisa,
  };
}

/** Normalises a Pakistani mobile number to 03XXXXXXXXX for storage/display. */
export function normalizePkMobile(input: string) {
  const digits = input.replace(/\D/g, "");
  // 923031234567 -> 03031234567
  if (digits.startsWith("92") && digits.length === 12) return `0${digits.slice(2)}`;
  return digits;
}

export function isValidPkMobile(input: string) {
  return /^03\d{9}$/.test(normalizePkMobile(input));
}
