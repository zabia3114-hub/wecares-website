import { db } from "@/db";
import { seedDatabase } from "@/db/seed";

let seedPromise: Promise<unknown> | null = null;

/**
 * Single shared lazy-seed promise. Guarded by a Postgres advisory lock inside
 * `seedDatabase`, so concurrent serverless cold starts cannot duplicate data.
 */
export function ensureSeeded() {
  if (!seedPromise) {
    seedPromise = seedDatabase().catch((error) => {
      seedPromise = null;
      throw error;
    });
  }
  return seedPromise;
}
