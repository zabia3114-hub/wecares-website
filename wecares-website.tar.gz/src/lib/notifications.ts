import { desc, eq, sql } from "drizzle-orm";
import { db } from "@/db";
import { notifications } from "@/db/schema";
import { formatPkr } from "@/lib/format";

export type OrderAlertItem = {
  name: string;
  quantity: number;
};

/**
 * Records an in-app alert for the store owner whenever an order is placed.
 * Runs after the order transaction commits, so a notification failure can
 * never roll back a real order.
 */
export async function notifyNewOrder(input: {
  orderNumber: string;
  customerName: string;
  city: string;
  mobile: string;
  totalPaisa: number;
  paymentMethod: string;
  items: OrderAlertItem[];
}) {
  const itemList = input.items
    .map((item) => `${item.name} × ${item.quantity}`)
    .join(", ");

  try {
    await db.insert(notifications).values({
      type: "new-order",
      title: `New order ${input.orderNumber} — ${formatPkr(input.totalPaisa)}`,
      body: `${input.customerName} (${input.city}) · ${itemList} · ${
        input.paymentMethod === "bank-transfer" ? "Bank Transfer" : "Cash on Delivery"
      }`,
      orderNumber: input.orderNumber,
      isRead: false,
    });
  } catch (error) {
    // Non-fatal: the order is already saved.
    console.error("notifyNewOrder failed", error);
  }

  // Optional email alert — only runs when an API key is configured.
  await sendEmailAlert(input);
}

export type UnreadSummary = {
  unreadCount: number;
  latest: Array<{
    id: number;
    title: string;
    body: string;
    orderNumber: string | null;
    createdAt: string;
  }>;
};

/** Unread alerts for the admin bell. */
export async function getUnreadNotifications(
  limit = 10,
): Promise<UnreadSummary> {
  try {
    const [countRow] = await db
      .select({ total: sql<number>`count(*)::int` })
      .from(notifications)
      .where(eq(notifications.isRead, false));

    const latest = await db
      .select({
        id: notifications.id,
        title: notifications.title,
        body: notifications.body,
        orderNumber: notifications.orderNumber,
        createdAt: notifications.createdAt,
      })
      .from(notifications)
      .orderBy(desc(notifications.createdAt), desc(notifications.id))
      .limit(limit);

    return {
      unreadCount: countRow?.total ?? 0,
      latest: latest.map((row) => ({
        ...row,
        createdAt: row.createdAt.toISOString(),
      })),
    };
  } catch (error) {
    console.error("getUnreadNotifications failed", error);
    return { unreadCount: 0, latest: [] };
  }
}

export async function markNotificationsRead(ids?: number[]) {
  try {
    if (ids && ids.length > 0) {
      await db
        .update(notifications)
        .set({ isRead: true })
        .where(sql`${notifications.id} = any(${ids})`);
    } else {
      await db.update(notifications).set({ isRead: true });
    }
    return true;
  } catch (error) {
    console.error("markNotificationsRead failed", error);
    return false;
  }
}

/* ------------------------------------------------------------------ */
/* Optional email alert                                                */
/* ------------------------------------------------------------------ */

/**
 * Sends an order alert email through Resend when RESEND_API_KEY and
 * ALERT_EMAIL_TO are configured. Silently skips otherwise, so the store keeps
 * working with no third-party setup.
 */
async function sendEmailAlert(input: {
  orderNumber: string;
  customerName: string;
  city: string;
  mobile: string;
  totalPaisa: number;
  paymentMethod: string;
  items: OrderAlertItem[];
}) {
  const apiKey = process.env.RESEND_API_KEY?.trim();
  const to = process.env.ALERT_EMAIL_TO?.trim();
  const from =
    process.env.ALERT_EMAIL_FROM?.trim() || "orders@resend.dev";

  if (!apiKey || !to) return; // Not configured — skip quietly.

  const itemList = input.items
    .map((item) => `• ${item.name} × ${item.quantity}`)
    .join("\n");

  try {
    const response = await fetch("https://api.resend.com/emails", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${apiKey}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        from,
        to: [to],
        subject: `New order ${input.orderNumber} — ${formatPkr(input.totalPaisa)}`,
        text: [
          "New order received on your We Cares store.",
          "",
          `Order: ${input.orderNumber}`,
          `Customer: ${input.customerName}`,
          `Mobile: ${input.mobile}`,
          `City: ${input.city}`,
          `Payment: ${
            input.paymentMethod === "bank-transfer"
              ? "Bank Transfer"
              : "Cash on Delivery"
          }`,
          `Total: ${formatPkr(input.totalPaisa)}`,
          "",
          "Items:",
          itemList,
          "",
          "Open the admin panel to confirm this order.",
        ].join("\n"),
      }),
    });

    if (!response.ok) {
      console.error("order email failed", await response.text());
    }
  } catch (error) {
    console.error("order email error", error);
  }
}
