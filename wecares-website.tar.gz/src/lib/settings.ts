import { sql } from "drizzle-orm";
import { db } from "@/db";
import { settings } from "@/db/schema";
import { SETTING_DEFAULTS, type SiteSettings } from "@/lib/settings-types";

export {
  THEMES,
  FONT_CHOICES,
  getTheme,
  fontStack,
  buildFontHref,
  DEFAULT_THEME_ID,
} from "@/lib/theme-presets";
export type { ThemePalette, FontChoice } from "@/lib/theme-presets";
export type { SiteSettings };
export { SETTING_DEFAULTS };

/** All editable keys, with the type used when persisting. */
const BOOLEAN_KEYS = new Set(["codEnabled", "bankTransferEnabled"]);
const NUMBER_KEYS = new Set([
  "shippingStandardRupees",
  "shippingExpressRupees",
  "freeShippingOverRupees",
]);

/** Creates the settings table if it is missing (self-healing on fresh hosts). */
async function ensureSettingsTable() {
  await db.execute(sql`
    create table if not exists "settings" (
      "key" text primary key,
      "value" text not null default '',
      "updated_at" timestamp with time zone not null default now()
    )
  `);
}

/**
 * Reads every setting from the database, falling back to defaults.
 * Runs on the server only; no secret reaches the client.
 */
export async function getSiteSettings(): Promise<SiteSettings> {
  const resolved: SiteSettings = { ...SETTING_DEFAULTS };

  try {
    const rows = await db.select().from(settings);
    for (const row of rows) {
      const key = row.key as keyof SiteSettings;
      if (!(key in SETTING_DEFAULTS)) continue;

      const fallback = SETTING_DEFAULTS[key];
      if (BOOLEAN_KEYS.has(row.key)) {
        resolved[key] = (row.value === "true") as never;
      } else if (NUMBER_KEYS.has(row.key)) {
        const parsed = Number(row.value);
        resolved[key] = (Number.isFinite(parsed) ? parsed : fallback) as never;
      } else {
        resolved[key] = (row.value || fallback) as never;
      }
    }
  } catch (error) {
    // Missing table is common on a freshly provisioned database. Create it so
    // the very first save succeeds instead of reporting a vague failure.
    console.warn("settings read failed, creating table", error);
    try {
      await ensureSettingsTable();
    } catch (createError) {
      console.error("could not create settings table", createError);
    }
  }

  return resolved;
}

/** Normalises one setting value for storage. */
function toStorageValue(key: string, rawValue: unknown) {
  if (BOOLEAN_KEYS.has(key)) {
    return rawValue === true || rawValue === "true" ? "true" : "false";
  }
  if (NUMBER_KEYS.has(key)) {
    const parsed = Number(rawValue);
    return Number.isFinite(parsed) && parsed >= 0
      ? String(Math.round(parsed))
      : "0";
  }
  return String(rawValue ?? "").slice(0, 2000);
}

/** Persists settings in a single transaction. Throws with a clear message. */
export async function saveSiteSettings(
  input: Record<string, unknown>,
): Promise<{ saved: number }> {
  const entries = Object.entries(input).filter(
    ([key]) => key in SETTING_DEFAULTS,
  );

  if (entries.length === 0) {
    throw new Error("No recognised settings were provided.");
  }

  try {
    await db.transaction(async (tx) => {
      for (const [key, rawValue] of entries) {
        const value = toStorageValue(key, rawValue);
        await tx
          .insert(settings)
          .values({ key, value })
          .onConflictDoUpdate({
            target: settings.key,
            set: { value, updatedAt: new Date() },
          });
      }
    });
  } catch (error) {
    // Retry once after ensuring the table exists — covers a fresh database.
    console.warn("settings save failed, ensuring table then retrying", error);
    await ensureSettingsTable();

    await db.transaction(async (tx) => {
      for (const [key, rawValue] of entries) {
        const value = toStorageValue(key, rawValue);
        await tx
          .insert(settings)
          .values({ key, value })
          .onConflictDoUpdate({
            target: settings.key,
            set: { value, updatedAt: new Date() },
          });
      }
    });
  }

  return { saved: entries.length };
}
