import { and, asc, desc, eq, gte, ilike, inArray, isNull, lte, or, sql } from "drizzle-orm";
import { db } from "@/db";
import { collections, orders, products } from "@/db/schema";
import type { Collection, Order, OrderLineItem, Product } from "@/db/schema";
import { ensureSeeded } from "@/lib/seed-init";
import { getSiteSettings } from "@/lib/settings";
import { notifyNewOrder } from "@/lib/notifications";
import { computeTotals, type ShippingMethod } from "@/lib/format";

export type ProductListItem = Product;

export type SortKey = "featured" | "price-asc" | "price-desc" | "newest";

export type ShopFilters = {
  collection?: string;
  /** Legacy free-text label filter. */
  category?: string;
  /** Editable category id filter. */
  categoryId?: number;
  /** Slug used to catch legacy unassigned rows. */
  categorySlug?: string;
  search?: string;
  sort?: SortKey;
  maxPrice?: number;
  minPrice?: number;
  limit?: number;
  /** Admin-only: include products hidden from the storefront. */
  includeInactive?: boolean;
};

export type CollectionWithCount = Collection & { productCount: number };

export async function getProducts(
  filters: ShopFilters = {},
): Promise<ProductListItem[]> {
  await ensureSeeded();

  const conditions = [];
  if (filters.collection) {
    conditions.push(eq(products.collectionSlug, filters.collection));
  }
  if (filters.category) {
    conditions.push(eq(products.categoryLabel, filters.category));
  }
  if (typeof filters.categoryId === "number") {
    conditions.push(
      or(
        eq(products.categoryId, filters.categoryId),
        // Legacy rows that were never assigned a category id still resolve
        // against a category whose slug matches their collection.
        and(
          isNull(products.categoryId),
          eq(products.collectionSlug, filters.categorySlug ?? ""),
        ),
      ),
    );
  }
  if (typeof filters.minPrice === "number") {
    conditions.push(gte(products.pricePaisa, filters.minPrice));
  }
  if (typeof filters.maxPrice === "number") {
    conditions.push(lte(products.pricePaisa, filters.maxPrice));
  }
  if (filters.search) {
    const term = `%${filters.search}%`;
    conditions.push(
      or(
        ilike(products.name, term),
        ilike(products.subtitle, term),
        ilike(products.description, term),
        ilike(products.categoryLabel, term),
      ),
    );
  }

  // Storefront never shows inactive products. Admin passes includeInactive.
  if (!filters.includeInactive) {
    conditions.push(eq(products.isActive, true));
  }

  const order = (() => {
    switch (filters.sort) {
      case "price-asc":
        return [asc(products.pricePaisa), asc(products.sortOrder)];
      case "price-desc":
        return [desc(products.pricePaisa), asc(products.sortOrder)];
      case "newest":
        return [desc(products.id)];
      default:
        return [asc(products.sortOrder)];
    }
  })();

  let query = db
    .select()
    .from(products)
    .$dynamic()
    .where(conditions.length ? and(...conditions) : undefined)
    .orderBy(...order);

  if (filters.limit) {
    query = query.limit(filters.limit);
  }

  return query;
}

export async function getProductBySlug(slug: string) {
  await ensureSeeded();
  const rows = await db
    .select()
    .from(products)
    .where(eq(products.slug, slug))
    .limit(1);
  return rows[0] ?? null;
}

export async function getCollections(): Promise<CollectionWithCount[]> {
  await ensureSeeded();
  const rows = await db
    .select({
      collection: collections,
      productCount: sql<number>`count(${products.id})::int`,
    })
    .from(collections)
    .leftJoin(products, eq(products.collectionSlug, collections.slug))
    .groupBy(collections.id)
    .orderBy(asc(collections.sortOrder));

  return rows.map((row) => ({ ...row.collection, productCount: row.productCount }));
}

export async function getCollectionBySlug(slug: string) {
  await ensureSeeded();
  const rows = await db
    .select()
    .from(collections)
    .where(eq(collections.slug, slug))
    .limit(1);
  return rows[0] ?? null;
}

export async function getFacets() {
  await ensureSeeded();
  const rows = await db
    .select({
      categoryLabel: products.categoryLabel,
      pricePaisa: products.pricePaisa,
    })
    .from(products);

  const categories = new Map<string, number>();
  let maxPrice = 0;
  for (const row of rows) {
    categories.set(row.categoryLabel, (categories.get(row.categoryLabel) ?? 0) + 1);
    maxPrice = Math.max(maxPrice, row.pricePaisa);
  }

  return {
    categories: [...categories.entries()]
      .map(([value, count]) => ({ value, count }))
      .sort((a, b) => a.value.localeCompare(b.value)),
    maxPrice: Math.ceil(maxPrice / 50000) * 50000,
  };
}

export type CreateOrderInput = {
  customerName: string;
  mobile: string;
  address: string;
  city: string;
  province?: string;
  orderDetails?: string;
  paymentMethod: "cod" | "bank-transfer";
  shippingMethod: ShippingMethod;
  items: Array<{ slug: string; quantity: number }>;
  subtotalPaisa: number;
  shippingPaisa: number;
  totalPaisa: number;
};

function generateOrderNumber() {
  const stamp = Date.now().toString(36).toUpperCase().slice(-5);
  const random = Math.random().toString(36).toUpperCase().slice(2, 5);
  return `WC-${stamp}${random}`;
}

/** A single quantity is the smallest order we accept; 20 caps abuse. */
export const MIN_ORDER_QUANTITY = 1;
export const MAX_ORDER_QUANTITY = 20;

export type CreateOrderResult =
  | { ok: true; order: Order }
  | { ok: false; error: string; slug?: string };

export async function createOrder(
  input: CreateOrderInput,
): Promise<CreateOrderResult> {
  await ensureSeeded();

  // Reject nonsense quantities outright rather than silently "correcting" them
  // into a charge the customer never asked for.
  for (const item of input.items) {
    const quantity = Math.round(item.quantity);
    if (
      !Number.isFinite(quantity) ||
      quantity < MIN_ORDER_QUANTITY ||
      quantity > MAX_ORDER_QUANTITY
    ) {
      return {
        ok: false,
        error: `Invalid quantity for an item. Each product must be between ${MIN_ORDER_QUANTITY} and ${MAX_ORDER_QUANTITY}.`,
        slug: item.slug,
      };
    }
  }

  const slugs = [...new Set(input.items.map((item) => item.slug))];

  try {
    // Everything below — availability check, stock decrement and order insert —
    // runs inside one transaction so two shoppers can never buy the last unit.
    return await db.transaction(async (tx) => {
      const catalogue = await tx
        .select()
        .from(products)
        .where(inArray(products.slug, slugs));

      const bySlug = new Map(catalogue.map((product) => [product.slug, product]));

      const items: OrderLineItem[] = [];
      for (const item of input.items) {
        const product = bySlug.get(item.slug);
        if (!product) {
          return { ok: false, error: "Some items are no longer available." };
        }
        // Hidden products must not be orderable even if a stale cart submits them.
        if (!product.isActive) {
          return {
            ok: false,
            error: `${product.name} is no longer available.`,
            slug: product.slug,
          };
        }
        if (product.stock < item.quantity) {
          return {
            ok: false,
            error:
              product.stock === 0
                ? `${product.name} has just sold out.`
                : `Only ${product.stock} left of ${product.name}. Please adjust the quantity.`,
            slug: product.slug,
          };
        }
        items.push({
          productId: product.id,
          slug: product.slug,
          name: product.name,
          image: product.images[0] ?? "",
          unitPricePaisa: product.pricePaisa,
          quantity: item.quantity,
        });
      }

      if (items.length === 0) {
        return { ok: false, error: "Your cart is empty." };
      }

      // Recompute the money from the database, never from the client.
      const subtotalPaisa = items.reduce(
        (total, item) => total + item.unitPricePaisa * item.quantity,
        0,
      );
      // Shipping rates come from admin settings, not from the client.
      const siteSettings = await getSiteSettings();
      const { shippingPaisa, totalPaisa } = computeTotals(subtotalPaisa, input.shippingMethod, {
        standardPaisa: siteSettings.shippingStandardRupees * 100,
        expressPaisa: siteSettings.shippingExpressRupees * 100,
        freeOverPaisa: siteSettings.freeShippingOverRupees * 100,
      });

      let orderNumber = generateOrderNumber();
      let inserted: Order | undefined;

      // Retry the insert if a duplicate order reference is somehow generated.
      for (let attempt = 0; attempt < 4 && !inserted; attempt += 1) {
        try {
          const rows = await tx
            .insert(orders)
            .values({
              orderNumber,
              customerName: input.customerName,
              mobile: input.mobile,
              address: input.address,
              city: input.city,
              province: input.province ?? "",
              orderDetails: input.orderDetails ?? "",
              paymentMethod: input.paymentMethod,
              shippingMethod: input.shippingMethod,
              items,
              subtotalPaisa,
              shippingPaisa,
              totalPaisa,
              status: "new",
            })
            .returning();
          inserted = rows[0];
        } catch (error) {
          const message = error instanceof Error ? error.message : "";
          if (!message.includes("orders_order_number_key")) throw error;
          orderNumber = generateOrderNumber();
        }
      }

      if (!inserted) {
        return { ok: false, error: "Could not create your order." };
      }

      // Commit the stock reduction now that the order is definitely saved.
      for (const item of items) {
        const updated = await tx
          .update(products)
          .set({ stock: sql`greatest(0, ${products.stock} - ${item.quantity})` })
          .where(
            and(
              eq(products.id, item.productId),
              gte(products.stock, item.quantity),
            ),
          )
          .returning({ id: products.id });

        // If the row did not update, stock moved underneath us — roll back.
        if (updated.length === 0) {
          return {
            ok: false,
            error: `${item.name} has just sold out. Please review your cart.`,
            slug: item.slug,
          };
        }
      }

      // Alert the store owner. Deliberately outside the order transaction's
      // critical path above: the order is already saved at this point.
      await notifyNewOrder({
        orderNumber: inserted.orderNumber,
        customerName: inserted.customerName,
        city: inserted.city,
        mobile: inserted.mobile,
        totalPaisa: inserted.totalPaisa,
        paymentMethod: inserted.paymentMethod,
        items: items.map((item) => ({
          name: item.name,
          quantity: item.quantity,
        })),
      });

      return { ok: true, order: inserted };
    });
  } catch (error) {
    console.error("createOrder failed", error);
    return {
      ok: false,
      error: "We could not place your order. Please try again.",
    };
  }
}

export async function getOrderByNumber(
  orderNumber: string,
): Promise<Order | null> {
  const rows = await db
    .select()
    .from(orders)
    .where(eq(orders.orderNumber, orderNumber.toUpperCase()))
    .limit(1);
  return rows[0] ?? null;
}

export { computeTotals };
