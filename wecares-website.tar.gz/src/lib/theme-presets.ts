import type { SiteSettings } from "./settings-types";

/* ------------------------------------------------------------------ */
/* Themes — 4 ready-made palettes                                      */
/* Each maps onto the CSS custom properties the UI is built from.      */
/* ------------------------------------------------------------------ */

export type ThemePalette = {
  id: string;
  name: string;
  description: string;
  /** Small preview swatches for the admin picker. */
  swatch: [string, string, string];
  vars: Record<string, string>;
};

export const THEMES: ThemePalette[] = [
  {
    id: "forest-gold",
    name: "Forest Gold",
    description: "Dark forest green, warm cream and gold. The original We Cares look.",
    swatch: ["#072018", "#c9a227", "#f8f5ee"],
    vars: {
      "--color-forest-950": "#04150f",
      "--color-forest-900": "#072018",
      "--color-forest-800": "#0b2e23",
      "--color-forest-700": "#14402f",
      "--color-forest-600": "#1b5440",
      "--color-moss": "#2e7355",
      "--color-gold": "#c9a227",
      "--color-gold-soft": "#dcc178",
      "--color-gold-deep": "#9a7a1c",
      "--color-cream": "#f8f5ee",
      "--color-cream-deep": "#efe9dd",
      "--color-sand": "#e2d9c6",
      "--color-ink": "#14251e",
      "--theme-header-from": "#04150f",
      "--theme-header-via": "rgba(4,21,15,0.92)",
      "--theme-header-to": "rgba(7,32,24,0.60)",
    },
  },
  {
    id: "onyx-yellow",
    name: "Onyx & Yellow",
    description: "Black with bright yellow accents on white. Bold, modern, high contrast.",
    swatch: ["#0a0a0a", "#ffd400", "#ffffff"],
    vars: {
      "--color-forest-950": "#000000",
      "--color-forest-900": "#0a0a0a",
      "--color-forest-800": "#161616",
      "--color-forest-700": "#242424",
      "--color-forest-600": "#333333",
      "--color-moss": "#4d4d4d",
      "--color-gold": "#ffd400",
      "--color-gold-soft": "#ffe75c",
      "--color-gold-deep": "#c9ad00",
      "--color-cream": "#ffffff",
      "--color-cream-deep": "#f4f4f4",
      "--color-sand": "#e4e4e4",
      "--color-ink": "#0a0a0a",
      "--theme-header-from": "#000000",
      "--theme-header-via": "rgba(0,0,0,0.93)",
      "--theme-header-to": "rgba(20,20,20,0.62)",
    },
  },
  {
    id: "ivory-platinum",
    name: "Ivory Platinum",
    description: "Clean white with near-black text and silver accents. Minimal luxury.",
    swatch: ["#ffffff", "#1c1c1c", "#b8b2a7"],
    vars: {
      "--color-forest-950": "#141414",
      "--color-forest-900": "#1c1c1c",
      "--color-forest-800": "#2a2a2a",
      "--color-forest-700": "#3a3a3a",
      "--color-forest-600": "#4a4a4a",
      "--color-moss": "#6b6459",
      "--color-gold": "#a8946a",
      "--color-gold-soft": "#c8b795",
      "--color-gold-deep": "#7d6c48",
      "--color-cream": "#ffffff",
      "--color-cream-deep": "#f6f4f1",
      "--color-sand": "#e8e4dd",
      "--color-ink": "#1c1c1c",
      "--theme-header-from": "#141414",
      "--theme-header-via": "rgba(20,20,20,0.92)",
      "--theme-header-to": "rgba(42,42,42,0.62)",
    },
  },
  {
    id: "maroon-gold",
    name: "Maroon Gold",
    description: "Deep burgundy with gold on cream. Rich, traditional, premium feel.",
    swatch: ["#3d0c1c", "#d4af37", "#fdf6ec"],
    vars: {
      "--color-forest-950": "#2a0711",
      "--color-forest-900": "#3d0c1c",
      "--color-forest-800": "#521527",
      "--color-forest-700": "#6b1d33",
      "--color-forest-600": "#84253f",
      "--color-moss": "#9c4a5e",
      "--color-gold": "#d4af37",
      "--color-gold-soft": "#e6cc7a",
      "--color-gold-deep": "#9c8224",
      "--color-cream": "#fdf6ec",
      "--color-cream-deep": "#f7ecdc",
      "--color-sand": "#e9dbc5",
      "--color-ink": "#2a1015",
      "--theme-header-from": "#2a0711",
      "--theme-header-via": "rgba(42,7,17,0.93)",
      "--theme-header-to": "rgba(61,12,28,0.62)",
    },
  },
];

export const DEFAULT_THEME_ID = "forest-gold";

export function getTheme(id: string | undefined | null): ThemePalette {
  return THEMES.find((theme) => theme.id === id) ?? THEMES[0];
}

/* ------------------------------------------------------------------ */
/* Fonts — selectable per segment                                      */
/* ------------------------------------------------------------------ */

export type FontChoice = { id: string; name: string; stack: string };

export const FONT_CHOICES: FontChoice[] = [
  { id: "cormorant", name: "Cormorant Garamond", stack: '"Cormorant Garamond", Georgia, serif' },
  { id: "playfair", name: "Playfair Display", stack: '"Playfair Display", Georgia, serif' },
  { id: "marcellus", name: "Marcellus", stack: '"Marcellus", Georgia, serif' },
  { id: "lora", name: "Lora", stack: '"Lora", Georgia, serif' },
  { id: "fraunces", name: "Fraunces", stack: '"Fraunces", Georgia, serif' },
  { id: "inter", name: "Inter", stack: '"Inter", system-ui, sans-serif' },
  { id: "manrope", name: "Manrope", stack: '"Manrope", system-ui, sans-serif' },
  { id: "poppins", name: "Poppins", stack: '"Poppins", system-ui, sans-serif' },
  { id: "jost", name: "Jost", stack: '"Jost", system-ui, sans-serif' },
  { id: "dmsans", name: "DM Sans", stack: '"DM Sans", system-ui, sans-serif' },
];

/** Google Fonts families that must be requested for a given selection. */


/* ------------------------------------------------------------------ */
/* Settings shape + accessors                                          */
/* ------------------------------------------------------------------ */


export type { SiteSettings };

export function fontStack(id: string | undefined | null, fallback: string) {
  return FONT_CHOICES.find((font) => font.id === id)?.stack ?? fallback;
}

/** Google Fonts families that must be requested for a given selection. */
const FONT_QUERY: Record<string, string> = {
  cormorant: "Cormorant+Garamond:ital,wght@0,400;0,500;0,600;0,700;1,400",
  playfair: "Playfair+Display:ital,wght@0,400;0,500;0,600;0,700;1,400",
  marcellus: "Marcellus",
  lora: "Lora:ital,wght@0,400;0,500;0,600;0,700;1,400",
  fraunces: "Fraunces:ital,opsz,wght@0,9..144,300..700;1,9..144,300..600",
  inter: "Inter:wght@300..700",
  manrope: "Manrope:wght@300..800",
  poppins: "Poppins:wght@300;400;500;600;700",
  jost: "Jost:wght@300..700",
  dmsans: "DM+Sans:wght@300..700",
};

/** Builds the Google Fonts <link> href covering every font in use. */
export function buildFontHref(ids: string[]) {
  const families = [...new Set(ids)]
    .map((id) => FONT_QUERY[id])
    .filter(Boolean)
    .map((query) => `family=${query}`)
    .join("&");

  if (!families) {
    return "https://fonts.googleapis.com/css2?family=Cormorant+Garamond:ital,wght@0,400;0,600;0,700&family=Inter:wght@300..700&display=swap";
  }

  return `https://fonts.googleapis.com/css2?${families}&display=swap`;
}
