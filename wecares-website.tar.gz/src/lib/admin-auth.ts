import { randomBytes, scryptSync, timingSafeEqual } from "node:crypto";
import { cookies } from "next/headers";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { adminUsers } from "@/db/schema";

const COOKIE_NAME = "wecares_admin";
const MAX_AGE_SECONDS = 60 * 60 * 12; // 12 hours

/**
 * PRODUCTION AUTH — credentials come ONLY from environment variables.
 *
 * There is deliberately NO built-in default password. If ADMIN_PASSWORD is not
 * configured, login is refused outright rather than silently allowing a
 * well-known credential. This is what removes the
 * "using built-in default credentials" security notice.
 *
 * Passwords are never stored or transmitted in plain text: the database holds a
 * salted scrypt hash, and the session cookie holds an HMAC-style signature.
 */

/* ------------------------------------------------------------------ */
/* Password hashing                                                    */
/* ------------------------------------------------------------------ */

/** Returns `scrypt$<saltHex>$<hashHex>`. */
export function hashPassword(password: string) {
  const salt = randomBytes(16);
  const derived = scryptSync(password, salt, 64);
  return `scrypt$${salt.toString("hex")}$${derived.toString("hex")}`;
}

/** Constant-time comparison of a plain password against a stored hash. */
export function verifyPassword(password: string, stored: string) {
  try {
    const [scheme, saltHex, hashHex] = stored.split("$");
    if (scheme !== "scrypt" || !saltHex || !hashHex) return false;
    const salt = Buffer.from(saltHex, "hex");
    const expected = Buffer.from(hashHex, "hex");
    const derived = scryptSync(password, salt, expected.length);
    if (derived.length !== expected.length) return false;
    return timingSafeEqual(derived, expected);
  } catch {
    return false;
  }
}

function safeEqual(a: string, b: string) {
  const bufA = Buffer.from(a);
  const bufB = Buffer.from(b);
  if (bufA.length !== bufB.length) return false;
  return timingSafeEqual(bufA, bufB);
}

/* ------------------------------------------------------------------ */
/* Configured credentials (env only — no defaults)                     */
/* ------------------------------------------------------------------ */

export function getConfiguredUsername() {
  return (process.env.ADMIN_USERNAME ?? "").trim();
}

export function getConfiguredPassword() {
  return (process.env.ADMIN_PASSWORD ?? "").trim();
}

/** True when ADMIN_PASSWORD is set in the environment. */
export function isAdminConfigured() {
  return getConfiguredPassword().length > 0;
}

/** True when the panel is missing ADMIN_PASSWORD (setup still required). */
export function usingDefaultAdminCredentials() {
  return !isAdminConfigured();
}

/* ------------------------------------------------------------------ */
/* Session tokens                                                      */
/* ------------------------------------------------------------------ */

function sessionSecret() {
  // Derived from the configured admin password, so changing the password
  // invalidates every existing session immediately.
  return `wecares-admin-session-${getConfiguredPassword()}`;
}

function sign(value: string) {
  return scryptSync(value, sessionSecret(), 32).toString("hex");
}

export type AdminSession = { username: string; issuedAt: number };

export function createSessionToken(username: string) {
  const issuedAt = Date.now();
  const payload = `${username}.${issuedAt}`;
  return `${payload}.${sign(payload)}`;
}

export function readSessionToken(token: string | undefined): AdminSession | null {
  if (!token) return null;
  const parts = token.split(".");
  if (parts.length !== 3) return null;
  const [username, issuedAtRaw, signature] = parts;
  if (!safeEqual(sign(`${username}.${issuedAtRaw}`), signature)) return null;

  const issuedAt = Number(issuedAtRaw);
  if (!Number.isFinite(issuedAt)) return null;
  if (Date.now() - issuedAt > MAX_AGE_SECONDS * 1000) return null;

  return { username, issuedAt };
}

/* ------------------------------------------------------------------ */
/* Credential verification (env first, then hashed DB row)             */
/* ------------------------------------------------------------------ */

export async function verifyCredentials(username: string, password: string) {
  const trimmedUser = username.trim();
  if (!trimmedUser || password.length === 0) return false;

  // The environment is the source of truth. If ADMIN_PASSWORD is not set,
  // there is no way in — by design.
  const expectedUser = getConfiguredUsername();
  const expectedPass = getConfiguredPassword();
  if (!expectedPass) return false;
  if (expectedUser && !safeEqual(trimmedUser, expectedUser)) return false;

  if (safeEqual(password, expectedPass)) return true;

  // Otherwise, check the salted hash stored in the database. This supports
  // passwords changed from the admin panel's "Change password" tab, which may
  // differ from the originally configured environment value.
  try {
    const rows = await db
      .select({ passwordHash: adminUsers.passwordHash })
      .from(adminUsers)
      .where(eq(adminUsers.username, trimmedUser))
      .limit(1);

    const row = rows[0];
    if (row && verifyPassword(password, row.passwordHash)) return true;
  } catch (error) {
    console.error("admin credential lookup failed", error);
  }

  return false;
}

/**
 * Stores a salted hash for the signed-in admin so that a password changed in
 * the panel keeps working even if the environment value is never updated.
 */
export async function ensureAdminAccount(username: string, password: string) {
  try {
    const existing = await db
      .select({ id: adminUsers.id })
      .from(adminUsers)
      .where(eq(adminUsers.username, username))
      .limit(1);

    if (existing[0]) return;

    await db
      .insert(adminUsers)
      .values({ username, passwordHash: hashPassword(password) });
  } catch (error) {
    console.error("ensureAdminAccount failed", error);
  }
}

export async function recordSuccessfulLogin(username: string) {
  try {
    await db
      .update(adminUsers)
      .set({ lastLoginAt: new Date() })
      .where(eq(adminUsers.username, username));
  } catch {
    /* non-fatal */
  }
}

/* ------------------------------------------------------------------ */
/* Cookie helpers                                                      */
/* ------------------------------------------------------------------ */

export async function getAdminSession() {
  const store = await cookies();
  return readSessionToken(store.get(COOKIE_NAME)?.value);
}

export async function setAdminCookie(username: string) {
  const store = await cookies();
  store.set(COOKIE_NAME, createSessionToken(username), {
    httpOnly: true,
    sameSite: "lax",
    secure: process.env.NODE_ENV === "production",
    path: "/",
    maxAge: MAX_AGE_SECONDS,
  });
}

export async function clearAdminCookie() {
  const store = await cookies();
  store.set(COOKIE_NAME, "", { path: "/", maxAge: 0 });
}

export const ADMIN_COOKIE_NAME = COOKIE_NAME;
