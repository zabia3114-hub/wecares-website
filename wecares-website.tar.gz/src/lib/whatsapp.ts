/** We Cares WhatsApp ordering helpers. */

export const WHATSAPP_NUMBER_LOCAL = "0303 730 7113";
/** Formatted for display in the UI. */
export const WHATSAPP_NUMBER_DISPLAY = WHATSAPP_NUMBER_LOCAL;
export const WHATSAPP_NUMBER_RAW = "03037307113";
export const WHATSAPP_NUMBER_INTL = "923037307113";
export const SUPPORT_PHONE_DISPLAY = "0303 730 7113";
export const SUPPORT_PHONE_INTL = WHATSAPP_NUMBER_INTL;
export const SUPPORT_EMAIL = "care@wecares.pk";

/** Builds a wa.me deep link that works on mobile and desktop. */
export function waLink(message: string) {
  return `https://wa.me/${WHATSAPP_NUMBER_INTL}?text=${encodeURIComponent(message)}`;
}

export const HELLO_MESSAGE =
  "Assalam o Alaikum! I would like to place an order with We Cares.";

export function productEnquiryMessage(name: string, price: string) {
  return `Assalam o Alaikum! I would like to order:\n\n• ${name} — ${price}\n\nPlease share delivery details.`;
}

export type WhatsAppLineItem = {
  name: string;
  quantity: number;
  lineTotal: string;
};

export function orderMessage(input: {
  items: WhatsAppLineItem[];
  total: string;
  orderNumber?: string;
  customerName?: string;
  city?: string;
}) {
  const lines = input.items
    .map((item) => `• ${item.name} × ${item.quantity} — ${item.lineTotal}`)
    .join("\n");

  return [
    "Assalam o Alaikum! New order from the We Cares website:",
    "",
    lines,
    "",
    `Total: ${input.total}`,
    input.customerName ? `Name: ${input.customerName}` : "",
    input.city ? `City: ${input.city}` : "",
    input.orderNumber ? `Order ref: ${input.orderNumber}` : "",
    "",
    "Please confirm my order. Thank you!",
  ]
    .filter(Boolean)
    .join("\n");
}

/** Builds a wa.me link for any number, used when the number is site-configurable. */
export function buildWhatsAppLink(number: string, message: string) {
  const digits = number.replace(/\D/g, "");
  return `https://wa.me/${digits}?text=${encodeURIComponent(message)}`;
}
