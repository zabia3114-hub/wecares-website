/** Canonical order lifecycle shared by storefront and admin. */

export const ORDER_STATUSES = [
  "new",
  "confirmed",
  "processing",
  "shipped",
  "delivered",
  "cancelled",
] as const;

export type OrderStatus = (typeof ORDER_STATUSES)[number];

export const ORDER_STATUS_LABELS: Record<OrderStatus, string> = {
  new: "New",
  confirmed: "Confirmed",
  processing: "Processing",
  shipped: "Shipped",
  delivered: "Delivered",
  cancelled: "Cancelled",
};

/** Legacy statuses from earlier orders, mapped onto the new lifecycle. */
const LEGACY_STATUS_MAP: Record<string, OrderStatus> = {
  pending: "new",
  dispatched: "shipped",
};

export function normalizeOrderStatus(value: string): OrderStatus {
  if ((ORDER_STATUSES as readonly string[]).includes(value)) {
    return value as OrderStatus;
  }
  return LEGACY_STATUS_MAP[value] ?? "new";
}

export function isOrderStatus(value: string): value is OrderStatus {
  return (ORDER_STATUSES as readonly string[]).includes(value);
}

/** Statuses that count as a completed sale for revenue reporting. */
export function isCompletedStatus(status: string) {
  return normalizeOrderStatus(status) === "delivered";
}

export function isCancelledStatus(status: string) {
  return normalizeOrderStatus(status) === "cancelled";
}

/* ------------------------------------------------------------------ */
/* Review moderation                                                   */
/* ------------------------------------------------------------------ */

export const REVIEW_STATUSES = ["pending", "approved", "hidden"] as const;
export type ReviewStatus = (typeof REVIEW_STATUSES)[number];

export const REVIEW_STATUS_LABELS: Record<ReviewStatus, string> = {
  pending: "Pending",
  approved: "Approved",
  hidden: "Hidden",
};

export function isReviewStatus(value: string): value is ReviewStatus {
  return (REVIEW_STATUSES as readonly string[]).includes(value);
}

export function normalizeReviewStatus(value: string): ReviewStatus {
  return isReviewStatus(value) ? value : "pending";
}
