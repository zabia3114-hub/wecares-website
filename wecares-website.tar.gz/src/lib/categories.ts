import { asc, eq, sql } from "drizzle-orm";
import { db } from "@/db";
import { categories, products } from "@/db/schema";
import type { Category } from "@/db/schema";

/**
 * Editable categories. Unlike the legacy free-text `categoryLabel`, these are
 * real rows: renaming a category updates the storefront, and disabling one
 * hides it without touching any product.
 */

/** Creates the table if missing so a fresh database never 500s. */
async function ensureTable() {
  await db.execute(sql`
    create table if not exists "categories" (
      "id" serial primary key,
      "slug" text not null,
      "name" text not null,
      "description" text not null default '',
      "image" text not null default '',
      "is_active" boolean not null default true,
      "sort_order" integer not null default 0,
      "created_at" timestamp with time zone not null default now(),
      constraint "categories_slug_key" unique ("slug")
    )
  `);
}

export type CategoryWithCount = Category & { productCount: number };

function slugify(value: string) {
  return value
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "")
    .slice(0, 60);
}

/** Storefront-visible categories (enabled only), with product counts. */
export async function getActiveCategories(): Promise<CategoryWithCount[]> {
  try {
    return await listCategories(true);
  } catch (error) {
    console.error("getActiveCategories failed", error);
    return [];
  }
}

/** Admin listing — includes disabled categories. */
export async function listCategories(
  onlyActive = false,
): Promise<CategoryWithCount[]> {
  try {
    const rows = await db
      .select({
        category: categories,
        productCount: sql<number>`(
          select count(*)::int from ${products}
          where ${products.categoryId} = ${categories.id}
            or (
              ${products.categoryId} is null
              and ${products.collectionSlug} = ${categories.slug}
            )
        )`,
      })
      .from(categories)
      .orderBy(asc(categories.sortOrder), asc(categories.name));

    const all = rows.map((row) => ({
      ...row.category,
      productCount: row.productCount,
    }));

    return onlyActive ? all.filter((item) => item.isActive) : all;
  } catch (error) {
    console.warn("categories read failed, creating table", error);
    await ensureTable();
    return [];
  }
}

/** Seeds a sensible starting set the first time the panel is opened. */
export async function ensureDefaultCategories() {
  try {
    const existing = await db.select({ id: categories.id }).from(categories).limit(1);
    if (existing[0]) return;

    const defaults = [
      { slug: "men", name: "Men", sortOrder: 1 },
      { slug: "women", name: "Women", sortOrder: 2 },
      { slug: "skincare", name: "Skincare", sortOrder: 3 },
      { slug: "health-fitness", name: "Health & Fitness", sortOrder: 4 },
      { slug: "daily-essentials", name: "Daily Essentials", sortOrder: 5 },
    ];

    await db.insert(categories).values(defaults).onConflictDoNothing();
  } catch (error) {
    console.warn("ensureDefaultCategories failed", error);
    await ensureTable();
  }
}

export async function createCategory(input: {
  name: string;
  description?: string;
  image?: string;
  isActive?: boolean;
  sortOrder?: number;
}) {
  await ensureTable();
  const name = input.name.trim();
  if (name.length < 2) throw new Error("Category name must be at least 2 characters.");

  let slug = slugify(name);
  if (!slug) slug = `category-${Date.now().toString(36)}`;

  const clash = await db
    .select({ id: categories.id })
    .from(categories)
    .where(eq(categories.slug, slug))
    .limit(1);

  if (clash[0]) throw new Error(`A category with the name "${name}" already exists.`);

  const inserted = await db
    .insert(categories)
    .values({
      slug,
      name,
      description: input.description?.trim() ?? "",
      image: input.image?.trim() ?? "",
      isActive: input.isActive ?? true,
      sortOrder: input.sortOrder ?? 99,
    })
    .returning();

  return inserted[0];
}

export async function updateCategory(
  id: number,
  input: {
    name: string;
    description?: string;
    image?: string;
    isActive?: boolean;
    sortOrder?: number;
  },
) {
  await ensureTable();
  const name = input.name.trim();
  if (name.length < 2) throw new Error("Category name must be at least 2 characters.");

  const updated = await db
    .update(categories)
    .set({
      name,
      description: input.description?.trim() ?? "",
      image: input.image?.trim() ?? "",
      isActive: input.isActive ?? true,
      sortOrder: input.sortOrder ?? 99,
    })
    .where(eq(categories.id, id))
    .returning();

  return updated[0] ?? null;
}

/** Renaming is a normal update, so every product stays linked automatically. */
export async function renameCategory(id: number, name: string) {
  await ensureTable();
  const updated = await db
    .update(categories)
    .set({ name: name.trim() })
    .where(eq(categories.id, id))
    .returning();
  return updated[0] ?? null;
}

export async function setCategoryActive(id: number, isActive: boolean) {
  await ensureTable();
  const updated = await db
    .update(categories)
    .set({ isActive })
    .where(eq(categories.id, id))
    .returning();
  return updated[0] ?? null;
}

export async function deleteCategory(id: number) {
  await ensureTable();
  // Detach products first so no product is deleted and none are orphaned.
  await db.update(products).set({ categoryId: null }).where(eq(products.categoryId, id));
  const deleted = await db
    .delete(categories)
    .where(eq(categories.id, id))
    .returning({ id: categories.id, name: categories.name });
  return deleted[0] ?? null;
}

/** Assigns a product to a category. Creates no duplicate product rows. */
export async function assignProductCategory(
  productId: number,
  categoryId: number | null,
) {
  if (categoryId != null) {
    await ensureTable();
    const exists = await db
      .select({ id: categories.id })
      .from(categories)
      .where(eq(categories.id, categoryId))
      .limit(1);
    if (!exists[0]) throw new Error("That category no longer exists.");
  }

  const updated = await db
    .update(products)
    .set({ categoryId })
    .where(eq(products.id, productId))
    .returning({ id: products.id, categoryId: products.categoryId });

  return updated[0] ?? null;
}
