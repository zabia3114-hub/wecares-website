/** Shape of the editable site settings. Kept free of server-only imports so
 * client components can import it safely. */

export type SiteSettings = {
  brandName: string;
  tagline: string;
  heroBadge: string;
  heroTitle: string;
  heroHighlight: string;
  heroSubtitle: string;
  whatsappNumber: string;
  whatsappDisplay: string;
  phoneNumber: string;
  email: string;
  address: string;
  city: string;
  orderHours: string;
  theme: string;
  fontHeading: string;
  fontBody: string;
  fontPrice: string;
  shippingStandardRupees: number;
  shippingExpressRupees: number;
  freeShippingOverRupees: number;
  codEnabled: boolean;
  bankTransferEnabled: boolean;
  orderPrefix: string;
  logoUrl: string;
  footerAbout: string;
};

export const SETTING_DEFAULTS: SiteSettings = {
  brandName: "We Cares",
  tagline: "Nature's Care, With You",
  heroBadge: "Herbal Wellness · Pakistan",
  heroTitle: "Nature's Care,",
  heroHighlight: "With You",
  heroSubtitle:
    "We Cares prepares traditional herbal majoon and herbal oils with carefully sourced botanicals, honest labelling and premium packaging. Delivered across Pakistan.",
  whatsappNumber: "923037307113",
  whatsappDisplay: "0303 730 7113",
  phoneNumber: "0303 730 7113",
  email: "care@wecares.pk",
  address: "Pakistan · nationwide delivery",
  city: "Pakistan",
  orderHours: "10:00 AM – 10:00 PM (PKT)",
  theme: "forest-gold",
  fontHeading: "cormorant",
  fontBody: "inter",
  fontPrice: "cormorant",
  shippingStandardRupees: 250,
  shippingExpressRupees: 500,
  freeShippingOverRupees: 5000,
  codEnabled: true,
  bankTransferEnabled: true,
  orderPrefix: "WC",
  logoUrl: "",
  footerAbout:
    "We Cares is a Pakistani herbal wellness brand. We prepare traditional herbal majoon and herbal oils with carefully sourced ingredients and honest labelling.",
};
