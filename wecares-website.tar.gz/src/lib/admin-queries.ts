import { desc, eq, sql } from "drizzle-orm";
import { db } from "@/db";
import { collections, orders, products, reviews } from "@/db/schema";
import type { Order, Product } from "@/db/schema";
import { ensureSeeded } from "@/lib/seed-init";
import {
  isOrderStatus,
  isReviewStatus,
  normalizeOrderStatus,
} from "@/lib/status";
import type { SortKey } from "@/lib/queries";

export type { SortKey };

/* ------------------------------------------------------------------ */
/* Products                                                            */
/* ------------------------------------------------------------------ */

export async function getAllProductsForAdmin(): Promise<Product[]> {
  await ensureSeeded();
  return db.select().from(products).orderBy(products.sortOrder, products.id);
}

export type ProductInput = {
  slug?: string;
  name: string;
  subtitle: string;
  description: string;
  howToUse: string;
  disclaimer?: string;
  collectionSlug: string;
  categoryLabel: string;
  categoryId?: number | null;
  priceRupees: number;
  compareAtRupees?: number | null;
  image: string;
  highlights: string[];
  ingredients: string[];
  netWeight: string;
  suitability: string;
  isFeatured?: boolean;
  isBestseller?: boolean;
  isActive?: boolean;
  stock: number;
  sortOrder: number;
};

function slugify(value: string) {
  return value
    .toLowerCase()
    .replace(/"/g, "")
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "")
    .slice(0, 80);
}

export async function createProduct(input: ProductInput) {
  await ensureSeeded();

  const slug = slugify(input.slug?.trim() || input.name);
  const existing = await db
    .select({ id: products.id })
    .from(products)
    .where(eq(products.slug, slug))
    .limit(1);

  if (existing[0]) {
    throw new Error(`A product with the URL slug "${slug}" already exists.`);
  }

  const inserted = await db
    .insert(products)
    .values({
      slug,
      name: input.name,
      subtitle: input.subtitle,
      description: input.description,
      howToUse: input.howToUse,
      disclaimer:
        input.disclaimer?.trim() ||
        "A herbal preparation. Not intended to diagnose, treat, cure or prevent any disease. Full ingredient and usage information is printed on the pack label.",
      collectionSlug: input.collectionSlug,
      categoryLabel: input.categoryLabel,
      categoryId: input.categoryId ?? null,
      pricePaisa: Math.round(input.priceRupees * 100),
      compareAtPaisa: input.compareAtRupees
        ? Math.round(input.compareAtRupees * 100)
        : null,
      images: input.image ? [input.image] : [],
      highlights: input.highlights,
      ingredients: input.ingredients,
      netWeight: input.netWeight,
      suitability: input.suitability,
      isFeatured: input.isFeatured ?? true,
      isNew: true,
      isBestseller: input.isBestseller ?? false,
      isActive: input.isActive ?? true,
      stock: input.stock,
      sortOrder: input.sortOrder,
    })
    .returning();

  return inserted[0];
}

export async function updateProduct(id: number, input: ProductInput) {
  await ensureSeeded();

  const updated = await db
    .update(products)
    .set({
      name: input.name,
      subtitle: input.subtitle,
      description: input.description,
      howToUse: input.howToUse,
      disclaimer:
        input.disclaimer?.trim() ||
        "A herbal preparation. Not intended to diagnose, treat, cure or prevent any disease. Full ingredient and usage information is printed on the pack label.",
      collectionSlug: input.collectionSlug,
      categoryLabel: input.categoryLabel,
      categoryId: input.categoryId ?? null,
      pricePaisa: Math.round(input.priceRupees * 100),
      compareAtPaisa: input.compareAtRupees
        ? Math.round(input.compareAtRupees * 100)
        : null,
      images: input.image ? [input.image] : [],
      highlights: input.highlights,
      ingredients: input.ingredients,
      netWeight: input.netWeight,
      suitability: input.suitability,
      isFeatured: input.isFeatured ?? false,
      isBestseller: input.isBestseller ?? false,
      isActive: input.isActive ?? true,
      stock: input.stock,
      sortOrder: input.sortOrder,
    })
    .where(eq(products.id, id))
    .returning();

  return updated[0] ?? null;
}

export async function deleteProduct(id: number) {
  const deleted = await db
    .delete(products)
    .where(eq(products.id, id))
    .returning({ id: products.id, slug: products.slug });
  return deleted[0] ?? null;
}

export async function toggleProductActive(id: number, isActive: boolean) {
  const updated = await db
    .update(products)
    .set({ isActive })
    .where(eq(products.id, id))
    .returning();
  return updated[0] ?? null;
}

export async function updateProductPrice(
  id: number,
  priceRupees: number,
  compareAtRupees: number | null,
) {
  const updated = await db
    .update(products)
    .set({
      pricePaisa: Math.round(priceRupees * 100),
      compareAtPaisa: compareAtRupees ? Math.round(compareAtRupees * 100) : null,
    })
    .where(eq(products.id, id))
    .returning();
  return updated[0] ?? null;
}

/* ------------------------------------------------------------------ */
/* Collections                                                         */
/* ------------------------------------------------------------------ */

export async function getCollectionsAdmin() {
  await ensureSeeded();
  return db.select().from(collections).orderBy(collections.sortOrder);
}

/* ------------------------------------------------------------------ */
/* Orders                                                              */
/* ------------------------------------------------------------------ */

export async function getAllOrders(): Promise<Order[]> {
  await ensureSeeded();
  return db.select().from(orders).orderBy(desc(orders.createdAt), desc(orders.id));
}

export type DashboardStats = {
  totalProducts: number;
  activeProducts: number;
  totalOrders: number;
  pendingOrders: number;
  completedOrders: number;
  cancelledOrders: number;
  totalRevenue: number;
  completedRevenue: number;
  totalReviews: number;
  pendingReviews: number;
  averageRating: number;
};

/** Every figure is computed in SQL from live tables — no hard-coded numbers. */
export async function getDashboardStats(): Promise<DashboardStats> {
  await ensureSeeded();

  const [productRow] = await db
    .select({
      total: sql<number>`count(*)::int`,
      active: sql<number>`count(*) filter (where ${products.isActive})::int`,
    })
    .from(products);

  const [orderRow] = await db
    .select({
      total: sql<number>`count(*)::int`,
      pending: sql<number>`count(*) filter (where ${orders.status} in ('new','pending'))::int`,
      completed: sql<number>`count(*) filter (where ${orders.status} in ('delivered'))::int`,
      cancelled: sql<number>`count(*) filter (where ${orders.status} = 'cancelled')::int`,
      revenue: sql<number>`coalesce(sum(${orders.totalPaisa}) filter (where ${orders.status} <> 'cancelled'), 0)::int`,
      completedRevenue: sql<number>`coalesce(sum(${orders.totalPaisa}) filter (where ${orders.status} = 'delivered'), 0)::int`,
    })
    .from(orders);

  const [reviewRow] = await db
    .select({
      total: sql<number>`count(*)::int`,
      pending: sql<number>`count(*) filter (where ${reviews.status} = 'pending')::int`,
      average: sql<number>`coalesce(avg(${reviews.rating}) filter (where ${reviews.status} = 'approved'), 0)::float`,
    })
    .from(reviews);

  return {
    totalProducts: productRow?.total ?? 0,
    activeProducts: productRow?.active ?? 0,
    totalOrders: orderRow?.total ?? 0,
    pendingOrders: orderRow?.pending ?? 0,
    completedOrders: orderRow?.completed ?? 0,
    cancelledOrders: orderRow?.cancelled ?? 0,
    totalRevenue: orderRow?.revenue ?? 0,
    completedRevenue: orderRow?.completedRevenue ?? 0,
    totalReviews: reviewRow?.total ?? 0,
    pendingReviews: reviewRow?.pending ?? 0,
    averageRating: Math.round((reviewRow?.average ?? 0) * 10) / 10,
  };
}

/** Permanently removes an order. Used to clear test/demo orders. */
export async function deleteOrder(id: number) {
  const deleted = await db
    .delete(orders)
    .where(eq(orders.id, id))
    .returning({ id: orders.id, orderNumber: orders.orderNumber });

  return deleted[0] ?? null;
}

export async function updateOrderStatus(id: number, status: string) {
  // Accept the canonical statuses plus known legacy values (pending/dispatched),
  // but reject anything unknown instead of silently defaulting it.
  const legacy: Record<string, string> = {
    pending: "new",
    dispatched: "shipped",
  };
  const next = legacy[status] ?? status;
  if (!isOrderStatus(next)) return null;

  const updated = await db
    .update(orders)
    .set({ status: next })
    .where(eq(orders.id, id))
    .returning();

  return updated[0] ?? null;
}

/* ------------------------------------------------------------------ */
/* Reviews moderation                                                  */
/* ------------------------------------------------------------------ */

export type AdminReview = {
  id: number;
  productId: number;
  productName: string;
  productSlug: string;
  authorName: string;
  authorMobile: string;
  rating: number;
  title: string;
  body: string;
  status: string;
  isVerifiedBuyer: boolean;
  createdAt: Date;
};

export async function getAllReviewsForAdmin(): Promise<AdminReview[]> {
  await ensureSeeded();
  const rows = await db
    .select({
      id: reviews.id,
      productId: reviews.productId,
      productName: products.name,
      productSlug: products.slug,
      authorName: reviews.authorName,
      authorMobile: reviews.authorMobile,
      rating: reviews.rating,
      title: reviews.title,
      body: reviews.body,
      status: reviews.status,
      isVerifiedBuyer: reviews.isVerifiedBuyer,
      createdAt: reviews.createdAt,
    })
    .from(reviews)
    .innerJoin(products, eq(products.id, reviews.productId))
    .orderBy(desc(reviews.createdAt), desc(reviews.id));

  return rows;
}

export async function setReviewStatus(id: number, status: string) {
  if (!isReviewStatus(status)) return null;

  const updated = await db
    .update(reviews)
    .set({ status })
    .where(eq(reviews.id, id))
    .returning();

  return updated[0] ?? null;
}

export async function deleteReview(id: number) {
  const deleted = await db
    .delete(reviews)
    .where(eq(reviews.id, id))
    .returning({ id: reviews.id });

  return deleted[0] ?? null;
}

/** Reviews that shoppers have submitted and are waiting for a decision. */
export async function getPendingReviewCount() {
  const [row] = await db
    .select({ total: sql<number>`count(*)::int` })
    .from(reviews)
    .where(eq(reviews.status, "pending"));

  return row?.total ?? 0;
}
