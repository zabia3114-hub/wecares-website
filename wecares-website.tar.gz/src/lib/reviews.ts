import { and, avg, count, desc, eq, sql } from "drizzle-orm";
import { db } from "@/db";
import { products, reviews } from "@/db/schema";
import { ensureSeeded } from "@/lib/seed-init";

export type PublicReview = {
  id: number;
  authorName: string;
  rating: number;
  title: string;
  body: string;
  isVerifiedBuyer: boolean;
  createdAt: Date;
};

/** Only approved reviews are ever shown to shoppers. */
export async function getApprovedProductReviews(
  productId: number,
): Promise<PublicReview[]> {
  await ensureSeeded();
  return db
    .select({
      id: reviews.id,
      authorName: reviews.authorName,
      rating: reviews.rating,
      title: reviews.title,
      body: reviews.body,
      isVerifiedBuyer: reviews.isVerifiedBuyer,
      createdAt: reviews.createdAt,
    })
    .from(reviews)
    .where(and(eq(reviews.productId, productId), eq(reviews.status, "approved")))
    .orderBy(desc(reviews.createdAt), desc(reviews.id));
}

export type RatingSummary = { average: number; total: number };

export async function getProductRatingSummary(
  productId: number,
): Promise<RatingSummary> {
  await ensureSeeded();
  const rows = await db
    .select({
      average: avg(reviews.rating),
      total: count(reviews.id),
    })
    .from(reviews)
    .where(and(eq(reviews.productId, productId), eq(reviews.status, "approved")));

  const row = rows[0];
  return {
    average: row?.average ? Math.round(Number(row.average) * 10) / 10 : 0,
    total: row?.total ?? 0,
  };
}

export type SubmitReviewInput = {
  productId: number;
  authorName: string;
  authorMobile: string;
  rating: number;
  title: string;
  body: string;
};

/**
 * Creates a review as `pending`. A review only becomes public once the owner
 * approves it in the admin panel.
 */
export async function submitProductReview(input: SubmitReviewInput) {
  await ensureSeeded();

  const exists = await db
    .select({ id: products.id })
    .from(products)
    .where(eq(products.id, input.productId))
    .limit(1);

  if (!exists[0]) return null;

  const inserted = await db
    .insert(reviews)
    .values({
      productId: input.productId,
      authorName: input.authorName,
      authorMobile: input.authorMobile,
      rating: input.rating,
      title: input.title,
      body: input.body,
      status: "pending",
      isVerifiedBuyer: false,
    })
    .returning();

  return inserted[0];
}

/** Used to flag reviews from customers who actually placed an order. */
export async function markVerifiedBuyers(mobile: string) {
  if (!mobile) return;
  try {
    await db
      .update(reviews)
      .set({ isVerifiedBuyer: true })
      .where(eq(reviews.authorMobile, mobile));
  } catch {
    /* non-fatal */
  }
}

export const revalidateReviews = sql;
