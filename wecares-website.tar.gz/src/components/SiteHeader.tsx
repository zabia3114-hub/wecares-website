"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { useEffect, useState } from "react";
import { useCart } from "@/components/cart/CartProvider";
import { Logo } from "@/components/Logo";
import { WhatsAppIcon } from "@/components/WhatsAppButton";
import { cn, formatPkr } from "@/lib/format";
import { buildWhatsAppLink } from "@/lib/whatsapp";
import { useSettings } from "@/components/SettingsProvider";

const NAV = [
  { href: "/shop", label: "All Products" },
  { href: "/collections/majoon-wellness", label: "Majoon" },
  { href: "/collections/herbal-oils", label: "Herbal Oils" },
  { href: "/collections/mens-care", label: "Men's Care" },
];

export function SiteHeader() {
  const settings = useSettings();
  const TICKER = [
    "Nationwide delivery across Pakistan",
    "Cash on delivery available",
    `Order on WhatsApp ${settings.whatsappDisplay}`,
    settings.tagline,
    "Quality-sourced herbal ingredients",
  ];
  const { count, openCart, subtotalPaisa } = useCart();
  const [scrolled, setScrolled] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);
  const pathname = usePathname();

  // Admin screens render their own header.
  if (pathname?.startsWith("/admin")) return null;

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 8);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  useEffect(() => {
    setMenuOpen(false);
  }, [pathname]);

  return (
    <header className="sticky top-0 z-50">
      {/* Trust ticker */}
      <div className="overflow-hidden bg-forest-950 py-2">
        <div className="marquee-track gap-8 text-[10px] font-medium uppercase tracking-[0.2em] text-gold-soft/90 sm:text-[11px]">
          {[...TICKER, ...TICKER].map((item, index) => (
            <span key={`${item}-${index}`} className="flex items-center gap-8">
              {item}
              <span aria-hidden className="text-gold">
                ✦
              </span>
            </span>
          ))}
        </div>
      </div>

      {/* Main bar */}
      <div
        className={cn(
          "border-b transition-all duration-300",
          scrolled
            ? "border-gold/25 bg-forest-900/95 shadow-lift backdrop-blur-md"
            : "border-transparent bg-forest-900",
        )}
      >
        <div className="mx-auto flex max-w-7xl items-center justify-between gap-3 px-4 py-3 sm:px-6 lg:px-8">
          <Link href="/" className="shrink-0" aria-label="We Cares home">
            <Logo variant="dark" brandName={settings.brandName} tagline={settings.tagline} logoUrl={settings.logoUrl} />
          </Link>

          <nav className="hidden items-center gap-7 lg:flex">
            {NAV.map((item) => (
              <Link
                key={item.label}
                href={item.href}
                className="relative text-sm font-medium text-cream/85 transition hover:text-gold"
              >
                {item.label}
              </Link>
            ))}
          </nav>

          <div className="flex items-center gap-2">
            <a
              href={buildWhatsAppLink(
                settings.whatsappNumber,
                "Assalam o Alaikum! I would like to place an order with We Cares.",
              )}
              target="_blank"
              rel="noopener noreferrer"
              className="hidden items-center gap-2 rounded-full border border-gold/40 px-4 py-2.5 text-xs font-semibold text-gold-soft transition hover:bg-gold/10 sm:inline-flex"
            >
              <WhatsAppIcon className="h-4 w-4" />
              {settings.whatsappDisplay}
            </a>

            <button
              type="button"
              onClick={openCart}
              className="group relative inline-flex items-center gap-2 rounded-full bg-gold px-4 py-2.5 text-sm font-semibold text-forest-950 transition hover:bg-gold-soft active:scale-95"
            >
              <svg viewBox="0 0 24 24" className="h-4 w-4" aria-hidden>
                <path
                  d="M6 8h12l-1 12H7L6 8zm3 0a3 3 0 016 0"
                  stroke="currentColor"
                  strokeWidth="1.6"
                  strokeLinecap="round"
                  fill="none"
                />
              </svg>
              <span className="hidden sm:inline">Cart</span>
              <span
                key={count}
                className="grid h-5 min-w-5 place-items-center rounded-full bg-forest-900 px-1 text-[11px] font-bold text-gold"
              >
                {count}
              </span>
            </button>

            <button
              type="button"
              onClick={() => setMenuOpen((open) => !open)}
              className="grid h-10 w-10 place-items-center rounded-full border border-gold/30 text-gold transition lg:hidden"
              aria-label="Toggle menu"
              aria-expanded={menuOpen}
            >
              <svg viewBox="0 0 24 24" className="h-4 w-4" aria-hidden>
                <path
                  d={menuOpen ? "M6 6l12 12M18 6L6 18" : "M4 7h16M4 12h16M4 17h16"}
                  stroke="currentColor"
                  strokeWidth="1.8"
                  strokeLinecap="round"
                />
              </svg>
            </button>
          </div>
        </div>

        {menuOpen ? (
          <div className="animate-fade-in border-t border-gold/20 bg-forest-900 px-4 pb-5 pt-4 lg:hidden">
            <div className="grid gap-2">
              {NAV.map((item) => (
                <Link
                  key={item.label}
                  href={item.href}
                  className="rounded-xl border border-gold/15 bg-forest-800/60 px-4 py-3.5 text-sm font-medium text-cream transition hover:border-gold/50"
                >
                  {item.label}
                </Link>
              ))}
            </div>
            <a
              href={buildWhatsAppLink(
                settings.whatsappNumber,
                "Assalam o Alaikum! I would like to place an order with We Cares.",
              )}
              target="_blank"
              rel="noopener noreferrer"
              className="mt-2.5 flex items-center justify-center gap-2 rounded-xl bg-[#25D366] px-4 py-3.5 text-sm font-semibold text-forest-950"
            >
              <WhatsAppIcon className="h-4 w-4" />
              Order on WhatsApp · {settings.whatsappDisplay}
            </a>
            <p className="mt-3 text-center text-[11px] text-cream/60">
              Cart total: {formatPkr(subtotalPaisa)}
            </p>
          </div>
        ) : null}
      </div>
    </header>
  );
}
