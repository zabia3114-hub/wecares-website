import type { AnchorHTMLAttributes, ReactNode } from "react";
import { cn } from "@/lib/format";
import { waLink } from "@/lib/whatsapp";

export function WhatsAppIcon({ className }: { className?: string }) {
  return (
    <svg viewBox="0 0 24 24" className={className} aria-hidden fill="currentColor">
      <path d="M17.47 14.38c-.3-.15-1.75-.86-2.02-.96-.27-.1-.47-.15-.67.15-.2.3-.77.96-.94 1.16-.17.2-.35.22-.64.07-.3-.15-1.12-.41-2.13-1.32-.79-.7-1.32-1.57-1.47-1.87-.15-.3-.02-.46.13-.61.13-.13.3-.35.45-.52.15-.17.2-.3.3-.5.1-.2.05-.37-.02-.52-.08-.15-.67-1.6-.92-2.19-.24-.58-.49-.5-.67-.5h-.57c-.2 0-.52.07-.79.37-.27.3-1.04 1.01-1.04 2.46 0 1.45 1.06 2.85 1.21 3.05.15.2 2.08 3.18 5.04 4.46.7.3 1.25.48 1.68.62.71.22 1.35.19 1.86.12.57-.09 1.75-.72 2-1.41.25-.7.25-1.29.17-1.41-.07-.13-.27-.2-.57-.35z" />
      <path d="M12.04 2C6.6 2 2.18 6.42 2.18 11.86c0 1.74.46 3.37 1.26 4.79L2 22l5.5-1.42a9.84 9.84 0 004.54 1.11c5.44 0 9.86-4.42 9.86-9.86S17.48 2 12.04 2zm0 17.9c-1.5 0-2.9-.4-4.11-1.1l-.3-.17-3.05.79.81-2.98-.19-.31a8.06 8.06 0 01-1.24-4.31c0-4.46 3.63-8.09 8.09-8.09s8.08 3.63 8.08 8.09c0 4.46-3.63 8.08-8.09 8.08z" />
    </svg>
  );
}

type Variant = "primary" | "outline" | "float";

const styles: Record<Variant, string> = {
  primary:
    "bg-[#25D366] text-[#04150f] hover:bg-[#1fbe5a] shadow-[0_10px_30px_-16px_rgba(37,211,102,0.9)]",
  outline:
    "border border-[#25D366]/60 bg-transparent text-[#1fbe5a] hover:bg-[#25D366]/10",
  float:
    "bg-[#25D366] text-white shadow-[0_14px_34px_-12px_rgba(4,21,15,0.6)] hover:bg-[#1fbe5a]",
};

export function WhatsAppButton({
  message,
  children,
  variant = "primary",
  className,
  size = "md",
  label,
  ...rest
}: {
  message: string;
  children?: ReactNode;
  variant?: Variant;
  size?: "sm" | "md" | "lg";
  label?: string;
} & Omit<AnchorHTMLAttributes<HTMLAnchorElement>, "href" | "children">) {
  const sizes = {
    sm: "px-4 py-2.5 text-xs gap-1.5",
    md: "px-5 py-3.5 text-sm gap-2",
    lg: "px-6 py-4 text-[15px] gap-2.5",
  };

  return (
    <a
      href={waLink(message)}
      target="_blank"
      rel="noopener noreferrer"
      aria-label={label ?? "Order on WhatsApp"}
      className={cn(
        "inline-flex items-center justify-center rounded-full font-semibold transition active:scale-[0.98]",
        styles[variant],
        sizes[size],
        className,
      )}
      {...rest}
    >
      <WhatsAppIcon className="h-4.5 w-4.5 shrink-0" />
      {children ?? "Order on WhatsApp"}
    </a>
  );
}
