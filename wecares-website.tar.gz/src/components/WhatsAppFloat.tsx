"use client";

import { useEffect, useState } from "react";
import { WhatsAppIcon } from "@/components/WhatsAppButton";
import { HELLO_MESSAGE, buildWhatsAppLink } from "@/lib/whatsapp";
import { useSettings } from "@/components/SettingsProvider";
import { usePathname } from "next/navigation";

/** Sticky WhatsApp shortcut, shown on all screen sizes but tuned for mobile. */
export function WhatsAppFloat() {
  const [mounted, setMounted] = useState(false);
  const pathname = usePathname();
  const settings = useSettings();

  useEffect(() => {
    const timer = setTimeout(() => setMounted(true), 700);
    return () => clearTimeout(timer);
  }, []);

  // The admin area has its own navigation and must not be overlapped.
  if (pathname?.startsWith("/admin")) return null;

  if (!mounted) return null;

  return (
    <a
      href={buildWhatsAppLink(settings.whatsappNumber, HELLO_MESSAGE)}
      target="_blank"
      rel="noopener noreferrer"
      aria-label={`Order on WhatsApp at ${settings.whatsappDisplay}`}
      className="fixed bottom-4 right-4 z-[60] flex items-center gap-2.5 rounded-full bg-[#25D366] px-4 py-3.5 font-semibold text-white shadow-[0_16px_38px_-12px_rgba(4,21,15,0.55)] transition active:scale-95 sm:bottom-6 sm:right-6 sm:px-5"
    >
      <WhatsAppIcon className="h-5 w-5 shrink-0" />
      <span className="text-sm leading-none">Order on WhatsApp</span>
      <span className="sr-only">{settings.whatsappDisplay}</span>
    </a>
  );
}
