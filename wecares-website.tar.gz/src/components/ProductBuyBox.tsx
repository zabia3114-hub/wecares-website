"use client";

import { useRouter } from "next/navigation";
import { useState } from "react";
import { useCart } from "@/components/cart/CartProvider";
import { WhatsAppButton } from "@/components/WhatsAppButton";
import { cn, formatPkr } from "@/lib/format";
import { productEnquiryMessage } from "@/lib/whatsapp";

export function ProductBuyBox({
  slug,
  name,
  image,
  pricePaisa,
  netWeight,
  stock,
}: {
  slug: string;
  name: string;
  image: string;
  pricePaisa: number;
  netWeight: string;
  stock: number;
}) {
  const { addItem, openCart, lastAddedSlug } = useCart();
  const [quantity, setQuantity] = useState(1);
  const router = useRouter();
  const justAdded = lastAddedSlug === slug;
  const lineTotal = formatPkr(pricePaisa * quantity);

  const addToCart = (goToCheckout = false) => {
    addItem({ slug, name, image, pricePaisa }, quantity);
    if (goToCheckout) router.push("/checkout");
    else openCart();
  };

  return (
    <div className="mt-8">
      <div className="flex flex-wrap items-center gap-3">
        <div className="inline-flex items-center gap-1 rounded-full border border-sand bg-white px-2 py-1.5">
          <button
            type="button"
            onClick={() => setQuantity((value) => Math.max(1, value - 1))}
            className="grid h-9 w-9 place-items-center rounded-full text-lg text-forest-800 transition hover:bg-cream-deep"
            aria-label="Decrease quantity"
          >
            −
          </button>
          <span className="w-9 text-center text-sm font-semibold">
            {quantity}
          </span>
          <button
            type="button"
            onClick={() => setQuantity((value) => Math.min(20, value + 1))}
            className="grid h-9 w-9 place-items-center rounded-full text-lg text-forest-800 transition hover:bg-cream-deep"
            aria-label="Increase quantity"
          >
            +
          </button>
        </div>

        <p className="text-sm text-ink/60">
          Total:{" "}
          <span className="font-display text-lg font-semibold text-forest-900">
            {lineTotal}
          </span>
        </p>
      </div>

      <div className="mt-5 space-y-2.5">
        <button
          type="button"
          onClick={() => addToCart(false)}
          className={cn(
            "w-full rounded-full px-7 py-4 text-sm font-semibold transition active:scale-[0.99]",
            justAdded
              ? "bg-moss text-cream"
              : "bg-forest-800 text-cream hover:bg-forest-700",
          )}
        >
          {justAdded ? "Added to cart ✓" : "Add to Cart"}
        </button>

        <button
          type="button"
          onClick={() => addToCart(true)}
          className="w-full rounded-full bg-gold px-7 py-4 text-sm font-semibold text-forest-950 transition hover:bg-gold-soft active:scale-[0.99]"
        >
          Buy Now — Order Now
        </button>

        <WhatsAppButton
          size="lg"
          variant="outline"
          className="w-full"
          message={productEnquiryMessage(`${name} (${netWeight})`, formatPkr(pricePaisa))}
          label={`Order ${name} on WhatsApp`}
        >
          Order on WhatsApp
        </WhatsAppButton>
      </div>

      <p className="mt-4 text-xs text-ink/55">
        {stock > 0
          ? `In stock · dispatched within 24 hours`
          : "Currently unavailable"}
      </p>
    </div>
  );
}
