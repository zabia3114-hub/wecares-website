"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { useMemo, useState } from "react";
import { ProductImage } from "@/components/ProductImage";
import { cn, formatPkr } from "@/lib/format";

export type AdminProduct = {
  id: number;
  categoryId: number | string;
  slug: string;
  name: string;
  subtitle: string;
  description: string;
  howToUse: string;
  disclaimer: string;
  collectionSlug: string;
  categoryLabel: string;
  priceRupees: number;
  compareAtRupees: number | null;
  image: string;
  highlights: string[];
  ingredients: string[];
  netWeight: string;
  suitability: string;
  isFeatured: boolean;
  isBestseller: boolean;
  isActive: boolean;
  stock: number;
  sortOrder: number;
};

export function ProductsManager({
  products,
  collections,
  categories = [],
}: {
  products: AdminProduct[];
  collections: Array<{ slug: string; name: string }>;
  categories?: Array<{ id: number; name: string }>;
}) {
  const router = useRouter();
  const [busyId, setBusyId] = useState<number | null>(null);
  const [message, setMessage] = useState<{ kind: "ok" | "error"; text: string } | null>(
    null,
  );
  const [query, setQuery] = useState("");
  const [showHidden, setShowHidden] = useState(true);

  const visible = useMemo(() => {
    const term = query.trim().toLowerCase();
    return products.filter((product) => {
      if (!showHidden && !product.isActive) return false;
      if (!term) return true;
      return (
        product.name.toLowerCase().includes(term) ||
        product.categoryLabel.toLowerCase().includes(term) ||
        product.slug.toLowerCase().includes(term)
      );
    });
  }, [products, query, showHidden]);

  async function mutate(body: Record<string, unknown>, successText: string) {
    setMessage(null);
    try {
      const response = await fetch("/api/admin/mutations", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body),
      });
      const payload = (await response.json()) as { ok?: boolean; error?: string };
      if (!response.ok || !payload.ok) {
        throw new Error(payload.error ?? "Action failed");
      }
      setMessage({ kind: "ok", text: successText });
      router.refresh();
      return true;
    } catch (error) {
      setMessage({
        kind: "error",
        text: error instanceof Error ? error.message : "Action failed",
      });
      return false;
    }
  }

  async function toggleActive(product: AdminProduct) {
    setBusyId(product.id);
    await mutate(
      {
        action: "toggle-active",
        id: product.id,
        isActive: !product.isActive,
      },
      product.isActive
        ? `${product.name} is now hidden from the store.`
        : `${product.name} is now live in the store.`,
    );
    setBusyId(null);
  }

  async function remove(product: AdminProduct) {
    const confirmed = window.confirm(
      `Permanently delete "${product.name}"?\n\nThis cannot be undone. To keep it but hide it from shoppers, use Hide instead.`,
    );
    if (!confirmed) return;
    setBusyId(product.id);
    const done = await mutate(
      { action: "delete", id: product.id },
      `${product.name} has been deleted.`,
    );
    setBusyId(null);
    void done;
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <h1 className="font-display text-3xl text-forest-900 sm:text-4xl">
            Products
          </h1>
          <p className="mt-2 text-sm text-ink/60">
            {products.length} total · {products.filter((p) => p.isActive).length}{" "}
            live in the store
          </p>
        </div>
        <Link
          href="/admin/products/new"
          className="rounded-full bg-gold px-6 py-3.5 text-sm font-semibold text-forest-950 transition hover:bg-gold-soft"
        >
          + Add product
        </Link>
      </div>

      {message ? (
        <p
          className={cn(
            "rounded-2xl px-4 py-3 text-sm font-medium",
            message.kind === "ok"
              ? "bg-moss/12 text-moss"
              : "bg-rose-50 text-red-700",
          )}
        >
          {message.text}
        </p>
      ) : null}

      <div className="flex flex-wrap items-center gap-3">
        <input
          value={query}
          onChange={(event) => setQuery(event.target.value)}
          placeholder="Search products"
          className="w-full max-w-xs rounded-full border border-sand bg-white px-5 py-3 text-sm focus:border-gold focus:outline-none"
        />
        <label className="inline-flex cursor-pointer items-center gap-2 text-sm text-ink/70">
          <input
            type="checkbox"
            checked={showHidden}
            onChange={(event) => setShowHidden(event.target.checked)}
            className="h-4 w-4 accent-forest-700"
          />
          Show hidden
        </label>
      </div>

      <div className="space-y-4">
        {visible.length === 0 ? (
          <p className="rounded-[1.5rem] border border-dashed border-sand bg-white px-6 py-14 text-center text-sm text-ink/55">
            No products match your search.
          </p>
        ) : (
          visible.map((product) => (
            <article
              key={product.id}
              className={cn(
                "rounded-[1.5rem] border bg-white p-4 sm:p-5",
                product.isActive ? "border-sand" : "border-dashed border-sand opacity-70",
              )}
            >
              <div className="flex flex-col gap-4 sm:flex-row">
                <div className="relative h-28 w-28 shrink-0 overflow-hidden rounded-2xl bg-forest-800">
                  <ProductImage
                    src={product.image}
                    alt={product.name}
                    name={product.name}
                    netWeight={product.netWeight}
                    sizes="112px"
                  />
                </div>

                <div className="min-w-0 flex-1">
                  <div className="flex flex-wrap items-center gap-2">
                    <span className="rounded-full bg-cream-deep px-2.5 py-1 text-[10px] font-bold uppercase tracking-[0.14em] text-forest-800">
                      {categories.find((c) => String(c.id) === String(product.categoryId))
                        ?.name ?? product.categoryLabel}
                    </span>
                    <span className="text-[10px] font-semibold uppercase tracking-[0.14em] text-ink/45">
                      {product.netWeight} · {product.suitability}
                    </span>
                    {!product.isActive ? (
                      <span className="rounded-full bg-ink/10 px-2.5 py-1 text-[10px] font-bold uppercase tracking-[0.12em] text-ink/60">
                        Hidden
                      </span>
                    ) : null}
                  </div>

                  <h2 className="mt-2 font-display text-lg leading-snug text-forest-900">
                    {product.name}
                  </h2>
                  <p className="mt-1 line-clamp-1 text-xs text-ink/55">
                    {product.subtitle}
                  </p>

                  <div className="mt-3 flex flex-wrap items-baseline gap-2">
                    <span className="font-display text-xl font-semibold text-forest-900">
                      {formatPkr(product.priceRupees * 100)}
                    </span>
                    {product.compareAtRupees ? (
                      <span className="text-xs text-ink/45 line-through">
                        {formatPkr(product.compareAtRupees * 100)}
                      </span>
                    ) : null}
                    <span
                      className={cn(
                        "rounded-full px-2.5 py-1 text-[10px] font-bold",
                        product.stock <= 10
                          ? "bg-red-50 text-red-700"
                          : "bg-moss/12 text-moss",
                      )}
                    >
                      {product.stock} in stock
                    </span>
                  </div>
                </div>

                <div className="flex shrink-0 flex-col gap-2 sm:w-40">
                  <Link
                    href={`/admin/products/${product.id}`}
                    className="rounded-full bg-forest-800 px-4 py-2.5 text-center text-xs font-semibold text-cream transition hover:bg-forest-700"
                  >
                    Edit
                  </Link>
                  <button
                    type="button"
                    onClick={() => toggleActive(product)}
                    disabled={busyId === product.id}
                    className="rounded-full border border-sand bg-white px-4 py-2.5 text-xs font-semibold text-forest-800 transition hover:border-gold disabled:opacity-50"
                  >
                    {product.isActive ? "Hide" : "Show"}
                  </button>
                  <Link
                    href={`/products/${product.slug}`}
                    className="rounded-full px-4 py-2.5 text-center text-xs font-semibold text-moss underline underline-offset-4"
                  >
                    View in store
                  </Link>
                  <button
                    type="button"
                    onClick={() => remove(product)}
                    disabled={busyId === product.id}
                    className="rounded-full px-4 py-2.5 text-xs font-semibold text-red-600 transition hover:bg-red-50 disabled:opacity-50"
                  >
                    Delete
                  </button>
                </div>
              </div>
            </article>
          ))
        )}
      </div>
    </div>
  );
}
