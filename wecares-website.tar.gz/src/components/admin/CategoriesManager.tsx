"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { useState } from "react";
import { ProductImage } from "@/components/ProductImage";
import { cn } from "@/lib/format";

export type AdminCategory = {
  id: number;
  name: string;
  slug: string;
  description: string;
  image: string;
  isActive: boolean;
  sortOrder: number;
  productCount: number;
};

type Draft = {
  id: number | null;
  name: string;
  description: string;
  image: string;
  isActive: boolean;
  sortOrder: number;
};

const EMPTY: Draft = {
  id: null,
  name: "",
  description: "",
  image: "",
  isActive: true,
  sortOrder: 10,
};

export function CategoriesManager({
  categories,
}: {
  categories: AdminCategory[];
}) {
  const router = useRouter();
  const [busyId, setBusyId] = useState<number | null>(null);
  const [draft, setDraft] = useState<Draft | null>(null);
  const [confirmId, setConfirmId] = useState<number | null>(null);
  const [message, setMessage] = useState<{
    kind: "ok" | "error";
    text: string;
  } | null>(null);

  async function call(body: Record<string, unknown>, successText: string) {
    setMessage(null);
    try {
      const response = await fetch("/api/admin/categories", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body),
      });
      const payload = (await response.json()) as { ok?: boolean; error?: string };
      if (!response.ok || !payload.ok) {
        throw new Error(payload.error ?? "Action failed");
      }
      setMessage({ kind: "ok", text: successText });
      router.refresh();
      return true;
    } catch (error) {
      setMessage({
        kind: "error",
        text: error instanceof Error ? error.message : "Action failed",
      });
      return false;
    }
  }

  async function saveDraft() {
    if (!draft) return;
    if (draft.name.trim().length < 2) {
      setMessage({ kind: "error", text: "Category name must be at least 2 characters." });
      return;
    }
    setBusyId(draft.id ?? -1);
    const ok = await call(
      {
        action: draft.id ? "update" : "create",
        id: draft.id ?? undefined,
        name: draft.name,
        description: draft.description,
        image: draft.image,
        isActive: draft.isActive,
        sortOrder: draft.sortOrder,
      },
      draft.id
        ? `${draft.name} updated. The storefront now uses the new name.`
        : `${draft.name} created and available on the storefront.`,
    );
    setBusyId(null);
    if (ok) setDraft(null);
  }

  async function toggle(category: AdminCategory) {
    setBusyId(category.id);
    await call(
      { action: "toggle-active", id: category.id, isActive: !category.isActive },
      category.isActive
        ? `${category.name} hidden from the storefront.`
        : `${category.name} is now visible on the storefront.`,
    );
    setBusyId(null);
  }

  async function remove(category: AdminCategory) {
    setBusyId(category.id);
    const ok = await call(
      { action: "delete", id: category.id },
      `${category.name} deleted. Its products were kept but are now uncategorised.`,
    );
    setBusyId(null);
    if (ok) setConfirmId(null);
  }

  async function move(category: AdminCategory, delta: number) {
    setBusyId(category.id);
    await call(
      {
        action: "update",
        id: category.id,
        name: category.name,
        description: category.description,
        image: category.image,
        isActive: category.isActive,
        sortOrder: Math.max(0, category.sortOrder + delta),
      },
      `${category.name} position updated.`,
    );
    setBusyId(null);
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <h1 className="font-display text-3xl text-forest-900 sm:text-4xl">
            Categories
          </h1>
          <p className="mt-2 text-sm text-ink/60">
            Create, rename, reorder, hide or delete categories. Products are
            assigned from the product editor.
          </p>
        </div>
        <button
          type="button"
          onClick={() => setDraft({ ...EMPTY })}
          className="rounded-full bg-gold px-6 py-3.5 text-sm font-semibold text-forest-950 transition hover:bg-gold-soft"
        >
          + Add category
        </button>
      </div>

      {message ? (
        <p
          className={cn(
            "rounded-2xl px-4 py-3 text-sm font-medium",
            message.kind === "ok"
              ? "bg-moss/12 text-moss"
              : "bg-red-50 text-red-700",
          )}
        >
          {message.text}
        </p>
      ) : null}

      {draft ? (
        <div className="rounded-[1.5rem] border border-gold/40 bg-white p-5 sm:p-7">
          <h2 className="font-display text-2xl text-forest-900">
            {draft.id ? "Edit category" : "New category"}
          </h2>

          <div className="mt-5 grid gap-5 sm:grid-cols-2">
            <label className="block text-[11px] font-semibold uppercase tracking-[0.14em] text-ink/55">
              Category name <span className="text-moss">*</span>
              <input
                value={draft.name}
                onChange={(event) =>
                  setDraft({ ...draft, name: event.target.value })
                }
                placeholder="e.g. Men, Women, Skincare"
                className="mt-2 w-full rounded-2xl border border-sand bg-white px-4 py-3.5 text-sm font-normal normal-case tracking-normal focus:border-gold focus:outline-none"
              />
            </label>

            <label className="block text-[11px] font-semibold uppercase tracking-[0.14em] text-ink/55">
              Position (lower = first)
              <input
                inputMode="numeric"
                value={draft.sortOrder}
                onChange={(event) =>
                  setDraft({
                    ...draft,
                    sortOrder: Number(event.target.value.replace(/\D/g, "")) || 0,
                  })
                }
                className="mt-2 w-full rounded-2xl border border-sand bg-white px-4 py-3.5 text-sm font-normal normal-case tracking-normal focus:border-gold focus:outline-none"
              />
            </label>

            <label className="block text-[11px] font-semibold uppercase tracking-[0.14em] text-ink/55 sm:col-span-2">
              Description (optional)
              <input
                value={draft.description}
                onChange={(event) =>
                  setDraft({ ...draft, description: event.target.value })
                }
                placeholder="Short line shown on the storefront"
                className="mt-2 w-full rounded-2xl border border-sand bg-white px-4 py-3.5 text-sm font-normal normal-case tracking-normal focus:border-gold focus:outline-none"
              />
            </label>

            <label className="block text-[11px] font-semibold uppercase tracking-[0.14em] text-ink/55 sm:col-span-2">
              Image path (optional)
              <input
                value={draft.image}
                onChange={(event) =>
                  setDraft({ ...draft, image: event.target.value })
                }
                placeholder="/api/images/your-upload.png"

                className="mt-2 w-full rounded-2xl border border-sand bg-white px-4 py-3.5 text-sm font-normal normal-case tracking-normal focus:border-gold focus:outline-none"
              />
              <span className="mt-1.5 block text-[11px] font-normal normal-case tracking-normal text-ink/50">
                Upload an image from Settings → Brand first, then paste its
                /api/images/… path here.
              </span>
            </label>

            <div className="sm:col-span-2">
              <button
                type="button"
                onClick={() => setDraft({ ...draft, isActive: !draft.isActive })}
                className={cn(
                  "flex w-full items-center justify-between gap-4 rounded-2xl border px-5 py-4 text-left transition",
                  draft.isActive
                    ? "border-forest-800 bg-cream-deep"
                    : "border-sand bg-white",
                )}
              >
                <span>
                  <span className="block text-sm font-semibold text-forest-900">
                    Visible on storefront
                  </span>
                  <span className="block text-xs text-ink/55">
                    Disabled categories are hidden from customers but keep their
                    products.
                  </span>
                </span>
                <span
                  className={cn(
                    "grid h-6 w-11 shrink-0 items-center rounded-full px-0.5 transition",
                    draft.isActive ? "bg-forest-800" : "bg-sand",
                  )}
                >
                  <span
                    className={cn(
                      "h-5 w-5 rounded-full bg-white transition",
                      draft.isActive && "translate-x-5",
                    )}
                  />
                </span>
              </button>
            </div>
          </div>

          <div className="mt-6 flex flex-wrap gap-2">
            <button
              type="button"
              onClick={saveDraft}
              disabled={busyId !== null}
              className="rounded-full bg-forest-800 px-6 py-3.5 text-sm font-semibold text-cream transition hover:bg-forest-700 disabled:opacity-60"
            >
              {busyId !== null ? "Saving…" : draft.id ? "Save changes" : "Create category"}
            </button>
            <button
              type="button"
              onClick={() => setDraft(null)}
              className="rounded-full border border-sand bg-white px-6 py-3.5 text-sm font-semibold text-forest-800 transition hover:border-gold"
            >
              Cancel
            </button>
          </div>
        </div>
      ) : null}

      {categories.length === 0 ? (
        <div className="rounded-[1.5rem] border border-dashed border-sand bg-white px-6 py-16 text-center">
          <h2 className="font-display text-2xl text-forest-900">
            No categories yet
          </h2>
          <p className="mx-auto mt-2 max-w-md text-sm text-ink/55">
            Create your first category — for example Men, Women, Skincare or
            Health &amp; Fitness — then assign products to it.
          </p>
        </div>
      ) : (
        <ul className="space-y-3">
          {categories.map((category) => (
            <li
              key={category.id}
              className={cn(
                "rounded-[1.5rem] border bg-white p-4 sm:p-5",
                category.isActive ? "border-sand" : "border-dashed border-sand opacity-70",
              )}
            >
              <div className="flex flex-wrap items-center gap-4">
                <div className="relative h-16 w-16 shrink-0 overflow-hidden rounded-2xl bg-forest-800">
                  <ProductImage
                    src={category.image}
                    alt={category.name}
                    name={category.name}
                    sizes="64px"
                  />
                </div>

                <div className="min-w-0 flex-1">
                  <div className="flex flex-wrap items-center gap-2">
                    <span className="font-display text-xl text-forest-900">
                      {category.name}
                    </span>
                    {!category.isActive ? (
                      <span className="rounded-full bg-ink/10 px-2.5 py-1 text-[10px] font-bold uppercase tracking-[0.12em] text-ink/60">
                        Hidden
                      </span>
                    ) : null}
                    <span className="rounded-full bg-cream-deep px-2.5 py-1 text-[10px] font-semibold text-forest-800">
                      {category.productCount}{" "}
                      {category.productCount === 1 ? "product" : "products"}
                    </span>
                    <span className="text-[10px] uppercase tracking-[0.14em] text-ink/40">
                      position {category.sortOrder}
                    </span>
                  </div>
                  {category.description ? (
                    <p className="mt-1 line-clamp-1 text-xs text-ink/55">
                      {category.description}
                    </p>
                  ) : null}
                </div>

                <div className="flex shrink-0 flex-wrap items-center gap-2">
                  <button
                    type="button"
                    onClick={() => move(category, -1)}
                    disabled={busyId === category.id}
                    className="grid h-10 w-10 place-items-center rounded-full border border-sand text-forest-800 transition hover:border-gold disabled:opacity-50"
                    aria-label={`Move ${category.name} up`}
                  >
                    ↑
                  </button>
                  <button
                    type="button"
                    onClick={() => move(category, 1)}
                    disabled={busyId === category.id}
                    className="grid h-10 w-10 place-items-center rounded-full border border-sand text-forest-800 transition hover:border-gold disabled:opacity-50"
                    aria-label={`Move ${category.name} down`}
                  >
                    ↓
                  </button>
                  <button
                    type="button"
                    onClick={() =>
                      setDraft({
                        id: category.id,
                        name: category.name,
                        description: category.description,
                        image: category.image,
                        isActive: category.isActive,
                        sortOrder: category.sortOrder,
                      })
                    }
                    className="rounded-full bg-forest-800 px-5 py-2.5 text-xs font-semibold text-cream transition hover:bg-forest-700"
                  >
                    Edit
                  </button>
                  <button
                    type="button"
                    onClick={() => toggle(category)}
                    disabled={busyId === category.id}
                    className="rounded-full border border-sand bg-white px-5 py-2.5 text-xs font-semibold text-forest-800 transition hover:border-gold disabled:opacity-50"
                  >
                    {category.isActive ? "Disable" : "Enable"}
                  </button>
                  <Link
                    href={`/category/${category.slug}`}
                    className="rounded-full px-4 py-2.5 text-xs font-semibold text-moss underline underline-offset-4"
                  >
                    View
                  </Link>
                  {confirmId === category.id ? (
                    <span className="flex items-center gap-2 rounded-full bg-red-50 px-3 py-1.5">
                      <span className="text-xs font-semibold text-red-700">Delete?</span>
                      <button
                        type="button"
                        onClick={() => remove(category)}
                        disabled={busyId === category.id}
                        className="rounded-full bg-red-600 px-3 py-1.5 text-[11px] font-semibold text-white disabled:opacity-50"
                      >
                        Yes
                      </button>
                      <button
                        type="button"
                        onClick={() => setConfirmId(null)}
                        className="rounded-full border border-sand bg-white px-3 py-1.5 text-[11px] font-semibold text-forest-800"
                      >
                        No
                      </button>
                    </span>
                  ) : (
                    <button
                      type="button"
                      onClick={() => setConfirmId(category.id)}
                      className="rounded-full px-4 py-2.5 text-xs font-semibold text-red-600 transition hover:bg-red-50"
                    >
                      Delete
                    </button>
                  )}
                </div>
              </div>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
