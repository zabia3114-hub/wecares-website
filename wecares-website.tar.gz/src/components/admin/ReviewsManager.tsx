"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { useMemo, useState } from "react";
import { cn, formatDate } from "@/lib/format";
import {
  REVIEW_STATUSES,
  REVIEW_STATUS_LABELS,
  type ReviewStatus,
} from "@/lib/status";

export type AdminReviewItem = {
  id: number;
  productId: number;
  productName: string;
  productSlug: string;
  authorName: string;
  authorMobile: string;
  rating: number;
  title: string;
  body: string;
  status: string;
  isVerifiedBuyer: boolean;
  createdAt: string;
};

const STATUS_STYLES: Record<string, string> = {
  pending: "bg-[#8a6a12]/15 text-[#8a6a12]",
  approved: "bg-moss/15 text-moss",
  hidden: "bg-ink/10 text-ink/60",
};

function Stars({ rating }: { rating: number }) {
  return (
    <span className="inline-flex gap-0.5" aria-label={`${rating} out of 5 stars`}>
      {[1, 2, 3, 4, 5].map((star) => (
        <span
          key={star}
          className={star <= rating ? "text-gold" : "text-sand"}
          aria-hidden
        >
          ★
        </span>
      ))}
    </span>
  );
}

export function ReviewsManager({ reviews }: { reviews: AdminReviewItem[] }) {
  const router = useRouter();
  const [filter, setFilter] = useState<"all" | ReviewStatus>("all");
  const [busyId, setBusyId] = useState<number | null>(null);
  const [message, setMessage] = useState<{ kind: "ok" | "error"; text: string } | null>(
    null,
  );
  const [confirmId, setConfirmId] = useState<number | null>(null);

  const counts = useMemo(() => {
    const map: Record<string, number> = { all: reviews.length };
    for (const review of reviews) {
      map[review.status] = (map[review.status] ?? 0) + 1;
    }
    return map;
  }, [reviews]);

  const visible =
    filter === "all" ? reviews : reviews.filter((r) => r.status === filter);

  async function act(review: AdminReviewItem, action: string, status?: string) {
    setBusyId(review.id);
    setMessage(null);
    try {
      const response = await fetch("/api/admin/mutations", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action, id: review.id, status }),
      });
      const payload = (await response.json()) as { ok?: boolean; error?: string };
      if (!response.ok || !payload.ok) {
        throw new Error(payload.error ?? "Action failed");
      }
      const labels: Record<string, string> = {
        "review-status:approved": "Review approved and now visible in the store.",
        "review-status:hidden": "Review hidden from the store.",
        "review-status:pending": "Review moved back to pending.",
        "review-delete": "Review deleted permanently.",
      };
      setMessage({
        kind: "ok",
        text: labels[`${action}:${status ?? ""}`] ?? "Done.",
      });
      router.refresh();
    } catch (error) {
      setMessage({
        kind: "error",
        text: error instanceof Error ? error.message : "Action failed",
      });
    } finally {
      setBusyId(null);
      setConfirmId(null);
    }
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="font-display text-3xl text-forest-900 sm:text-4xl">
          Reviews
        </h1>
        <p className="mt-2 text-sm text-ink/60">
          {reviews.length} total · {counts.pending ?? 0} awaiting your approval.
          Only approved reviews are visible to shoppers.
        </p>
      </div>

      {message ? (
        <p
          className={cn(
            "rounded-2xl px-4 py-3 text-sm font-medium",
            message.kind === "ok"
              ? "bg-moss/12 text-moss"
              : "bg-red-50 text-red-700",
          )}
        >
          {message.text}
        </p>
      ) : null}

      <div className="flex flex-wrap gap-2">
        {(["all", ...REVIEW_STATUSES] as const).map((value) => (
          <button
            key={value}
            type="button"
            onClick={() => setFilter(value)}
            className={cn(
              "rounded-full px-4 py-2.5 text-xs font-semibold transition",
              filter === value
                ? "bg-forest-800 text-cream"
                : "border border-sand bg-white text-ink/65 hover:border-gold",
            )}
          >
            {value === "all" ? "All" : REVIEW_STATUS_LABELS[value]}
            <span className="ml-1.5 opacity-60">{counts[value] ?? 0}</span>
          </button>
        ))}
      </div>

      {visible.length === 0 ? (
        <div className="rounded-[1.5rem] border border-dashed border-sand bg-white px-6 py-16 text-center">
          <h2 className="font-display text-2xl text-forest-900">
            No reviews here
          </h2>
          <p className="mx-auto mt-2 max-w-md text-sm leading-relaxed text-ink/55">
            When customers leave a review on a product page it lands here as
            Pending. Approve it to make it public, hide it, or delete it.
          </p>
        </div>
      ) : (
        <ul className="space-y-4">
          {visible.map((review) => (
            <li
              key={review.id}
              className="rounded-[1.5rem] border border-sand bg-white p-5"
            >
              <div className="flex flex-wrap items-start justify-between gap-3">
                <div className="min-w-0">
                  <div className="flex flex-wrap items-center gap-2">
                    <span className="font-display text-lg text-forest-900">
                      {review.authorName}
                    </span>
                    <span
                      className={cn(
                        "rounded-full px-2.5 py-1 text-[10px] font-bold uppercase tracking-[0.12em]",
                        STATUS_STYLES[review.status] ?? "bg-cream text-ink/60",
                      )}
                    >
                      {REVIEW_STATUS_LABELS[
                        review.status as ReviewStatus
                      ] ?? review.status}
                    </span>
                    {review.isVerifiedBuyer ? (
                      <span className="rounded-full bg-forest-800 px-2.5 py-1 text-[10px] font-bold uppercase tracking-[0.1em] text-gold-soft">
                        Verified buyer
                      </span>
                    ) : null}
                  </div>
                  <p className="mt-1 text-xs text-ink/55">
                    {formatDate(review.createdAt)} ·{" "}
                    <Link
                      href={`/products/${review.productSlug}`}
                      className="underline underline-offset-2 hover:text-moss"
                    >
                      {review.productName}
                    </Link>
                    {review.authorMobile ? ` · ${review.authorMobile}` : ""}
                  </p>
                </div>
                <Stars rating={review.rating} />
              </div>

              {review.title ? (
                <p className="mt-3 font-display text-base text-forest-900">
                  {review.title}
                </p>
              ) : null}
              <p className="mt-1.5 text-sm leading-relaxed text-ink/75">
                {review.body}
              </p>

              {confirmId === review.id ? (
                <div className="mt-4 rounded-2xl border border-red-200 bg-red-50 p-4">
                  <p className="text-sm font-semibold text-red-800">
                    Delete this review permanently?
                  </p>
                  <p className="mt-1 text-xs text-red-700">
                    This cannot be undone. Use Hide instead to keep it but remove
                    it from the store.
                  </p>
                  <div className="mt-3 flex flex-wrap gap-2">
                    <button
                      type="button"
                      disabled={busyId === review.id}
                      onClick={() => act(review, "review-delete")}
                      className="rounded-full bg-red-600 px-5 py-2.5 text-xs font-semibold text-white transition hover:bg-red-700 disabled:opacity-50"
                    >
                      Yes, delete
                    </button>
                    <button
                      type="button"
                      onClick={() => setConfirmId(null)}
                      className="rounded-full border border-sand bg-white px-5 py-2.5 text-xs font-semibold text-forest-800"
                    >
                      Cancel
                    </button>
                  </div>
                </div>
              ) : (
                <div className="mt-4 flex flex-wrap gap-2">
                  {review.status !== "approved" ? (
                    <button
                      type="button"
                      disabled={busyId === review.id}
                      onClick={() =>
                        act(review, "review-status", "approved")
                      }
                      className="rounded-full bg-moss px-5 py-2.5 text-xs font-semibold text-cream transition hover:brightness-110 disabled:opacity-50"
                    >
                      Approve
                    </button>
                  ) : null}

                  {review.status !== "hidden" ? (
                    <button
                      type="button"
                      disabled={busyId === review.id}
                      onClick={() => act(review, "review-status", "hidden")}
                      className="rounded-full border border-sand bg-white px-5 py-2.5 text-xs font-semibold text-forest-800 transition hover:border-gold disabled:opacity-50"
                    >
                      {review.status === "approved" ? "Hide" : "Hide"}
                    </button>
                  ) : (
                    <button
                      type="button"
                      disabled={busyId === review.id}
                      onClick={() => act(review, "review-status", "pending")}
                      className="rounded-full border border-sand bg-white px-5 py-2.5 text-xs font-semibold text-forest-800 transition hover:border-gold disabled:opacity-50"
                    >
                      Unhide (set pending)
                    </button>
                  )}

                  <button
                    type="button"
                    disabled={busyId === review.id}
                    onClick={() => setConfirmId(review.id)}
                    className="rounded-full px-5 py-2.5 text-xs font-semibold text-red-600 transition hover:bg-red-50 disabled:opacity-50"
                  >
                    Delete
                  </button>
                </div>
              )}
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
