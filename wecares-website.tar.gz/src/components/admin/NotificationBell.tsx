"use client";

import Link from "next/link";
import { useCallback, useEffect, useRef, useState } from "react";
import { cn } from "@/lib/format";

type NotificationRow = {
  id: number;
  title: string;
  body: string;
  orderNumber: string | null;
  createdAt: string;
};

/**
 * Order-alert bell. Polls the server, shows an unread badge, and plays a sound
 * plus a browser notification when a genuinely new order arrives.
 */
export function NotificationBell() {
  const [open, setOpen] = useState(false);
  const [unreadCount, setUnreadCount] = useState(0);
  const [items, setItems] = useState<NotificationRow[]>([]);
  const [loading, setLoading] = useState(true);
  const [soundOn, setSoundOn] = useState(true);
  const seen = useRef<Set<string>>(new Set());
  const initialised = useRef(false);
  const audioCtx = useRef<AudioContext | null>(null);

  const playChime = useCallback(() => {
    if (!soundOn) return;
    try {
      type Ctor = typeof AudioContext;
      const Ctx: Ctor | undefined =
        window.AudioContext ??
        (window as unknown as { webkitAudioContext?: Ctor }).webkitAudioContext;
      if (!Ctx) return;
      audioCtx.current = audioCtx.current ?? new Ctx();
      const ctx = audioCtx.current;
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.type = "sine";
      osc.frequency.setValueAtTime(880, ctx.currentTime);
      osc.frequency.setValueAtTime(1180, ctx.currentTime + 0.12);
      gain.gain.setValueAtTime(0.0001, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.18, ctx.currentTime + 0.02);
      gain.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + 0.5);
      osc.start();
      osc.stop(ctx.currentTime + 0.52);
    } catch {
      /* audio unavailable — silent fallback */
    }
  }, [soundOn]);

  const load = useCallback(
    async (announce: boolean) => {
      try {
        const response = await fetch("/api/admin/notifications", {
          cache: "no-store",
        });
        if (!response.ok) return;
        const data = (await response.json()) as {
          ok?: boolean;
          unreadCount?: number;
          latest?: NotificationRow[];
        };
        if (!data.ok) return;

        const nextCount = data.unreadCount ?? 0;
        const latest = data.latest ?? [];
        setUnreadCount(nextCount);
        setItems(latest);

        // Only announce orders we have not seen in this browser session, and
        // never on the very first load (that would beep on every page open).
        const fresh = latest.filter(
          (row) => !seen.current.has(String(row.id)),
        );
        latest.forEach((row) => seen.current.add(String(row.id)));

        if (initialised.current && announce && fresh.length > 0) {
          playChime();
          if (typeof Notification !== "undefined" && Notification.permission === "granted") {
            for (const row of fresh.slice(0, 3)) {
              try {
                new Notification("We Cares — new order", {
                  body: row.title,
                  tag: String(row.id),
                });
              } catch {
                /* notification blocked */
              }
            }
          }
        }
        initialised.current = true;
      } catch {
        /* network hiccup — retry on the next poll */
      } finally {
        setLoading(false);
      }
    },
    [playChime],
  );

  useEffect(() => {
    void load(true);
    const timer = setInterval(() => void load(true), 20000);
    return () => clearInterval(timer);
  }, [load]);

  // Ask for browser-notification permission the first time an admin opens the bell.
  function requestPermission() {
    if (typeof Notification !== "undefined" && Notification.permission === "default") {
      void Notification.requestPermission();
    }
  }

  async function markAllRead() {
    const response = await fetch("/api/admin/notifications", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({}),
    });
    if (response.ok) {
      const data = (await response.json()) as { unreadCount?: number };
      setUnreadCount(data.unreadCount ?? 0);
    }
  }

  return (
    <div className="relative">
      <button
        type="button"
        onClick={() => {
          setOpen((value) => !value);
          requestPermission();
        }}
        className="relative grid h-10 w-10 place-items-center rounded-full border border-gold/30 text-gold transition hover:bg-gold/10"
        aria-label={`Notifications${unreadCount ? ` (${unreadCount} unread)` : ""}`}
      >
        <svg viewBox="0 0 24 24" className="h-4.5 w-4.5" aria-hidden fill="none">
          <path
            d="M6 9a6 6 0 1112 0v4l1.5 3H4.5L6 13V9zM10 19a2 2 0 004 0"
            stroke="currentColor"
            strokeWidth="1.6"
            strokeLinecap="round"
            strokeLinejoin="round"
          />
        </svg>
        {unreadCount > 0 ? (
          <span className="absolute -right-0.5 -top-0.5 grid h-5 min-w-5 place-items-center rounded-full bg-[#25D366] px-1 text-[10px] font-bold text-forest-950">
            {unreadCount > 9 ? "9+" : unreadCount}
          </span>
        ) : null}
      </button>

      {open ? (
        <>
          <button
            type="button"
            aria-label="Close notifications"
            onClick={() => setOpen(false)}
            className="fixed inset-0 z-40 cursor-default"
          />
          <div className="absolute right-0 z-50 mt-2 w-[21rem] max-w-[calc(100vw-2rem)] overflow-hidden rounded-2xl border border-sand bg-white shadow-lift">
            <div className="flex items-center justify-between border-b border-sand px-4 py-3">
              <p className="text-sm font-semibold text-forest-900">Alerts</p>
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => setSoundOn((value) => !value)}
                  className="rounded-full border border-sand px-2.5 py-1 text-[10px] font-semibold text-forest-800"
                  aria-pressed={soundOn}
                >
                  {soundOn ? "Sound on" : "Sound off"}
                </button>
                {unreadCount > 0 ? (
                  <button
                    type="button"
                    onClick={() => void markAllRead()}
                    className="text-[10px] font-semibold text-moss underline underline-offset-2"
                  >
                    Mark all read
                  </button>
                ) : null}
              </div>
            </div>

            <div className="max-h-80 overflow-y-auto">
              {loading ? (
                <div className="space-y-3 p-4">
                  {[0, 1, 2].map((row) => (
                    <div key={row} className="skeleton h-12 rounded-xl" />
                  ))}
                </div>
              ) : items.length === 0 ? (
                <p className="px-4 py-10 text-center text-sm text-ink/55">
                  No alerts yet. You will hear a chime here whenever a customer
                  places an order.
                </p>
              ) : (
                <ul className="divide-y divide-sand">
                  {items.map((row) => (
                    <li key={row.id} className="px-4 py-3">
                      <div className="flex items-start justify-between gap-2">
                        <p
                          className={cn(
                            "text-sm font-semibold",
                            unreadCount > 0 ? "text-forest-900" : "text-ink/75",
                          )}
                        >
                          {row.title}
                        </p>
                      </div>
                      <p className="mt-0.5 text-xs leading-relaxed text-ink/60">
                        {row.body}
                      </p>
                      <div className="mt-1.5 flex items-center gap-3">
                        {row.orderNumber ? (
                          <Link
                            href="/admin/orders"
                            className="text-[11px] font-semibold text-moss underline underline-offset-2"
                          >
                            Open orders
                          </Link>
                        ) : null}
                        <span className="text-[11px] text-ink/40">
                          {new Date(row.createdAt).toLocaleString("en-GB", {
                            day: "numeric",
                            month: "short",
                            hour: "2-digit",
                            minute: "2-digit",
                          })}
                        </span>
                      </div>
                    </li>
                  ))}
                </ul>
              )}
            </div>
          </div>
        </>
      ) : null}
    </div>
  );
}
