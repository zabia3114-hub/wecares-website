"use client";

import { useRouter } from "next/navigation";
import { useRef, useState } from "react";
import { ProductImage } from "@/components/ProductImage";
import { cn, formatPkr } from "@/lib/format";

export type ProductFormState = {
  slug: string;
  categoryId?: number | string;
  name: string;
  subtitle: string;
  description: string;
  howToUse: string;
  disclaimer: string;
  collectionSlug: string;
  categoryLabel: string;
  priceRupees: number | string;
  compareAtRupees: number | string;
  image: string;
  highlights: string;
  ingredients: string;
  netWeight: string;
  suitability: string;
  isFeatured: boolean;
  isBestseller: boolean;
  isActive: boolean;
  stock: number | string;
  sortOrder: number | string;
};

export function ProductEditor({
  mode,
  productId,
  initial,
  collections,
  categories = [],
}: {
  mode: "create" | "edit";
  productId?: number;
  initial: ProductFormState;
  collections: Array<{ slug: string; name: string }>;
  categories?: Array<{ id: number; name: string }>;
}) {
  const router = useRouter();
  // Normalise once so no call site can ever send an unrecognised action.
  const actionName: "create" | "update" = mode === "create" ? "create" : "update";
  const [form, setForm] = useState<ProductFormState>(initial);
  const [uploading, setUploading] = useState(false);
  const [saving, setSaving] = useState(false);
  const [message, setMessage] = useState<{ kind: "ok" | "error"; text: string } | null>(
    null,
  );
  const fileInput = useRef<HTMLInputElement>(null);

  const set = <K extends keyof ProductFormState>(
    key: K,
    value: ProductFormState[K],
  ) => setForm((current) => ({ ...current, [key]: value }));

  const price = Number(form.priceRupees) || 0;
  const compareAt = Number(form.compareAtRupees) || 0;

  async function uploadFile(file: File) {
    setUploading(true);
    setMessage(null);

    // Allow choosing the same file again later: without this the browser
    // fires no change event if the path is unchanged.
    if (fileInput.current) fileInput.current.value = "";

    if (file.size > 6 * 1024 * 1024) {
      setMessage({
        kind: "error",
        text: `That image is ${(file.size / 1024 / 1024).toFixed(1)} MB. Please use a photo under 6 MB.`,
      });
      setUploading(false);
      return;
    }

    try {
      const data = new FormData();
      data.append("file", file);
      // Default the stored filename to the product slug so uploads stay tidy.
      data.append("filename", form.slug || form.name);
      const response = await fetch("/api/admin/upload", {
        method: "POST",
        body: data,
      });
      const payload = (await response.json()) as {
        ok?: boolean;
        url?: string;
        error?: string;
      };
      if (!response.ok || !payload.ok || !payload.url) {
        // Surface the server's real reason instead of hiding it.
        throw new Error(
          payload.error ??
            `Upload failed (server said ${response.status}). Please try a different photo.`,
        );
      }

      // Verify the stored image actually loads before claiming success. This is
      // what stops a silent placeholder from masquerading as a real upload.
      const loads = await new Promise<boolean>((resolve) => {
        const probe = new Image();
        const timer = setTimeout(() => resolve(false), 12000);
        probe.onload = () => {
          clearTimeout(timer);
          resolve(true);
        };
        probe.onerror = () => {
          clearTimeout(timer);
          resolve(false);
        };
        probe.src = payload.url as string;
      });

      if (!loads) {
        throw new Error(
          "The uploaded file was stored but could not be displayed. Please try a standard JPG or PNG photo.",
        );
      }

      set("image", payload.url);
      setMessage({
        kind: "ok",
        text: "Photo uploaded. Saving it to the product…",
      });

      // Save immediately so the image is never lost if the page is closed
      // before the operator remembers to press Save.
      try {
        const saveResponse = await fetch("/api/admin/mutations", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            // Be explicit: the editor is either creating or updating, and the
            // server only understands those two words.
            action: actionName,
            id: productId,
            product: {
              ...form,
              image: payload.url,
              priceRupees: price,
              compareAtRupees: compareAt || null,
              stock: Number(form.stock) || 0,
              sortOrder: Number(form.sortOrder) || 99,
            },
          }),
        });
        const saveData = (await saveResponse.json()) as {
          ok?: boolean;
          error?: string;
        };
        if (!saveResponse.ok || !saveData.ok) {
          throw new Error(saveData.error ?? "Could not save the product");
        }
        setMessage({
          kind: "ok",
          text: "Photo uploaded and saved to this product. Done!",
        });
      } catch (saveError) {
        setMessage({
          kind: "error",
          text:
            saveError instanceof Error
              ? `Photo uploaded, but saving failed: ${saveError.message}. Please press "Save product" at the top.`
              : "Photo uploaded, but saving failed. Please press Save product.",
        });
      }
    } catch (error) {
      setMessage({
        kind: "error",
        text: error instanceof Error ? error.message : "Upload failed",
      });
    } finally {
      setUploading(false);
    }
  }

  async function save(event: React.FormEvent) {
    event.preventDefault();
    setSaving(true);
    setMessage(null);
    try {
      const response = await fetch("/api/admin/mutations", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          // The API only understands "create" and "update" — the raw mode
          // string ("edit") is not a valid action and was rejected as
          // "Unknown action".
          action: actionName,
          id: productId,
          product: {
            ...form,
            priceRupees: price,
            compareAtRupees: compareAt || null,
            stock: Number(form.stock) || 0,
            sortOrder: Number(form.sortOrder) || 99,
          },
        }),
      });
      const payload = (await response.json()) as {
        ok?: boolean;
        error?: string;
        product?: { id: number };
      };
      if (!response.ok || !payload.ok) {
        throw new Error(payload.error ?? "Could not save");
      }
      router.push("/admin/products");
      router.refresh();
    } catch (error) {
      setMessage({
        kind: "error",
        text: error instanceof Error ? error.message : "Could not save",
      });
      setSaving(false);
    }
  }

  return (
    <form onSubmit={save} className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <h1 className="font-display text-3xl text-forest-900 sm:text-4xl">
          {mode === "create" ? "Add product" : "Edit product"}
        </h1>
        <div className="flex gap-2">
          <button
            type="button"
            onClick={() => router.push("/admin/products")}
            className="rounded-full border border-sand bg-white px-5 py-3 text-sm font-semibold text-forest-800 transition hover:border-gold"
          >
            Cancel
          </button>
          <button
            type="submit"
            disabled={saving || uploading}
            className="rounded-full bg-gold px-6 py-3 text-sm font-semibold text-forest-950 transition hover:bg-gold-soft disabled:opacity-60"
          >
            {saving ? "Saving…" : "Save product"}
          </button>
        </div>
      </div>

      {message ? (
        <p
          className={cn(
            "rounded-2xl px-4 py-3 text-sm font-medium",
            message.kind === "ok" ? "bg-moss/12 text-moss" : "bg-rose-50 text-red-700",
          )}
        >
          {message.text}
        </p>
      ) : null}

      <div className="grid gap-6 lg:grid-cols-[1.5fr_1fr]">
        <div className="space-y-5 rounded-[1.5rem] border border-sand bg-white p-6">
          <Text
            label="Product name"
            value={form.name}
            onChange={(value) => set("name", value)}
            required
          />
          <Text
            label="Short description (shown under the name)"
            value={form.subtitle}
            onChange={(value) => set("subtitle", value)}
          />

          <label className="block text-[11px] font-semibold uppercase tracking-[0.14em] text-ink/55">
            Full description
            <textarea
              rows={4}
              value={form.description}
              onChange={(event) => set("description", event.target.value)}
              className="mt-2 w-full rounded-2xl border border-sand bg-white px-4 py-3.5 text-sm font-normal normal-case tracking-normal focus:border-gold focus:outline-none"
            />
          </label>

          <label className="block text-[11px] font-semibold uppercase tracking-[0.14em] text-ink/55">
            How to use
            <textarea
              rows={3}
              value={form.howToUse}
              onChange={(event) => set("howToUse", event.target.value)}
              className="mt-2 w-full rounded-2xl border border-sand bg-white px-4 py-3.5 text-sm font-normal normal-case tracking-normal focus:border-gold focus:outline-none"
            />
          </label>

          <label className="block text-[11px] font-semibold uppercase tracking-[0.14em] text-ink/55">
            Ingredients (one per line)
            <textarea
              rows={4}
              value={form.ingredients}
              onChange={(event) => set("ingredients", event.target.value)}
              className="mt-2 w-full rounded-2xl border border-sand bg-white px-4 py-3.5 text-sm font-normal normal-case tracking-normal focus:border-gold focus:outline-none"
            />
          </label>

          <label className="block text-[11px] font-semibold uppercase tracking-[0.14em] text-ink/55">
            Key highlights (one per line)
            <textarea
              rows={3}
              value={form.highlights}
              onChange={(event) => set("highlights", event.target.value)}
              className="mt-2 w-full rounded-2xl border border-sand bg-white px-4 py-3.5 text-sm font-normal normal-case tracking-normal focus:border-gold focus:outline-none"
            />
          </label>

          <label className="block text-[11px] font-semibold uppercase tracking-[0.14em] text-ink/55">
            Important information / disclaimer
            <textarea
              rows={3}
              value={form.disclaimer}
              onChange={(event) => set("disclaimer", event.target.value)}
              className="mt-2 w-full rounded-2xl border border-sand bg-white px-4 py-3.5 text-sm font-normal normal-case tracking-normal focus:border-gold focus:outline-none"
            />
          </label>
        </div>

        <div className="space-y-5">
          {/* Pricing */}
          <section className="rounded-[1.5rem] border border-gold/30 bg-cream-deep p-6">
            <h2 className="font-display text-lg text-forest-900">Pricing</h2>
            <div className="mt-4 space-y-4">
              <Text
                label="Sale price (Rs.)"
                value={form.priceRupees}
                onChange={(value) => set("priceRupees", value)}
                inputMode="numeric"
                required
              />
              <Text
                label="Original price (Rs.) — optional"
                value={form.compareAtRupees}
                onChange={(value) => set("compareAtRupees", value)}
                inputMode="numeric"
                hint="Shown crossed out. Leave blank for no discount badge."
              />
              <div className="rounded-2xl bg-white px-4 py-3 text-sm">
                <p className="text-ink/55">Preview</p>
                <p className="mt-1">
                  <span className="font-display text-xl font-semibold text-forest-900">
                    {formatPkr(price * 100)}
                  </span>
                  {compareAt > price ? (
                    <span className="ml-2 text-sm text-ink/45 line-through">
                      {formatPkr(compareAt * 100)}
                    </span>
                  ) : null}
                </p>
                {compareAt > price ? (
                  <p className="mt-1 text-xs font-semibold text-moss">
                    Save{" "}
                    {Math.round(((compareAt - price) / compareAt) * 100)}%
                  </p>
                ) : null}
              </div>
            </div>
          </section>

          {/* Image */}
          <section className="rounded-[1.5rem] border border-sand bg-white p-6">
            <h2 className="font-display text-lg text-forest-900">Product image</h2>

            {/*
              The input stays in the layout at 1px (opacity 0) rather than
              `display:none` / `sr-only`, because a zero-size or hidden input
              will not open the file picker when its <label> is tapped on many
              mobile browsers. The wrapping <label> makes the whole preview
              panel tappable.
            */}
            <label
              htmlFor="product-image-input"
              className="block cursor-pointer"
            >
              <div className="relative aspect-square w-full max-w-[220px] overflow-hidden rounded-2xl border border-dashed border-gold/60 bg-forest-800">
                <ProductImage
                  src={form.image}
                  alt={form.name || "Product"}
                  name={form.name || "Product"}
                  netWeight={form.netWeight}
                  showError
                />
                <span className="absolute inset-x-0 bottom-0 bg-forest-950/70 px-3 py-2 text-center text-[11px] font-semibold text-cream">
                  Tap to change photo
                </span>
              </div>
            </label>

            <input
              ref={fileInput}
              id="product-image-input"
              type="file"
              accept="image/*"
              onChange={(event) => {
                const file = event.target.files?.[0];
                if (file) void uploadFile(file);
              }}
              style={{
                position: "absolute",
                width: 1,
                height: 1,
                opacity: 0,
                overflow: "hidden",
              }}
              tabIndex={-1}
            />

            <div className="mt-4 space-y-2.5">
              <label
                htmlFor="product-image-input"
                className="block w-full cursor-pointer rounded-full bg-forest-800 px-5 py-4 text-center text-sm font-semibold text-cream transition hover:bg-forest-700"
              >
                {uploading ? "Uploading…" : "Choose photo"}
              </label>

              <Text
                label="Or paste an image path"
                value={form.image}
                onChange={(value) => set("image", value)}
                hint="/images/products/your-file.jpg"
              />

              <p className="text-[11px] leading-relaxed text-ink/50">
                Square images work best. Uploaded files are saved to
                public/images/products/.
              </p>
            </div>
          </section>

          {/* Organisation */}
          <section className="rounded-[1.5rem] border border-sand bg-white p-6">
            <h2 className="font-display text-lg text-forest-900">Details</h2>
            <div className="mt-4 space-y-4">
              <label className="block text-[11px] font-semibold uppercase tracking-[0.14em] text-ink/55">
                Category
                <select
                  value={String(form.categoryId ?? "")}
                  onChange={async (event) => {
                    const next = Number(event.target.value) || 0;
                    set("categoryId" as keyof ProductFormState, next as never);
                    if (mode !== "edit" || !productId) return;
                    // Persist immediately so assignment is never lost.
                    try {
                      await fetch("/api/admin/categories", {
                        method: "POST",
                        headers: { "Content-Type": "application/json" },
                        body: JSON.stringify({
                          action: "assign-product",
                          productId,
                          categoryId: next || null,
                        }),
                      });
                    } catch {
                      /* surfaced by the main Save action */
                    }
                  }}
                  className="mt-2 w-full rounded-2xl border border-sand bg-white px-4 py-3.5 text-sm font-normal normal-case tracking-normal focus:border-gold focus:outline-none"
                >
                  <option value="">Uncategorised</option>
                  {categories.map((category) => (
                    <option key={category.id} value={category.id}>
                      {category.name}
                    </option>
                  ))}
                </select>
                <span className="mt-1.5 block text-[11px] font-normal normal-case tracking-normal text-ink/50">
                  Customers see only products assigned to the chosen category.
                </span>
              </label>

              <label className="block text-[11px] font-semibold uppercase tracking-[0.14em] text-ink/55">
                Collection
                <select
                  value={form.collectionSlug}
                  onChange={(event) => set("collectionSlug", event.target.value)}
                  className="mt-2 w-full rounded-2xl border border-sand bg-white px-4 py-3.5 text-sm font-normal normal-case tracking-normal focus:border-gold focus:outline-none"
                >
                  <option value="">Choose…</option>
                  {collections.map((collection) => (
                    <option key={collection.slug} value={collection.slug}>
                      {collection.name}
                    </option>
                  ))}
                </select>
              </label>

              <Text
                label="Category label"
                value={form.categoryLabel}
                onChange={(value) => set("categoryLabel", value)}
                hint="e.g. Herbal Majoon, Herbal Oil"
              />
              <Text
                label="Net weight"
                value={form.netWeight}
                onChange={(value) => set("netWeight", value)}
                hint="e.g. 250g or 15ml"
              />
              <Text
                label="Suitable for"
                value={form.suitability}
                onChange={(value) => set("suitability", value)}
                hint="e.g. For men & women"
              />
              <Text
                label="Stock quantity"
                value={form.stock}
                onChange={(value) => set("stock", value)}
                inputMode="numeric"
              />
              <Text
                label="Display order"
                value={form.sortOrder}
                onChange={(value) => set("sortOrder", value)}
                inputMode="numeric"
                hint="Lower numbers appear first."
              />
              {mode === "create" ? (
                <Text
                  label="URL slug (optional)"
                  value={form.slug}
                  onChange={(value) => set("slug", value)}
                  hint="Leave blank to generate from the name."
                />
              ) : null}

              <div className="space-y-2.5 border-t border-sand pt-4">
                <Check
                  label="Visible in store"
                  checked={form.isActive}
                  onChange={(value) => set("isActive", value)}
                />
                <Check
                  label="Featured on home page"
                  checked={form.isFeatured}
                  onChange={(value) => set("isFeatured", value)}
                />
                <Check
                  label="Show 'Popular' badge"
                  checked={form.isBestseller}
                  onChange={(value) => set("isBestseller", value)}
                />
              </div>
            </div>
          </section>
        </div>
      </div>
    </form>
  );
}

function Text({
  label,
  value,
  onChange,
  hint,
  required,
  inputMode,
}: {
  label: string;
  value: string | number;
  onChange: (value: string) => void;
  hint?: string;
  required?: boolean;
  inputMode?: "text" | "numeric" | "tel";
}) {
  return (
    <label className="block text-[11px] font-semibold uppercase tracking-[0.14em] text-ink/55">
      {label}
      {required ? <span className="ml-1 text-moss">*</span> : null}
      <input
        value={value}
        inputMode={inputMode}
        required={required}
        onChange={(event) => onChange(event.target.value)}
        className="mt-2 w-full rounded-2xl border border-sand bg-white px-4 py-3.5 text-sm font-normal normal-case tracking-normal focus:border-gold focus:outline-none"
      />
      {hint ? (
        <span className="mt-1.5 block text-[11px] font-normal normal-case tracking-normal text-ink/50">
          {hint}
        </span>
      ) : null}
    </label>
  );
}

function Check({
  label,
  checked,
  onChange,
}: {
  label: string;
  checked: boolean;
  onChange: (value: boolean) => void;
}) {
  return (
    <label className="inline-flex cursor-pointer items-center gap-2.5 text-sm font-medium text-forest-900">
      <input
        type="checkbox"
        checked={checked}
        onChange={(event) => onChange(event.target.checked)}
        className="h-4 w-4 accent-forest-700"
      />
      {label}
    </label>
  );
}
