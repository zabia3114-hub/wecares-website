"use client";

import { useRouter } from "next/navigation";
import { useMemo, useState } from "react";
import { ProductImage } from "@/components/ProductImage";
import { cn, formatDate, formatPkr } from "@/lib/format";
import {
  ORDER_STATUSES,
  ORDER_STATUS_LABELS,
  normalizeOrderStatus,
} from "@/lib/status";

export type AdminOrder = {
  id: number;
  orderNumber: string;
  customerName: string;
  mobile: string;
  address: string;
  city: string;
  province: string;
  orderDetails: string;
  paymentMethod: string;
  shippingMethod: string;
  status: string;
  items: Array<{
    slug: string;
    name: string;
    image: string;
    quantity: number;
    unitPricePaisa: number;
  }>;
  subtotalPaisa: number;
  shippingPaisa: number;
  totalPaisa: number;
  createdAt: string;
};

const STATUSES = ORDER_STATUSES.map((value) => ({
  value,
  label: ORDER_STATUS_LABELS[value],
}));

const STATUS_STYLES: Record<string, string> = {
  new: "bg-[#8a6a12]/15 text-[#8a6a12]",
  confirmed: "bg-moss/15 text-moss",
  shipped: "bg-forest-800 text-cream",
  delivered: "bg-forest-900 text-gold-soft",
  cancelled: "bg-red-50 text-red-700",
};

function waNumber(mobile: string) {
  const digits = mobile.replace(/\D/g, "");
  if (digits.startsWith("0")) return `92${digits.slice(1)}`;
  return digits;
}

export function OrdersInbox({ orders }: { orders: AdminOrder[] }) {
  const router = useRouter();
  const [filter, setFilter] = useState<string>("all");
  const [busyId, setBusyId] = useState<number | null>(null);
  const [confirmDelete, setConfirmDelete] = useState<number | null>(null);
  const [openId, setOpenId] = useState<number | null>(
    orders[0]?.id ?? null,
  );

  const counts = useMemo(() => {
    const map: Record<string, number> = { all: orders.length };
    for (const order of orders) {
      map[order.status] = (map[order.status] ?? 0) + 1;
    }
    return map;
  }, [orders]);

  const revenue = orders
    .filter((order) => order.status !== "cancelled")
    .reduce((total, order) => total + order.totalPaisa, 0);

  const visible = filter === "all" ? orders : orders.filter((o) => o.status === filter);

  async function removeOrder(order: AdminOrder) {
    setBusyId(order.id);
    try {
      await fetch("/api/admin/mutations", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action: "order-delete", id: order.id }),
      });
      router.refresh();
    } finally {
      setBusyId(null);
      setConfirmDelete(null);
    }
  }

  async function setStatus(order: AdminOrder, status: string) {
    setBusyId(order.id);
    try {
      await fetch("/api/admin/mutations", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action: "order-status", id: order.id, status }),
      });
      router.refresh();
    } finally {
      setBusyId(null);
    }
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <h1 className="font-display text-3xl text-forest-900 sm:text-4xl">
            Orders
          </h1>
          <p className="mt-2 text-sm text-ink/60">
            {orders.length} order{orders.length === 1 ? "" : "s"} ·{" "}
            {formatPkr(revenue)} total revenue
          </p>
        </div>
      </div>

      <div className="flex flex-wrap gap-2">
        {[
          { value: "all", label: "All" },
          ...STATUSES.filter((status) => counts[status.value]),
        ].map((tab) => (
          <button
            key={tab.value}
            type="button"
            onClick={() => setFilter(tab.value)}
            className={cn(
              "rounded-full px-4 py-2.5 text-xs font-semibold transition",
              filter === tab.value
                ? "bg-forest-800 text-cream"
                : "border border-sand bg-white text-ink/65 hover:border-gold",
            )}
          >
            {tab.label}
            <span className="ml-1.5 opacity-60">
              {counts[tab.value] ?? 0}
            </span>
          </button>
        ))}
      </div>

      {visible.length === 0 ? (
        <div className="rounded-[1.5rem] border border-dashed border-sand bg-white px-6 py-16 text-center">
          <h2 className="font-display text-2xl text-forest-900">
            No orders here yet
          </h2>
          <p className="mx-auto mt-2 max-w-sm text-sm text-ink/55">
            Every order placed at checkout appears in this list automatically,
            with the customer&apos;s name, mobile number and delivery address.
          </p>
        </div>
      ) : (
        <ul className="space-y-4">
          {visible.map((order) => {
            const open = openId === order.id;
            return (
              <li
                key={order.id}
                className="overflow-hidden rounded-[1.5rem] border border-sand bg-white"
              >
                {/* Row header — always visible */}
                <div className="flex flex-wrap items-center gap-4 p-4 sm:p-5">
                  <button
                    type="button"
                    onClick={() => setOpenId(open ? null : order.id)}
                    className="min-w-0 flex-1 text-left"
                  >
                    <div className="flex flex-wrap items-center gap-2">
                      <span className="font-display text-lg text-forest-900">
                        {order.customerName}
                      </span>
                      <span
                        className={cn(
                          "rounded-full px-2.5 py-1 text-[10px] font-bold uppercase tracking-[0.12em]",
                          STATUS_STYLES[normalizeOrderStatus(order.status)] ??
                            "bg-cream text-ink/60",
                        )}
                      >
                        {ORDER_STATUS_LABELS[normalizeOrderStatus(order.status)]}
                      </span>
                    </div>
                    <p className="mt-1 text-xs text-ink/55">
                      {order.orderNumber} · {order.city} ·{" "}
                      {formatDate(order.createdAt)} ·{" "}
                      {order.paymentMethod === "cod"
                        ? "Cash on delivery"
                        : "Bank transfer"}
                    </p>
                  </button>

                  <div className="flex shrink-0 items-center gap-3">
                    <span className="font-display text-xl font-semibold text-forest-900">
                      {formatPkr(order.totalPaisa)}
                    </span>
                    <a
                      href={`https://wa.me/${waNumber(order.mobile)}`}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="rounded-full bg-[#25D366] px-4 py-2.5 text-xs font-semibold text-white transition hover:brightness-95"
                    >
                      WhatsApp
                    </a>
                    <a
                      href={`tel:+${waNumber(order.mobile)}`}
                      className="hidden rounded-full border border-sand px-4 py-2.5 text-xs font-semibold text-forest-800 transition hover:border-gold sm:block"
                    >
                      Call
                    </a>
                  </div>
                </div>

                {open ? (
                  <div className="animate-fade-in grid gap-6 border-t border-sand bg-cream p-5 lg:grid-cols-2">
                    <div>
                      <h3 className="text-[11px] font-semibold uppercase tracking-[0.16em] text-moss">
                        Items
                      </h3>
                      <ul className="mt-3 space-y-3">
                        {order.items.map((item) => (
                          <li key={item.slug} className="flex items-center gap-3">
                            <div className="relative h-14 w-12 shrink-0 overflow-hidden rounded-xl bg-forest-800">
                              <ProductImage
                                src={item.image}
                                alt={item.name}
                                name={item.name}
                                sizes="48px"
                              />
                            </div>
                            <div className="min-w-0 flex-1">
                              <p className="truncate text-sm font-medium text-forest-900">
                                {item.name}
                              </p>
                              <p className="text-xs text-ink/55">
                                {item.quantity} ×{" "}
                                {formatPkr(item.unitPricePaisa)}
                              </p>
                            </div>
                            <span className="shrink-0 text-sm font-semibold text-forest-900">
                              {formatPkr(item.unitPricePaisa * item.quantity)}
                            </span>
                          </li>
                        ))}
                      </ul>

                      <dl className="mt-4 space-y-1.5 border-t border-sand pt-4 text-sm">
                        <div className="flex justify-between text-ink/60">
                          <dt>Subtotal</dt>
                          <dd className="font-semibold text-forest-900">
                            {formatPkr(order.subtotalPaisa)}
                          </dd>
                        </div>
                        <div className="flex justify-between text-ink/60">
                          <dt>
                            Delivery (
                            {order.shippingMethod === "express"
                              ? "Express"
                              : "Standard"}
                            )
                          </dt>
                          <dd className="font-semibold text-forest-900">
                            {order.shippingPaisa === 0
                              ? "Free"
                              : formatPkr(order.shippingPaisa)}
                          </dd>
                        </div>
                        <div className="flex justify-between border-t border-sand pt-2">
                          <dt className="font-semibold text-forest-900">Total</dt>
                          <dd className="font-display text-xl text-forest-900">
                            {formatPkr(order.totalPaisa)}
                          </dd>
                        </div>
                      </dl>
                    </div>

                    <div>
                      <h3 className="text-[11px] font-semibold uppercase tracking-[0.16em] text-moss">
                        Delivery details
                      </h3>
                      <address className="mt-3 text-sm not-italic leading-relaxed text-ink/75">
                        <span className="font-semibold text-forest-900">
                          {order.customerName}
                        </span>
                        <br />
                        {order.mobile}
                        <br />
                        {order.address}
                        <br />
                        {order.city}
                        {order.province ? `, ${order.province}` : ""}
                      </address>

                      {order.orderDetails ? (
                        <div className="mt-4 rounded-2xl bg-white p-4">
                          <p className="text-[10px] font-semibold uppercase tracking-[0.14em] text-moss">
                            Customer notes
                          </p>
                          <p className="mt-1.5 text-sm text-ink/75">
                            {order.orderDetails}
                          </p>
                        </div>
                      ) : null}

                      {confirmDelete === order.id ? (
                        <div className="mt-5 rounded-2xl border border-red-200 bg-red-50 p-4">
                          <p className="text-sm font-semibold text-red-800">
                            Delete order {order.orderNumber} permanently?
                          </p>
                          <p className="mt-1 text-xs text-red-700">
                            This cannot be undone. Use Cancelled instead to keep
                            a record.
                          </p>
                          <div className="mt-3 flex flex-wrap gap-2">
                            <button
                              type="button"
                              disabled={busyId === order.id}
                              onClick={() => removeOrder(order)}
                              className="rounded-full bg-red-600 px-5 py-2.5 text-xs font-semibold text-white disabled:opacity-50"
                            >
                              Yes, delete
                            </button>
                            <button
                              type="button"
                              onClick={() => setConfirmDelete(null)}
                              className="rounded-full border border-sand bg-white px-5 py-2.5 text-xs font-semibold text-forest-800"
                            >
                              Cancel
                            </button>
                          </div>
                        </div>
                      ) : null}

                      <div className="mt-5">
                        <p className="text-[11px] font-semibold uppercase tracking-[0.16em] text-moss">
                          Update status
                        </p>
                        <div className="mt-3 flex flex-wrap gap-2">
                          {STATUSES.map((status) => (
                            <button
                              key={status.value}
                              type="button"
                              disabled={busyId === order.id}
                              onClick={() => setStatus(order, status.value)}
                              className={cn(
                                "rounded-full px-4 py-2.5 text-xs font-semibold transition disabled:opacity-50",
                                order.status === status.value
                                  ? "bg-forest-800 text-cream"
                                  : "border border-sand bg-white text-ink/70 hover:border-gold",
                              )}
                            >
                              {status.label}
                            </button>
                          ))}
                        </div>
                      </div>

                      <button
                        type="button"
                        disabled={busyId === order.id}
                        onClick={() => setConfirmDelete(order.id)}
                        className="mt-4 rounded-full px-5 py-2.5 text-xs font-semibold text-red-600 transition hover:bg-red-50 disabled:opacity-50"
                      >
                        Delete this order
                      </button>
                    </div>
                  </div>
                ) : null}
              </li>
            );
          })}
        </ul>
      )}
    </div>
  );
}
