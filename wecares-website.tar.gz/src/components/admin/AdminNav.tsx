"use client";

import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { cn } from "@/lib/format";
import { NotificationBell } from "@/components/admin/NotificationBell";

const LINKS = [
    { href: "/admin", label: "Dashboard" },
    { href: "/admin/products", label: "Products" },
  { href: "/admin/categories", label: "Categories" },
    { href: "/admin/orders", label: "Orders" },
    { href: "/admin/reviews", label: "Reviews" },
  { href: "/admin/settings", label: "Settings" },
];

export function AdminNav({ username }: { username: string }) {
  const pathname = usePathname();
  const router = useRouter();

  async function logout() {
    await fetch("/api/admin/auth", { method: "DELETE" });
    router.push("/admin/login");
    router.refresh();
  }

  return (
    <div className="flex flex-wrap items-center gap-2">
      <nav className="flex items-center gap-1">
        {LINKS.map((link) => (
          <Link
            key={link.href}
            href={link.href}
            className={cn(
              "rounded-full px-4 py-2 text-xs font-semibold transition",
              pathname === link.href
                ? "bg-gold text-forest-950"
                : "text-cream/75 hover:bg-forest-800 hover:text-gold",
            )}
          >
            {link.label}
          </Link>
        ))}
      </nav>

      <NotificationBell />

      <span className="hidden text-xs text-cream/50 sm:inline">
        · {username}
      </span>

      <Link
        href="/"
        className="rounded-full border border-gold/30 px-3.5 py-2 text-xs font-semibold text-gold-soft transition hover:bg-gold/10"
      >
        View store
      </Link>

      <button
        type="button"
        onClick={logout}
        className="rounded-full bg-forest-800 px-3.5 py-2 text-xs font-semibold text-cream transition hover:bg-moss"
      >
        Log out
      </button>
    </div>
  );
}
