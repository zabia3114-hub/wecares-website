"use client";

import { useRouter } from "next/navigation";
import { useMemo, useState } from "react";
import { cn } from "@/lib/format";
import { FONT_CHOICES, THEMES } from "@/lib/theme-presets";
import type { SiteSettings } from "@/lib/settings-types";
import { useRef } from "react";
import { WeCaresMark } from "@/components/Logo";

const TABS = [
  { id: "brand", label: "Brand & Hero" },
  { id: "theme", label: "Theme Store" },
  { id: "fonts", label: "Fonts" },
  { id: "contact", label: "Contact" },
  { id: "shipping", label: "Shipping" },
  { id: "security", label: "Password" },
] as const;

type TabId = (typeof TABS)[number]["id"];

export function SettingsManager({
  initial,
  usingDefaultPassword,
}: {
  initial: SiteSettings;
  usingDefaultPassword: boolean;
}) {
  const router = useRouter();
  const [tab, setTab] = useState<TabId>("brand");
  const [form, setForm] = useState<SiteSettings>(initial);
  const [saving, setSaving] = useState(false);
  const [message, setMessage] = useState<{ kind: "ok" | "error"; text: string } | null>(
    null,
  );

  const theme = useMemo(
    () => THEMES.find((item) => item.id === form.theme) ?? THEMES[0],
    [form.theme],
  );
  const logoInput = useRef<HTMLInputElement>(null);
  const [logoBusy, setLogoBusy] = useState(false);

  const set = <K extends keyof SiteSettings>(key: K, value: SiteSettings[K]) =>
    setForm((current) => ({ ...current, [key]: value }));

  async function uploadLogo(file: File) {
    setLogoBusy(true);
    setMessage(null);
    if (file.size > 4 * 1024 * 1024) {
      setMessage({
        kind: "error",
        text: `Logo is ${(file.size / 1024 / 1024).toFixed(1)} MB. Please use a file under 4 MB.`,
      });
      setLogoBusy(false);
      return;
    }
    try {
      const data = new FormData();
      data.append("file", file);
      data.append("filename", "brand-logo");
      const response = await fetch("/api/admin/upload", {
        method: "POST",
        body: data,
      });
      const payload = (await response.json()) as {
        ok?: boolean;
        url?: string;
        error?: string;
      };
      if (!response.ok || !payload.ok || !payload.url) {
        throw new Error(payload.error ?? `Upload failed (${response.status})`);
      }
      set("logoUrl", payload.url);
      setMessage({
        kind: "ok",
        text: "Logo uploaded. Press Save logo / Save changes to apply it.",
      });
    } catch (error) {
      setMessage({
        kind: "error",
        text: error instanceof Error ? error.message : "Logo upload failed",
      });
    } finally {
      setLogoBusy(false);
    }
  }

  async function save(partial?: Partial<SiteSettings>) {
    setSaving(true);
    setMessage(null);
    const payload = partial ? { ...form, ...partial } : form;
    try {
      const response = await fetch("/api/admin/settings", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });

      // Session expired while editing: send the operator to login rather than
      // showing a vague failure they cannot act on.
      if (response.status === 401) {
        setMessage({
          kind: "error",
          text:
            "Your session has expired. Please sign in again — your changes are still on this page.",
        });
        setSaving(false);
        setTimeout(() => router.push("/admin/login?next=/admin/settings"), 1800);
        return;
      }

      const data = (await response.json()) as {
        ok?: boolean;
        error?: string;
        settings?: SiteSettings;
      };

      if (!response.ok || !data.ok) {
        // Always surface the server's own reason so a failure is never vague.
        throw new Error(
          data.error ?? `Save failed (server returned ${response.status}).`,
        );
      }

      // Adopt the server's stored values so the form cannot drift from what is
      // actually persisted.
      if (data.settings) setForm(data.settings);
      else if (partial) setForm((current) => ({ ...current, ...partial }));

      setMessage({
        kind: "ok",
        text: "Settings saved. Refresh the storefront to see them live.",
      });
      router.refresh();
    } catch (error) {
      setMessage({
        kind: "error",
        text:
          error instanceof Error
            ? `Save failed: ${error.message}`
            : "Save failed: the server did not respond. Check your connection and try again.",
      });
    } finally {
      setSaving(false);
    }
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <h1 className="font-display text-3xl text-forest-900 sm:text-4xl">
            Settings
          </h1>
          <p className="mt-2 text-sm text-ink/60">
            Change your brand, theme, fonts, contact details and shipping —
            without touching any code.
          </p>
        </div>
        <button
          type="button"
          onClick={() => save()}
          disabled={saving || tab === "security"}
          className="rounded-full bg-gold px-6 py-3.5 text-sm font-semibold text-forest-950 transition hover:bg-gold-soft disabled:opacity-50"
        >
          {saving ? "Saving…" : "Save changes"}
        </button>
      </div>

      {message ? (
        <p
          className={cn(
            "rounded-2xl px-4 py-3 text-sm font-medium",
            message.kind === "ok"
              ? "bg-moss/12 text-moss"
              : "bg-red-50 text-red-700",
          )}
        >
          {message.text}
        </p>
      ) : null}

      {usingDefaultPassword && tab !== "security" ? (
        <div className="flex flex-wrap items-center justify-between gap-3 rounded-2xl border border-gold bg-gold/15 px-4 py-3">
          <p className="text-sm text-forest-900">
            You are still using the default admin password.
          </p>
          <button
            type="button"
            onClick={() => setTab("security")}
            className="rounded-full bg-forest-800 px-4 py-2 text-xs font-semibold text-cream"
          >
            Change it now
          </button>
        </div>
      ) : null}

      {/* Tabs */}
      <div className="flex flex-wrap gap-2">
        {TABS.map((item) => (
          <button
            key={item.id}
            type="button"
            onClick={() => {
              setTab(item.id);
              setMessage(null);
            }}
            className={cn(
              "rounded-full px-4 py-2.5 text-xs font-semibold transition sm:text-sm",
              tab === item.id
                ? "bg-forest-800 text-cream"
                : "border border-sand bg-white text-ink/65 hover:border-gold",
            )}
          >
            {item.label}
          </button>
        ))}
      </div>

      {/* ---------------- BRAND & HERO ---------------- */}
      {tab === "brand" ? (
        <>
        <Section title="Brand Logo">
          <p className="text-sm text-ink/60">
            Upload your own logo. It replaces the default leaf mark in the site
            header and footer everywhere the brand appears.
          </p>

          <input
            ref={logoInput}
            id="brand-logo-input"
            type="file"
            accept="image/*"
            onChange={(event) => {
              const file = event.target.files?.[0];
              if (file) void uploadLogo(file);
              if (logoInput.current) logoInput.current.value = "";
            }}
            style={{
              position: "absolute",
              width: 1,
              height: 1,
              opacity: 0,
              overflow: "hidden",
            }}
            tabIndex={-1}
          />

          <div className="mt-5 flex flex-col gap-5 sm:flex-row sm:items-start">
            {/* Current / newly selected logo preview */}
            <div className="flex h-32 w-32 shrink-0 items-center justify-center overflow-hidden rounded-2xl border-2 border-dashed border-gold/50 bg-forest-900">
              {form.logoUrl ? (
                // eslint-disable-next-line @next/next/no-img-element
                <img
                  src={form.logoUrl}
                  alt="Brand logo"
                  className="h-full w-full object-contain p-2"
                />
              ) : (
                <WeCaresMark className="h-16 w-16 text-gold" />
              )}
            </div>

            <div className="flex-1 space-y-3">
              <p className="text-xs text-ink/55">
                {form.logoUrl
                  ? "New logo selected. Press Save changes to apply it."
                  : "No custom logo uploaded. The default leaf mark is in use."}
              </p>

              <div className="flex flex-wrap gap-2">
                <label
                  htmlFor="brand-logo-input"
                  className="inline-flex cursor-pointer items-center justify-center rounded-full bg-forest-800 px-5 py-3 text-sm font-semibold text-cream transition hover:bg-forest-700"
                >
                  {logoBusy ? "Uploading…" : "Upload Logo"}
                </label>

                {form.logoUrl ? (
                  <>
                    <label
                      htmlFor="brand-logo-input"
                      className="inline-flex cursor-pointer items-center justify-center rounded-full border border-sand bg-white px-5 py-3 text-sm font-semibold text-forest-800 transition hover:border-gold"
                    >
                      Change Logo
                    </label>
                    <button
                      type="button"
                      onClick={() => set("logoUrl", "")}
                      className="rounded-full px-4 py-3 text-sm font-semibold text-red-600 transition hover:bg-red-50"
                    >
                      Remove
                    </button>
                  </>
                ) : null}
              </div>

              {form.logoUrl ? (
                <button
                  type="button"
                  onClick={() => save({ logoUrl: form.logoUrl })}
                  disabled={saving}
                  className="rounded-full bg-gold px-6 py-3 text-sm font-semibold text-forest-950 transition hover:bg-gold-soft disabled:opacity-60"
                >
                  {saving ? "Saving…" : "Save logo"}
                </button>
              ) : null}
            </div>
          </div>
        </Section>

        <div className="mt-6">
        <Section title="Brand & Homepage Hero">
          <div className="grid gap-5 sm:grid-cols-2">
            <Field
              label="Brand name"
              value={form.brandName}
              onChange={(value) => set("brandName", value)}
              hint="Shown in the header, footer and login page."
            />
            <Field
              label="Tagline"
              value={form.tagline}
              onChange={(value) => set("tagline", value)}
              hint="Appears under the brand name."
            />
          </div>

          <div className="mt-5 rounded-2xl border border-gold/30 bg-cream-deep p-5">
            <p className="text-[11px] font-semibold uppercase tracking-[0.16em] text-moss">
              Homepage hero
            </p>
            <div className="mt-4 space-y-4">
              <Field
                label="Small badge above the heading"
                value={form.heroBadge}
                onChange={(value) => set("heroBadge", value)}
              />
              <div className="grid gap-5 sm:grid-cols-2">
                <Field
                  label="Heading (first line)"
                  value={form.heroTitle}
                  onChange={(value) => set("heroTitle", value)}
                />
                <Field
                  label="Heading (highlighted line)"
                  value={form.heroHighlight}
                  onChange={(value) => set("heroHighlight", value)}
                  hint="This line is shown in the gold accent colour."
                />
              </div>
              <label className="block text-[11px] font-semibold uppercase tracking-[0.14em] text-ink/55">
                Paragraph under the heading
                <textarea
                  rows={3}
                  value={form.heroSubtitle}
                  onChange={(event) => set("heroSubtitle", event.target.value)}
                  className="mt-2 w-full rounded-2xl border border-sand bg-white px-4 py-3.5 text-sm font-normal normal-case tracking-normal focus:border-gold focus:outline-none"
                />
              </label>
            </div>
          </div>

          <label className="mt-5 block text-[11px] font-semibold uppercase tracking-[0.14em] text-ink/55">
            Footer about text
            <textarea
              rows={3}
              value={form.footerAbout}
              onChange={(event) => set("footerAbout", event.target.value)}
              className="mt-2 w-full rounded-2xl border border-sand bg-white px-4 py-3.5 text-sm font-normal normal-case tracking-normal focus:border-gold focus:outline-none"
            />
          </label>
        </Section>
        </div>
        </>
      ) : null}

      {/* ---------------- THEME STORE ---------------- */}
      {tab === "theme" ? (
        <Section title="Theme Store">
          <p className="text-sm text-ink/60">
            Pick a colour palette. The whole store updates instantly — colors,
            header, buttons and badges.
          </p>

          <div className="mt-5 grid gap-4 sm:grid-cols-2">
            {THEMES.map((item) => {
              const active = form.theme === item.id;
              return (
                <button
                  key={item.id}
                  type="button"
                  onClick={() => set("theme", item.id)}
                  className={cn(
                    "rounded-[1.25rem] border-2 p-5 text-left transition",
                    active
                      ? "border-gold bg-gold/10"
                      : "border-sand bg-white hover:border-gold/50",
                  )}
                >
                  <div className="flex items-center justify-between gap-3">
                    <span className="font-display text-xl text-forest-900">
                      {item.name}
                    </span>
                    {active ? (
                      <span className="rounded-full bg-forest-800 px-2.5 py-1 text-[10px] font-bold uppercase tracking-[0.12em] text-gold">
                        Selected
                      </span>
                    ) : null}
                  </div>
                  <div className="mt-3 flex gap-2">
                    {item.swatch.map((colour) => (
                      <span
                        key={colour}
                        className="h-8 w-8 rounded-full border border-sand"
                        style={{ backgroundColor: colour }}
                        aria-hidden
                      />
                    ))}
                  </div>
                  <p className="mt-3 text-xs leading-relaxed text-ink/60">
                    {item.description}
                  </p>
                </button>
              );
            })}
          </div>

          {/* Live preview */}
          <div className="mt-6 rounded-2xl border border-sand p-5">
            <p className="text-[11px] font-semibold uppercase tracking-[0.16em] text-moss">
              Preview
            </p>
            <div
              className="mt-3 rounded-2xl px-5 py-6 text-cream"
              style={{
                background: `linear-gradient(135deg, ${theme.vars["--color-forest-950"]}, ${theme.vars["--color-forest-800"]})`,
              }}
            >
              <p
                className="text-[10px] font-semibold uppercase tracking-[0.24em]"
                style={{ color: theme.vars["--color-gold-soft"] }}
              >
                {form.heroBadge || "Badge"}
              </p>
              <p
                className="mt-3 font-display text-3xl leading-tight"
                style={{ fontFamily: fontStack(form.fontHeading) }}
              >
                {form.heroTitle || "Heading"}{" "}
                <span className="italic" style={{ color: theme.vars["--color-gold"] }}>
                  {form.heroHighlight || "Highlight"}
                </span>
              </p>
              <p
                className="mt-3 max-w-md text-sm opacity-80"
                style={{ fontFamily: fontStack(form.fontBody) }}
              >
                {form.heroSubtitle}
              </p>
              <span
                className="mt-5 inline-block rounded-full px-5 py-2.5 text-sm font-semibold"
                style={{
                  backgroundColor: theme.vars["--color-gold"],
                  color: theme.vars["--color-forest-950"],
                }}
              >
                Shop Products
              </span>
            </div>
          </div>

          <button
            type="button"
            onClick={() => save({ theme: form.theme })}
            disabled={saving}
            className="mt-5 w-full rounded-full bg-forest-800 px-6 py-4 text-sm font-semibold text-cream transition hover:bg-forest-700 disabled:opacity-60 sm:w-auto"
          >
            {saving ? "Applying…" : "Apply this theme"}
          </button>
        </Section>
      ) : null}

      {/* ---------------- FONTS ---------------- */}
      {tab === "fonts" ? (
        <Section title="Fonts">
          <p className="text-sm text-ink/60">
            Choose a separate font for each part of the site.
          </p>

          <div className="mt-5 space-y-5">
            <FontPicker
              label="Headings & titles"
              hint="Used for page titles, product names and section headings."
              value={form.fontHeading}
              onChange={(value) => set("fontHeading", value)}
              sample="Nature's Care"
            />
            <FontPicker
              label="Body text"
              hint="Used for paragraphs, descriptions and form labels."
              value={form.fontBody}
              onChange={(value) => set("fontBody", value)}
              sample="Premium herbal preparations delivered across Pakistan."
            />
            <FontPicker
              label="Prices & numbers"
              hint="Used for prices, totals and large figures."
              value={form.fontPrice}
              onChange={(value) => set("fontPrice", value)}
              sample="Rs. 6,500"
            />
          </div>

          <button
            type="button"
            onClick={() =>
              save({
                fontHeading: form.fontHeading,
                fontBody: form.fontBody,
                fontPrice: form.fontPrice,
              })
            }
            disabled={saving}
            className="mt-5 w-full rounded-full bg-forest-800 px-6 py-4 text-sm font-semibold text-cream transition hover:bg-forest-700 disabled:opacity-60 sm:w-auto"
          >
            {saving ? "Applying…" : "Apply these fonts"}
          </button>
        </Section>
      ) : null}

      {/* ---------------- CONTACT ---------------- */}
      {tab === "contact" ? (
        <Section title="Contact & WhatsApp">
          <div className="grid gap-5 sm:grid-cols-2">
            <Field
              label="WhatsApp number (international)"
              value={form.whatsappNumber}
              onChange={(value) =>
                set("whatsappNumber", value.replace(/\D/g, ""))
              }
              hint="Digits only, with country code. Example: 923037307113"
            />
            <Field
              label="WhatsApp number (as displayed)"
              value={form.whatsappDisplay}
              onChange={(value) => set("whatsappDisplay", value)}
              hint="How it looks on screen. Example: 0303 730 7113"
            />
            <Field
              label="Phone number"
              value={form.phoneNumber}
              onChange={(value) => set("phoneNumber", value)}
            />
            <Field
              label="Email address"
              value={form.email}
              onChange={(value) => set("email", value)}
            />
            <Field
              label="Address line"
              value={form.address}
              onChange={(value) => set("address", value)}
            />
            <Field
              label="City / country"
              value={form.city}
              onChange={(value) => set("city", value)}
            />
            <Field
              label="Order hours"
              value={form.orderHours}
              onChange={(value) => set("orderHours", value)}
            />
            <Field
              label="Order number prefix"
              value={form.orderPrefix}
              onChange={(value) =>
                set("orderPrefix", value.toUpperCase().replace(/[^A-Z]/g, "").slice(0, 4))
              }
              hint="New orders will start with these letters."
            />
          </div>
        </Section>
      ) : null}

      {/* ---------------- SHIPPING ---------------- */}
      {tab === "shipping" ? (
        <Section title="Shipping & Payment">
          <div className="grid gap-5 sm:grid-cols-3">
            <Field
              label="Standard delivery (Rs.)"
              value={String(form.shippingStandardRupees)}
              onChange={(value) =>
                set("shippingStandardRupees", Number(value.replace(/\D/g, "")) || 0)
              }
              inputMode="numeric"
            />
            <Field
              label="Express delivery (Rs.)"
              value={String(form.shippingExpressRupees)}
              onChange={(value) =>
                set("shippingExpressRupees", Number(value.replace(/\D/g, "")) || 0)
              }
              inputMode="numeric"
            />
            <Field
              label="Free delivery over (Rs.)"
              value={String(form.freeShippingOverRupees)}
              onChange={(value) =>
                set("freeShippingOverRupees", Number(value.replace(/\D/g, "")) || 0)
              }
              hint="Set to 0 to disable free delivery."
              inputMode="numeric"
            />
          </div>

          <div className="mt-6 space-y-3">
            <p className="text-[11px] font-semibold uppercase tracking-[0.14em] text-ink/55">
              Payment methods offered at checkout
            </p>
            <Toggle
              label="Cash on Delivery"
              hint="Customer pays when the parcel arrives."
              checked={form.codEnabled}
              onChange={(value) => set("codEnabled", value)}
            />
            <Toggle
              label="Bank Transfer"
              hint="You share account details after the order."
              checked={form.bankTransferEnabled}
              onChange={(value) => set("bankTransferEnabled", value)}
            />
          </div>

          <div className="mt-6 rounded-2xl bg-cream px-4 py-3 text-sm text-ink/70">
            <p>
              Preview: Standard {formatRs(form.shippingStandardRupees)} · Express{" "}
              {formatRs(form.shippingExpressRupees)} · Free over{" "}
              {formatRs(form.freeShippingOverRupees)}
            </p>
          </div>
        </Section>
      ) : null}

      {/* ---------------- SECURITY ---------------- */}
      {tab === "security" ? (
        <PasswordPanel
          usingDefault={usingDefaultPassword}
          username="admin"
        />
      ) : null}
    </div>
  );
}

/* ------------------------------------------------------------------ */

function formatRs(amount: number) {
  return `Rs. ${new Intl.NumberFormat("en-PK").format(amount)}`;
}

function fontStack(id: string) {
  return FONT_CHOICES.find((font) => font.id === id)?.stack ?? "inherit";
}

function Section({
  title,
  children,
}: {
  title: string;
  children: React.ReactNode;
}) {
  return (
    <section className="rounded-[1.5rem] border border-sand bg-white p-5 sm:p-7">
      <h2 className="font-display text-2xl text-forest-900">{title}</h2>
      <div className="mt-5">{children}</div>
    </section>
  );
}

function Field({
  label,
  value,
  onChange,
  hint,
  inputMode,
}: {
  label: string;
  value: string;
  onChange: (value: string) => void;
  hint?: string;
  inputMode?: "text" | "numeric" | "tel";
}) {
  return (
    <label className="block text-[11px] font-semibold uppercase tracking-[0.14em] text-ink/55">
      {label}
      <input
        value={value}
        inputMode={inputMode}
        onChange={(event) => onChange(event.target.value)}
        className="mt-2 w-full rounded-2xl border border-sand bg-white px-4 py-3.5 text-sm font-normal normal-case tracking-normal focus:border-gold focus:outline-none"
      />
      {hint ? (
        <span className="mt-1.5 block text-[11px] font-normal normal-case tracking-normal text-ink/50">
          {hint}
        </span>
      ) : null}
    </label>
  );
}

function Toggle({
  label,
  hint,
  checked,
  onChange,
}: {
  label: string;
  hint?: string;
  checked: boolean;
  onChange: (value: boolean) => void;
}) {
  return (
    <button
      type="button"
      onClick={() => onChange(!checked)}
      className={cn(
        "flex w-full items-center justify-between gap-4 rounded-2xl border px-5 py-4 text-left transition",
        checked ? "border-forest-800 bg-cream-deep" : "border-sand bg-white",
      )}
    >
      <span>
        <span className="block text-sm font-semibold text-forest-900">{label}</span>
        {hint ? <span className="block text-xs text-ink/55">{hint}</span> : null}
      </span>
      <span
        className={cn(
          "grid h-6 w-11 shrink-0 items-center rounded-full px-0.5 transition",
          checked ? "bg-forest-800" : "bg-sand",
        )}
      >
        <span
          className={cn(
            "h-5 w-5 rounded-full bg-white transition",
            checked && "translate-x-5",
          )}
        />
      </span>
    </button>
  );
}

function FontPicker({
  label,
  hint,
  value,
  onChange,
  sample,
}: {
  label: string;
  hint?: string;
  value: string;
  onChange: (value: string) => void;
  sample: string;
}) {
  const selected = FONT_CHOICES.find((font) => font.id === value);
  return (
    <div className="rounded-2xl border border-sand p-4">
      <p className="text-[11px] font-semibold uppercase tracking-[0.14em] text-ink/55">
        {label}
      </p>
      {hint ? <p className="mt-1 text-[11px] text-ink/50">{hint}</p> : null}

      <select
        value={value}
        onChange={(event) => onChange(event.target.value)}
        className="mt-3 w-full rounded-2xl border border-sand bg-white px-4 py-3 text-sm focus:border-gold focus:outline-none"
      >
        {FONT_CHOICES.map((font) => (
          <option key={font.id} value={font.id}>
            {font.name}
          </option>
        ))}
      </select>

      <p
        className="mt-3 rounded-xl bg-cream px-4 py-3 text-2xl text-forest-900"
        style={{ fontFamily: selected?.stack }}
      >
        {sample}
      </p>
    </div>
  );
}

function PasswordPanel({
  usingDefault,
  username,
}: {
  usingDefault: boolean;
  username: string;
}) {
  const [currentPassword, setCurrentPassword] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState<{ kind: "ok" | "error"; text: string } | null>(
    null,
  );

  const strength = useMemo(() => {
    let score = 0;
    if (newPassword.length >= 8) score += 1;
    if (newPassword.length >= 12) score += 1;
    if (/[A-Z]/.test(newPassword) && /[a-z]/.test(newPassword)) score += 1;
    if (/\d/.test(newPassword)) score += 1;
    if (/[^A-Za-z0-9]/.test(newPassword)) score += 1;
    return score;
  }, [newPassword]);

  async function submit(event: React.FormEvent) {
    event.preventDefault();
    setMessage(null);

    if (newPassword !== confirmPassword) {
      setMessage({ kind: "error", text: "New passwords do not match." });
      return;
    }
    if (newPassword.length < 8) {
      setMessage({
        kind: "error",
        text: "New password must be at least 8 characters.",
      });
      return;
    }

    setBusy(true);
    try {
      const response = await fetch("/api/admin/password", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ currentPassword, newPassword }),
      });
      const data = (await response.json()) as { ok?: boolean; error?: string };
      if (!response.ok || !data.ok) {
        throw new Error(data.error ?? "Could not change password");
      }
      setMessage({
        kind: "ok",
        text: "Password changed. Use the new password next time you sign in.",
      });
      setCurrentPassword("");
      setNewPassword("");
      setConfirmPassword("");
    } catch (error) {
      setMessage({
        kind: "error",
        text: error instanceof Error ? error.message : "Could not change password",
      });
    } finally {
      setBusy(false);
    }
  }

  return (
    <Section title="Change password">
      {usingDefault ? (
        <div className="mb-5 rounded-2xl border border-gold bg-gold/15 px-4 py-3 text-sm text-forest-900">
          <strong className="font-semibold">Security notice:</strong> you are
          still using the default password. Change it now before going live.
        </div>
      ) : null}

      <form onSubmit={submit} className="max-w-md space-y-5">
        <label className="block text-[11px] font-semibold uppercase tracking-[0.14em] text-ink/55">
          Current password
          <input
            type="password"
            required
            value={currentPassword}
            onChange={(event) => setCurrentPassword(event.target.value)}
            autoComplete="current-password"
            className="mt-2 w-full rounded-2xl border border-sand bg-white px-4 py-3.5 text-sm font-normal normal-case tracking-normal focus:border-gold focus:outline-none"
          />
        </label>

        <label className="block text-[11px] font-semibold uppercase tracking-[0.14em] text-ink/55">
          New password
          <input
            type="password"
            required
            value={newPassword}
            onChange={(event) => setNewPassword(event.target.value)}
            autoComplete="new-password"
            className="mt-2 w-full rounded-2xl border border-sand bg-white px-4 py-3.5 text-sm font-normal normal-case tracking-normal focus:border-gold focus:outline-none"
          />
        </label>

        {newPassword ? (
          <div className="flex items-center gap-2">
            {[1, 2, 3, 4, 5].map((step) => (
              <span
                key={step}
                className={cn(
                  "h-1.5 flex-1 rounded-full",
                  step <= strength ? "bg-moss" : "bg-sand",
                )}
              />
            ))}
            <span className="ml-2 text-[11px] font-semibold text-ink/60">
              {strength <= 2 ? "Weak" : strength <= 3 ? "Fair" : "Strong"}
            </span>
          </div>
        ) : null}

        <label className="block text-[11px] font-semibold uppercase tracking-[0.14em] text-ink/55">
          Confirm new password
          <input
            type="password"
            required
            value={confirmPassword}
            onChange={(event) => setConfirmPassword(event.target.value)}
            autoComplete="new-password"
            className="mt-2 w-full rounded-2xl border border-sand bg-white px-4 py-3.5 text-sm font-normal normal-case tracking-normal focus:border-gold focus:outline-none"
          />
        </label>

        {message ? (
          <p
            className={cn(
              "rounded-2xl px-4 py-3 text-sm font-medium",
              message.kind === "ok"
                ? "bg-moss/12 text-moss"
                : "bg-red-50 text-red-700",
            )}
          >
            {message.text}
          </p>
        ) : null}

        <button
          type="submit"
          disabled={busy}
          className="w-full rounded-full bg-forest-800 px-6 py-4 text-sm font-semibold text-cream transition hover:bg-forest-700 disabled:opacity-60"
        >
          {busy ? "Updating…" : "Update password"}
        </button>

        <p className="text-[11px] leading-relaxed text-ink/50">
          Signed in as <span className="font-semibold">{username}</span>. Passwords
          are stored as salted scrypt hashes — never in plain text.
        </p>
      </form>
    </Section>
  );
}
