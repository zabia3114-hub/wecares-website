"use client";

import { useRouter, useSearchParams } from "next/navigation";
import { useState } from "react";
import { Logo } from "@/components/Logo";

export function LoginForm({
  brandName,
  tagline,
}: {
  brandName?: string;
  tagline?: string;
}) {
  const router = useRouter();
  const searchParams = useSearchParams();
  const nextPath = searchParams.get("next") ?? "/admin";

  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  async function submit(event: React.FormEvent) {
    event.preventDefault();
    setError(null);
    setLoading(true);
    try {
      const response = await fetch("/api/admin/auth", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ username, password }),
      });
      const payload = (await response.json()) as { ok?: boolean; error?: string };
      if (!response.ok || !payload.ok) {
        throw new Error(payload.error ?? "Login failed");
      }
      router.push(nextPath.startsWith("/admin") ? nextPath : "/admin");
      router.refresh();
    } catch (loginError) {
      setError(
        loginError instanceof Error ? loginError.message : "Login failed",
      );
      setLoading(false);
    }
  }

  return (
    <div className="flex min-h-screen items-center justify-center bg-forest-900 px-4 py-16">
      <div className="w-full max-w-sm">
        <div className="flex justify-center">
          <Logo variant="dark" brandName={brandName} tagline={tagline} />
        </div>

        <div className="mt-8 rounded-[1.5rem] border border-gold/25 bg-cream p-7">
          <h1 className="font-display text-2xl text-forest-900">Admin login</h1>
          <p className="mt-1.5 text-xs text-ink/60">
            Manage products, prices and orders.
          </p>

          <form onSubmit={submit} className="mt-6 space-y-4">
            <label className="block text-[11px] font-semibold uppercase tracking-[0.14em] text-ink/55">
              Username
              <input
                value={username}
                onChange={(event) => setUsername(event.target.value)}
                autoComplete="username"
                className="mt-2 w-full rounded-2xl border border-sand bg-white px-4 py-3.5 text-sm font-normal normal-case tracking-normal text-ink focus:border-gold focus:outline-none"
              />
            </label>

            <label className="block text-[11px] font-semibold uppercase tracking-[0.14em] text-ink/55">
              Password
              <input
                type="password"
                value={password}
                onChange={(event) => setPassword(event.target.value)}
                autoComplete="current-password"
                className="mt-2 w-full rounded-2xl border border-sand bg-white px-4 py-3.5 text-sm font-normal normal-case tracking-normal text-ink focus:border-gold focus:outline-none"
              />
            </label>

            {error ? (
              <p className="rounded-2xl bg-moss/12 px-4 py-3 text-sm font-medium text-moss">
                {error}
              </p>
            ) : null}

            <button
              type="submit"
              disabled={loading}
              className="w-full rounded-full bg-forest-800 px-6 py-4 text-sm font-semibold text-cream transition hover:bg-forest-700 disabled:opacity-60"
            >
              {loading ? "Signing in…" : "Sign in"}
            </button>
          </form>
        </div>

        <p className="mt-5 text-center text-[11px] leading-relaxed text-cream/45">
          Authorised access only. Credentials are configured by the store owner
          through environment variables and are never stored in this page.
        </p>
      </div>
    </div>
  );
}
