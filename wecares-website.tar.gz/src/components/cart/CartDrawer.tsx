"use client";

import Link from "next/link";
import { useCart } from "@/components/cart/CartProvider";
import { ProductImage } from "@/components/ProductImage";
import { WhatsAppButton } from "@/components/WhatsAppButton";
import {
  cn,
  computeTotals,
  formatPkr,
  FREE_DELIVERY_THRESHOLD_PAISA,
  type ShippingMethod,
} from "@/lib/format";
import { orderMessage } from "@/lib/whatsapp";

export function CartDrawer() {
  const {
    items,
    isOpen,
    closeCart,
    removeItem,
    setQuantity,
    subtotalPaisa,
    count,
  } = useCart();

  if (!isOpen) return null;

  const { shippingPaisa, totalPaisa } = computeTotals(subtotalPaisa, "standard");
  const remaining = Math.max(0, FREE_DELIVERY_THRESHOLD_PAISA - subtotalPaisa);
  const progress = Math.min(
    100,
    Math.round((subtotalPaisa / FREE_DELIVERY_THRESHOLD_PAISA) * 100),
  );

  const waMessage = orderMessage({
    items: items.map((item) => ({
      name: item.name,
      quantity: item.quantity,
      lineTotal: formatPkr(item.pricePaisa * item.quantity),
    })),
    total: formatPkr(totalPaisa),
  });

  return (
    <div className="fixed inset-0 z-[70] flex justify-end">
      <button
        type="button"
        aria-label="Close cart"
        onClick={closeCart}
        className="animate-fade-in absolute inset-0 bg-forest-950/60 backdrop-blur-sm"
      />
      <aside className="animate-drawer relative flex h-full w-full flex-col bg-cream shadow-lift sm:max-w-[26rem]">
        <header className="flex items-center justify-between border-b border-sand bg-forest-900 px-5 py-4 text-cream">
          <div>
            <p className="text-[10px] font-semibold uppercase tracking-[0.24em] text-gold">
              Your Cart
            </p>
            <h2 className="mt-1 font-display text-2xl">
              {count === 0 ? "Empty" : `${count} ${count === 1 ? "item" : "items"}`}
            </h2>
          </div>
          <button
            type="button"
            onClick={closeCart}
            className="grid h-10 w-10 place-items-center rounded-full border border-gold/30 text-gold transition hover:rotate-90 hover:bg-gold/10"
            aria-label="Close cart"
          >
            <svg viewBox="0 0 24 24" className="h-4 w-4" aria-hidden>
              <path
                d="M6 6l12 12M18 6L6 18"
                stroke="currentColor"
                strokeWidth="1.8"
                strokeLinecap="round"
              />
            </svg>
          </button>
        </header>

        {items.length > 0 ? (
          <div className="border-b border-sand bg-cream-deep px-5 py-3.5">
            <p className="text-xs font-medium text-forest-800">
              {remaining === 0
                ? "✓ Free standard delivery unlocked"
                : `Add ${formatPkr(remaining)} more for free standard delivery`}
            </p>
            <div className="mt-2 h-1.5 w-full overflow-hidden rounded-full bg-white">
              <div
                className="h-full rounded-full bg-gradient-to-r from-moss to-gold transition-[width] duration-700"
                style={{ width: `${progress}%` }}
              />
            </div>
          </div>
        ) : null}

        <div className="flex-1 overflow-y-auto px-5 py-5">
          {items.length === 0 ? (
            <div className="flex h-full flex-col items-center justify-center gap-4 text-center">
              <span className="grid h-20 w-20 place-items-center rounded-full bg-forest-800 text-gold">
                <svg viewBox="0 0 24 24" className="h-8 w-8" aria-hidden>
                  <path
                    d="M6 8h12l-1 12H7L6 8zm3 0a3 3 0 016 0"
                    stroke="currentColor"
                    strokeWidth="1.4"
                    strokeLinecap="round"
                    fill="none"
                  />
                </svg>
              </span>
              <div>
                <h3 className="font-display text-2xl text-forest-900">
                  Your cart is empty
                </h3>
                <p className="mt-2 max-w-xs text-sm text-ink/65">
                  Browse our herbal majoon and herbal oils to get started.
                </p>
              </div>
              <Link
                href="/shop"
                onClick={closeCart}
                className="rounded-full bg-forest-800 px-6 py-3.5 text-sm font-semibold text-cream transition hover:bg-forest-700"
              >
                View Products
              </Link>
            </div>
          ) : (
            <ul className="space-y-5">
              {items.map((item) => (
                <li key={item.slug} className="flex gap-3.5">
                  <Link
                    href={`/products/${item.slug}`}
                    onClick={closeCart}
                    className="relative h-24 w-20 shrink-0 overflow-hidden rounded-2xl bg-forest-800"
                  >
                    <ProductImage
                      src={item.image}
                      alt={item.name}
                      name={item.name}
                      sizes="80px"
                    />
                  </Link>
                  <div className="flex flex-1 flex-col justify-between">
                    <div className="flex items-start justify-between gap-3">
                      <Link
                        href={`/products/${item.slug}`}
                        onClick={closeCart}
                        className="text-sm font-semibold leading-snug text-forest-900 hover:text-moss"
                      >
                        {item.name}
                      </Link>
                      <span className="shrink-0 text-sm font-semibold text-forest-800">
                        {formatPkr(item.pricePaisa * item.quantity)}
                      </span>
                    </div>
                    <div className="mt-2 flex items-center justify-between">
                      <div className="inline-flex items-center gap-1 rounded-full border border-sand bg-white px-1.5 py-1">
                        <button
                          type="button"
                          onClick={() => setQuantity(item.slug, item.quantity - 1)}
                          className="grid h-6 w-6 place-items-center rounded-full text-forest-800 transition hover:bg-cream-deep"
                          aria-label={`Decrease quantity of ${item.name}`}
                        >
                          −
                        </button>
                        <span className="w-6 text-center text-sm font-semibold">
                          {item.quantity}
                        </span>
                        <button
                          type="button"
                          onClick={() => setQuantity(item.slug, item.quantity + 1)}
                          className="grid h-6 w-6 place-items-center rounded-full text-forest-800 transition hover:bg-cream-deep"
                          aria-label={`Increase quantity of ${item.name}`}
                        >
                          +
                        </button>
                      </div>
                      <button
                        type="button"
                        onClick={() => removeItem(item.slug)}
                        className="text-xs font-medium text-ink/50 underline decoration-sand underline-offset-4 transition hover:text-moss"
                      >
                        Remove
                      </button>
                    </div>
                  </div>
                </li>
              ))}
            </ul>
          )}
        </div>

        {items.length > 0 ? (
          <footer className="border-t border-sand bg-white px-5 py-5">
            <dl className="space-y-1.5 text-sm">
              <div className="flex justify-between text-ink/65">
                <dt>Subtotal</dt>
                <dd className="font-semibold text-forest-900">
                  {formatPkr(subtotalPaisa)}
                </dd>
              </div>
              <div className="flex justify-between text-ink/65">
                <dt>Delivery</dt>
                <dd className="font-semibold text-forest-900">
                  {shippingPaisa === 0 ? "Free" : formatPkr(shippingPaisa)}
                </dd>
              </div>
              <div className="flex justify-between border-t border-sand pt-3">
                <dt className="font-semibold text-forest-900">Total</dt>
                <dd className="font-display text-2xl font-semibold text-forest-900">
                  {formatPkr(totalPaisa)}
                </dd>
              </div>
            </dl>
            <p className="mt-1.5 text-[11px] text-ink/50">
              Prices inclusive of all applicable taxes. Cash on delivery available.
            </p>

            <Link
              href="/checkout"
              onClick={closeCart}
              className="mt-4 flex w-full items-center justify-center gap-2 rounded-full bg-forest-800 px-6 py-4 text-sm font-semibold text-cream transition hover:bg-forest-700"
            >
              Proceed to Checkout · {formatPkr(totalPaisa)}
            </Link>
            <WhatsAppButton
              message={waMessage}
              className="mt-2.5 w-full"
              label="Send this order on WhatsApp"
            >
              Order on WhatsApp
            </WhatsAppButton>
          </footer>
        ) : null}
      </aside>
    </div>
  );
}


