"use client";

import Link from "next/link";
import { useCart } from "@/components/cart/CartProvider";
import { ProductImage } from "@/components/ProductImage";
import { WhatsAppButton } from "@/components/WhatsAppButton";
import {
  cn,
  discountPercent,
  formatPkr,
} from "@/lib/format";
import { productEnquiryMessage } from "@/lib/whatsapp";
import type { ProductListItem } from "@/lib/queries";

export function ProductCard({
  product,
  priority = false,
  className,
}: {
  product: ProductListItem;
  priority?: boolean;
  className?: string;
}) {
  const { addItem, openCart, lastAddedSlug } = useCart();
  const off = discountPercent(product.pricePaisa, product.compareAtPaisa);
  const justAdded = lastAddedSlug === product.slug;
  const price = formatPkr(product.pricePaisa);

  return (
    <article
      className={cn(
        "group flex h-full flex-col overflow-hidden rounded-[1.75rem] border border-sand bg-white transition duration-500 hover:-translate-y-1.5 hover:border-gold/60 hover:shadow-card",
        className,
      )}
    >
      <Link
        href={`/products/${product.slug}`}
        className="relative block aspect-square overflow-hidden bg-forest-800"
      >
        <div className="h-full w-full transition duration-700 group-hover:scale-[1.05]">
          <ProductImage
            src={product.images[0]}
            alt={product.name}
            name={product.name}
            netWeight={product.netWeight}
            priority={priority}
            sizes="(max-width: 640px) 90vw, (max-width: 1024px) 45vw, 30vw"
          />
        </div>

        {off > 0 ? (
          <span className="absolute left-3 top-3 rounded-full bg-gold px-3 py-1.5 text-[10px] font-bold uppercase tracking-[0.14em] text-forest-950">
            Save {off}%
          </span>
        ) : null}
        {product.isBestseller ? (
          <span className="absolute right-3 top-3 rounded-full bg-cream/95 px-3 py-1.5 text-[10px] font-bold uppercase tracking-[0.14em] text-forest-800">
            Popular
          </span>
        ) : null}
      </Link>

      <div className="flex flex-1 flex-col p-4 sm:p-5">
        <p className="text-[10px] font-semibold uppercase tracking-[0.2em] text-moss">
          {product.categoryLabel} · {product.netWeight}
        </p>

        <h3 className="mt-2 font-display text-xl leading-snug text-forest-900">
          <Link
            href={`/products/${product.slug}`}
            className="transition hover:text-moss"
          >
            {product.name}
          </Link>
        </h3>

        <p className="mt-2 line-clamp-2 text-sm leading-relaxed text-ink/70">
          {product.subtitle}. {product.suitability}.
        </p>

        <div className="mt-4 flex items-baseline gap-2.5">
          <span className="font-display text-2xl font-semibold text-forest-800">
            {formatPkr(product.pricePaisa)}
          </span>
          {product.compareAtPaisa ? (
            <span className="text-sm text-ink/45 line-through">
              {formatPkr(product.compareAtPaisa)}
            </span>
          ) : null}
        </div>

        <div className="mt-auto space-y-2.5 pt-5">
          <button
            type="button"
            onClick={() => {
              addItem({
                slug: product.slug,
                name: product.name,
                image: product.images[0],
                pricePaisa: product.pricePaisa,
              });
              openCart();
            }}
            className={cn(
              "w-full rounded-full px-5 py-3.5 text-sm font-semibold transition active:scale-[0.98]",
              justAdded
                ? "bg-moss text-cream"
                : "bg-forest-800 text-cream hover:bg-forest-700",
            )}
          >
            {justAdded ? "Added to cart ✓" : "Add to Cart"}
          </button>

          <WhatsAppButton
            size="md"
            variant="outline"
            className="w-full"
            message={productEnquiryMessage(product.name, price)}
            label={`Order ${product.name} on WhatsApp`}
          >
            Order on WhatsApp
          </WhatsAppButton>
        </div>
      </div>
    </article>
  );
}
