"use client";

import { useRouter, useSearchParams } from "next/navigation";
import { useMemo, useState, useTransition } from "react";
import { cn, formatPkr } from "@/lib/format";

type FacetOption = { value: string; count: number };

export type ShopControlsProps = {
  categories: FacetOption[];
  collections: Array<{ slug: string; name: string; productCount: number }>;
  maxPrice: number;
  total: number;
};

const SORTS = [
  { value: "featured", label: "Featured" },
  { value: "price-asc", label: "Price: low to high" },
  { value: "price-desc", label: "Price: high to low" },
  { value: "newest", label: "Newest" },
] as const;

export function ShopControls({
  categories,
  collections,
  maxPrice,
  total,
}: ShopControlsProps) {
  const router = useRouter();
  const searchParams = useSearchParams();
  const [isPending, startTransition] = useTransition();
  const [mobileOpen, setMobileOpen] = useState(false);

  const current = useMemo(() => {
    const max = Number(searchParams.get("max") ?? maxPrice);
    return {
      collection: searchParams.get("collection") ?? "",
      category: searchParams.get("category") ?? "",
      sort: searchParams.get("sort") ?? "featured",
      max: Number.isFinite(max) ? max : maxPrice,
      q: searchParams.get("q") ?? "",
    };
  }, [searchParams, maxPrice]);

  function pushParams(mutate: (params: URLSearchParams) => void) {
    const params = new URLSearchParams(searchParams.toString());
    mutate(params);
    const query = params.toString();
    startTransition(() => {
      router.push(query ? `/shop?${query}` : "/shop", { scroll: false });
    });
  }

  const setParam = (key: string, value: string) =>
    pushParams((params) => {
      if (!value || params.get(key) === value) params.delete(key);
      else params.set(key, value);
    });

  const activeChips = [
    current.collection &&
      collections.find((c) => c.slug === current.collection)?.name,
    current.category,
    current.q ? `“${current.q}”` : "",
    Number(searchParams.get("max") ?? maxPrice) < maxPrice
      ? `Under ${formatPkr(Number(searchParams.get("max")))}`
      : "",
  ].filter(Boolean) as string[];

  const panel = (
    <div className="space-y-7">
      <div>
        <p className="text-[11px] font-semibold uppercase tracking-[0.2em] text-moss">
          Category
        </p>
        <ul className="mt-3 space-y-1.5">
          {categories.map((option) => (
            <li key={option.value}>
              <button
                type="button"
                onClick={() => setParam("category", option.value)}
                className={cn(
                  "flex w-full items-center justify-between rounded-xl px-3 py-2.5 text-left text-sm transition",
                  current.category === option.value
                    ? "bg-forest-800 text-cream"
                    : "text-ink/75 hover:bg-cream-deep",
                )}
              >
                <span>{option.value}</span>
                <span className="text-xs opacity-60">{option.count}</span>
              </button>
            </li>
          ))}
        </ul>
      </div>

      <div>
        <p className="text-[11px] font-semibold uppercase tracking-[0.2em] text-moss">
          Collection
        </p>
        <ul className="mt-3 space-y-1.5">
          {collections.map((collection) => (
            <li key={collection.slug}>
              <button
                type="button"
                onClick={() => setParam("collection", collection.slug)}
                className={cn(
                  "flex w-full items-center justify-between rounded-xl px-3 py-2.5 text-left text-sm transition",
                  current.collection === collection.slug
                    ? "bg-forest-800 text-cream"
                    : "text-ink/75 hover:bg-cream-deep",
                )}
              >
                <span>{collection.name}</span>
                <span className="text-xs opacity-60">
                  {collection.productCount}
                </span>
              </button>
            </li>
          ))}
        </ul>
      </div>

      <div>
        <p className="text-[11px] font-semibold uppercase tracking-[0.2em] text-moss">
          Maximum price
        </p>
        <input
          type="range"
          min={100000}
          max={maxPrice}
          step={50000}
          value={current.max}
          onChange={(event) =>
            pushParams((params) => {
              const value = Number(event.target.value);
              if (value >= maxPrice) params.delete("max");
              else params.set("max", String(value));
            })
          }
          className="mt-3 w-full accent-forest-700"
          aria-label="Maximum price"
        />
        <div className="mt-1.5 flex justify-between text-xs text-ink/60">
          <span>{formatPkr(100000)}</span>
          <span className="font-semibold text-forest-800">
            up to {formatPkr(current.max)}
          </span>
        </div>
      </div>

      <button
        type="button"
        onClick={() => router.push("/shop")}
        className="w-full rounded-full border border-sand bg-white px-4 py-3 text-xs font-semibold uppercase tracking-[0.16em] text-ink/60 transition hover:border-gold hover:text-moss"
      >
        Clear all filters
      </button>
    </div>
  );

  return (
    <>
      <aside className="hidden lg:block">
        <div className="sticky top-32 rounded-[1.5rem] border border-sand bg-white p-6">
          {panel}
        </div>
      </aside>

      <div className="mb-6 flex flex-wrap items-center justify-between gap-3">
        <p className="text-sm text-ink/60">
          <span
            className={cn("font-semibold text-forest-900", isPending && "opacity-60")}
          >
            {total}
          </span>{" "}
          {total === 1 ? "product" : "products"}
        </p>
        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={() => setMobileOpen(true)}
            className="inline-flex items-center gap-2 rounded-full border border-sand bg-white px-4 py-2.5 text-sm font-semibold text-forest-800 transition hover:border-gold lg:hidden"
          >
            Filters
            {activeChips.length > 0 ? (
              <span className="grid h-5 w-5 place-items-center rounded-full bg-gold text-[11px] text-forest-950">
                {activeChips.length}
              </span>
            ) : null}
          </button>
          <label className="sr-only" htmlFor="sort">
            Sort products
          </label>
          <select
            id="sort"
            value={current.sort}
            onChange={(event) => setParam("sort", event.target.value)}
            className="rounded-full border border-sand bg-white px-4 py-2.5 text-sm font-semibold text-forest-800 transition hover:border-gold focus:border-gold focus:outline-none"
          >
            {SORTS.map((option) => (
              <option key={option.value} value={option.value}>
                {option.label}
              </option>
            ))}
          </select>
        </div>
      </div>

      {activeChips.length > 0 ? (
        <div className="mb-6 flex flex-wrap gap-2">
          {activeChips.map((chip) => (
            <span
              key={chip}
              className="inline-flex items-center gap-2 rounded-full bg-forest-800 px-3.5 py-1.5 text-xs font-semibold text-cream"
            >
              {chip}
            </span>
          ))}
          <button
            type="button"
            onClick={() => router.push("/shop")}
            className="rounded-full px-3 py-1.5 text-xs font-semibold text-moss underline underline-offset-4"
          >
            Clear
          </button>
        </div>
      ) : null}

      {mobileOpen ? (
        <div className="fixed inset-0 z-[65] lg:hidden">
          <button
            type="button"
            aria-label="Close filters"
            onClick={() => setMobileOpen(false)}
            className="animate-fade-in absolute inset-0 bg-forest-950/60 backdrop-blur-sm"
          />
          <div className="animate-drawer absolute inset-y-0 right-0 flex w-full max-w-sm flex-col bg-cream shadow-lift">
            <div className="flex items-center justify-between border-b border-sand bg-forest-900 px-5 py-4 text-cream">
              <h2 className="font-display text-xl">Filters</h2>
              <button
                type="button"
                onClick={() => setMobileOpen(false)}
                className="grid h-9 w-9 place-items-center rounded-full border border-gold/30 text-gold"
                aria-label="Close filters"
              >
                ×
              </button>
            </div>
            <div className="flex-1 overflow-y-auto px-5 py-5">{panel}</div>
            <div className="border-t border-sand p-5">
              <button
                type="button"
                onClick={() => setMobileOpen(false)}
                className="w-full rounded-full bg-forest-800 px-6 py-3.5 text-sm font-semibold text-cream"
              >
                Show {total} {total === 1 ? "product" : "products"}
              </button>
            </div>
          </div>
        </div>
      ) : null}
    </>
  );
}
