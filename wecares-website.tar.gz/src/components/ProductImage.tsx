"use client";

import { useEffect, useState } from "react";
import { WeCaresMark } from "@/components/Logo";
import { cn } from "@/lib/format";

/**
 * Renders the product's own uploaded image. No resizing, cropping, caching
 * proxy or substitution happens — the exact bytes the owner uploaded are what
 * the browser receives.
 *
 * Two very different situations are handled explicitly:
 *
 * 1. `src` is empty  -> the owner has not uploaded a photo yet. A neutral
 *    "no photo yet" panel is correct here.
 *
 * 2. `src` is set but the browser could not load it -> this is an error. We
 *    DO NOT silently draw a placeholder instead, because that looks exactly
 *    like the upload "worked" while showing a template image. The broken
 *    state is shown clearly, with the path that failed so it can be fixed.
 */
export function ProductImage({
  src,
  alt,
  name,
  netWeight,
  className,
  sizes,
  priority = false,
  showError = false,
}: {
  src?: string;
  alt: string;
  name: string;
  netWeight?: string;
  className?: string;
  sizes?: string;
  priority?: boolean;
  /** Show an explicit broken-image message instead of a quiet placeholder. */
  showError?: boolean;
}) {
  const [failed, setFailed] = useState(false);

  // If the stored path changes (a new upload), clear any earlier failure so the
  // freshly uploaded photo is actually attempted again.
  useEffect(() => {
    setFailed(false);
  }, [src]);

  const trimmed = src?.trim() ?? "";
  const hasImage = trimmed.length > 0 && !failed;

  // Case 1: no photo uploaded at all — neutral empty state.
  if (!trimmed) {
    return (
      <div
        className={cn(
          "relative flex h-full w-full flex-col items-center justify-center gap-3 bg-gradient-to-br from-forest-800 via-forest-700 to-forest-900 px-4 text-center",
          className,
        )}
      >
        <div
          className="absolute inset-0 opacity-25"
          style={{
            backgroundImage:
              "radial-gradient(circle at 25% 20%, rgba(201,162,39,0.35), transparent 45%), radial-gradient(circle at 78% 80%, rgba(46,115,85,0.5), transparent 45%)",
          }}
        />
        <WeCaresMark className="relative h-14 w-14 text-gold" />
        <p className="relative font-display text-lg leading-snug text-cream">
          {name}
        </p>
        {netWeight ? (
          <p className="relative rounded-full border border-gold/40 px-3 py-1 text-[10px] font-semibold uppercase tracking-[0.18em] text-gold-soft">
            {netWeight}
          </p>
        ) : null}
        <p className="relative text-[10px] uppercase tracking-[0.16em] text-cream/50">
          No photo uploaded
        </p>
      </div>
    );
  }

  // Case 2: a photo IS stored but failed to load — be honest about it.
  if (failed) {
    if (!showError) {
      // Compact surfaces (cart, order rows) keep a quiet mark, but it is still
      // an explicit broken-image glyph, not a fake product photo.
      return (
        <div
          className={cn(
            "flex h-full w-full flex-col items-center justify-center gap-1 bg-cream-deep px-2 text-center",
            className,
          )}
          title="Image could not be loaded"
        >
          <span className="text-xl leading-none text-ink/35" aria-hidden>
            ⚠
          </span>
          <span className="text-[9px] font-semibold uppercase tracking-[0.1em] text-ink/45">
            Image error
          </span>
        </div>
      );
    }

    return (
      <div
        className={cn(
          "flex h-full w-full flex-col items-center justify-center gap-2 bg-red-50 px-4 text-center",
          className,
        )}
      >
        <span className="text-2xl" aria-hidden>
          ⚠
        </span>
        <p className="text-xs font-semibold text-red-700">
          Image could not be loaded
        </p>
        <p className="break-all text-[10px] leading-snug text-red-600/80">
          {trimmed}
        </p>
        <p className="text-[10px] leading-snug text-red-600/70">
          Re-upload the photo in the admin panel.
        </p>
      </div>
    );
  }

  // Normal case: the owner's own image, served exactly as uploaded.
  return (
    // eslint-disable-next-line @next/next/no-img-element
    <img
      key={trimmed}
      src={trimmed}
      alt={alt}
      sizes={sizes}
      loading={priority ? "eager" : "lazy"}
      decoding="async"
      onError={() => setFailed(true)}
      className={cn("h-full w-full object-cover", className)}
    />
  );
}
