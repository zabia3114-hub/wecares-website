"use client";

import { useRouter } from "next/navigation";
import { useState } from "react";
import { cn } from "@/lib/format";
import type { PublicReview } from "@/lib/reviews";

export function ProductReviews({
  productId,
  productSlug,
  reviews,
  average,
  total,
}: {
  productId: number;
  productSlug: string;
  reviews: PublicReview[];
  average: number;
  total: number;
}) {
  const router = useRouter();
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState({
    authorName: "",
    authorMobile: "",
    rating: 5,
    title: "",
    body: "",
  });
  const [status, setStatus] = useState<"idle" | "saving" | "sent">("idle");
  const [error, setError] = useState<string | null>(null);

  async function submit(event: React.FormEvent) {
    event.preventDefault();
    setError(null);
    setStatus("saving");
    try {
      const response = await fetch(`/api/products/${productSlug}/reviews`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(form),
      });
      const payload = (await response.json()) as { ok?: boolean; error?: string };
      if (!response.ok || !payload.ok) {
        throw new Error(payload.error ?? "Could not submit your review");
      }
      setStatus("sent");
      setForm({ authorName: "", authorMobile: "", rating: 5, title: "", body: "" });
      setOpen(false);
      router.refresh();
    } catch (submitError) {
      setStatus("idle");
      setError(
        submitError instanceof Error ? submitError.message : "Something went wrong",
      );
    }
  }

  return (
    <section id="reviews" className="mt-14 scroll-mt-32">
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <p className="text-[11px] font-semibold uppercase tracking-[0.28em] text-moss">
            Customer Reviews
          </p>
          <h2 className="mt-2 font-display text-2xl text-forest-900 sm:text-3xl">
            What customers say
          </h2>
        </div>
        <button
          type="button"
          onClick={() => setOpen((value) => !value)}
          className="rounded-full bg-forest-800 px-6 py-3.5 text-sm font-semibold text-cream transition hover:bg-forest-700"
        >
          {open ? "Close form" : "Write a review"}
        </button>
      </div>

      <div className="mt-6 grid gap-6 rounded-[1.5rem] border border-sand bg-white p-6 lg:grid-cols-[260px_1fr]">
        {/* Summary */}
        <div>
          <div className="flex items-end gap-3">
            <span className="font-display text-4xl leading-none text-forest-900">
              {total > 0 ? average.toFixed(1) : "—"}
            </span>
            <div className="pb-1">
              <Stars rating={Math.round(average)} />
              <p className="mt-1 text-xs text-ink/55">
                {total} approved {total === 1 ? "review" : "reviews"}
              </p>
            </div>
          </div>
          <p className="mt-4 text-[11px] leading-relaxed text-ink/50">
            Every review is checked by our team before it appears here.
          </p>
        </div>

        <div>
          {open ? (
            <form
              onSubmit={submit}
              className="mb-6 space-y-4 rounded-[1.25rem] border border-gold/30 bg-cream p-5"
            >
              <h3 className="font-display text-lg text-forest-900">
                Share your experience
              </h3>

              <div className="flex items-center gap-3">
                <span className="text-[11px] font-semibold uppercase tracking-[0.14em] text-ink/55">
                  Rating
                </span>
                <div className="flex gap-1">
                  {[1, 2, 3, 4, 5].map((star) => (
                    <button
                      key={star}
                      type="button"
                      onClick={() =>
                        setForm((current) => ({ ...current, rating: star }))
                      }
                      aria-label={`${star} star${star > 1 ? "s" : ""}`}
                      className={cn(
                        "text-2xl leading-none transition",
                        star <= form.rating ? "text-gold" : "text-sand hover:text-gold/50",
                      )}
                    >
                      ★
                    </button>
                  ))}
                </div>
              </div>

              <div className="grid gap-4 sm:grid-cols-2">
                <label className="block text-[11px] font-semibold uppercase tracking-[0.14em] text-ink/55">
                  Your name
                  <input
                    required
                    value={form.authorName}
                    onChange={(event) =>
                      setForm((c) => ({ ...c, authorName: event.target.value }))
                    }
                    className="mt-2 w-full rounded-2xl border border-sand bg-white px-4 py-3 text-sm font-normal normal-case tracking-normal focus:border-gold focus:outline-none"
                    placeholder="e.g. Ahmed Raza"
                  />
                </label>
                <label className="block text-[11px] font-semibold uppercase tracking-[0.14em] text-ink/55">
                  Mobile number
                  <input
                    required
                    inputMode="tel"
                    value={form.authorMobile}
                    onChange={(event) =>
                      setForm((c) => ({
                        ...c,
                        authorMobile: event.target.value.replace(/[^\d+]/g, ""),
                      }))
                    }
                    className="mt-2 w-full rounded-2xl border border-sand bg-white px-4 py-3 text-sm font-normal normal-case tracking-normal focus:border-gold focus:outline-none"
                    placeholder="03001234567"
                  />
                </label>
              </div>

              <label className="block text-[11px] font-semibold uppercase tracking-[0.14em] text-ink/55">
                Headline (optional)
                <input
                  value={form.title}
                  onChange={(event) =>
                    setForm((c) => ({ ...c, title: event.target.value }))
                  }
                  className="mt-2 w-full rounded-2xl border border-sand bg-white px-4 py-3 text-sm font-normal normal-case tracking-normal focus:border-gold focus:outline-none"
                  placeholder="Good quality product"
                />
              </label>

              <label className="block text-[11px] font-semibold uppercase tracking-[0.14em] text-ink/55">
                Your review
                <textarea
                  required
                  rows={4}
                  value={form.body}
                  onChange={(event) =>
                    setForm((c) => ({ ...c, body: event.target.value }))
                  }
                  className="mt-2 w-full rounded-2xl border border-sand bg-white px-4 py-3 text-sm font-normal normal-case tracking-normal focus:border-gold focus:outline-none"
                  placeholder="Tell other customers about the product and the packaging."
                />
              </label>

              {error ? (
                <p className="rounded-2xl bg-red-50 px-4 py-3 text-sm font-medium text-red-700">
                  {error}
                </p>
              ) : null}

              <button
                type="submit"
                disabled={status === "saving"}
                className="rounded-full bg-forest-800 px-6 py-3.5 text-sm font-semibold text-cream transition hover:bg-forest-700 disabled:opacity-60"
              >
                {status === "saving" ? "Submitting…" : "Submit review"}
              </button>
              <p className="text-[11px] text-ink/50">
                Reviews are published after moderation.
              </p>
            </form>
          ) : null}

          {status === "sent" ? (
            <p className="mb-6 rounded-2xl bg-moss/12 px-4 py-3 text-sm font-medium text-moss">
              Thank you — your review has been received and will appear once
              approved.
            </p>
          ) : null}

          {reviews.length === 0 ? (
            <p className="rounded-2xl bg-cream px-4 py-8 text-center text-sm text-ink/55">
              No reviews yet. Be the first to share your experience.
            </p>
          ) : (
            <ul className="space-y-4">
              {reviews.map((review) => (
                <li key={review.id} className="rounded-[1.25rem] bg-cream p-5">
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <Stars rating={review.rating} />
                    <span className="text-xs text-ink/50">
                      {new Date(review.createdAt).toLocaleDateString("en-GB", {
                        day: "numeric",
                        month: "short",
                        year: "numeric",
                      })}
                    </span>
                  </div>
                  {review.title ? (
                    <h3 className="mt-3 font-display text-lg text-forest-900">
                      {review.title}
                    </h3>
                  ) : null}
                  <p className="mt-1.5 text-sm leading-relaxed text-ink/75">
                    {review.body}
                  </p>
                  <p className="mt-3 text-xs font-semibold text-moss">
                    {review.authorName}
                    {review.isVerifiedBuyer ? (
                      <span className="ml-2 rounded-full bg-forest-800 px-2 py-0.5 text-[10px] font-bold uppercase tracking-[0.1em] text-gold-soft">
                        Verified buyer
                      </span>
                    ) : null}
                  </p>
                </li>
              ))}
            </ul>
          )}
        </div>
      </div>
    </section>
  );
}

function Stars({ rating }: { rating: number }) {
  return (
    <span className="inline-flex gap-0.5" aria-hidden>
      {[1, 2, 3, 4, 5].map((star) => (
        <span
          key={star}
          className={star <= rating ? "text-gold" : "text-sand"}
        >
          ★
        </span>
      ))}
    </span>
  );
}
