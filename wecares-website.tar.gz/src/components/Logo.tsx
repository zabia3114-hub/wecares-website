import { cn } from "@/lib/format";

/**
 * We Cares botanical mark: a stylised leaf pair inside a gold ring.
 * Rendered as inline SVG so it stays crisp at every size and adds no request.
 */
export function WeCaresMark({ className }: { className?: string }) {
  return (
    <svg viewBox="0 0 48 48" className={className} aria-hidden>
      <circle
        cx="24"
        cy="24"
        r="22.5"
        fill="none"
        stroke="currentColor"
        strokeWidth="1"
        opacity="0.55"
      />
      <path
        d="M24 38c-7.4 0-12.4-5-12.4-12.2 0-6.6 4.6-11.6 12.4-15.8 7.8 4.2 12.4 9.2 12.4 15.8C36.4 33 31.4 38 24 38z"
        fill="currentColor"
        opacity="0.14"
      />
      <path
        d="M24 36.5V16.8"
        stroke="currentColor"
        strokeWidth="1.6"
        strokeLinecap="round"
      />
      <path
        d="M24 27c-3.4-.5-6-3-6.6-6.4 3.4.5 6 3 6.6 6.4z"
        fill="currentColor"
      />
      <path
        d="M24 21.5c3.4-.5 6-3 6.6-6.4-3.4.5-6 3-6.6 6.4z"
        fill="currentColor"
        opacity="0.75"
      />
      <path
        d="M24 32.4c-3.1-.4-5.4-2.6-6-5.6 3.1.4 5.4 2.6 6 5.6z"
        fill="currentColor"
        opacity="0.7"
      />
    </svg>
  );
}

export function Logo({
  variant = "dark",
  className,
  compact = false,
  brandName = "We Cares",
  tagline = "Nature's Care, With You",
  logoUrl,
}: {
  /** "dark" = for dark backgrounds, "light" = for light backgrounds */
  variant?: "dark" | "light";
  className?: string;
  compact?: boolean;
  brandName?: string;
  tagline?: string;
  /** Custom uploaded logo. When set it replaces the leaf mark. */
  logoUrl?: string;
}) {
  const markColor =
    variant === "dark" ? "text-gold" : "text-forest-700";
  const wordColor = variant === "dark" ? "text-cream" : "text-forest-800";

  return (
    <span className={cn("inline-flex items-center gap-2.5", className)}>
      {logoUrl ? (
        // eslint-disable-next-line @next/next/no-img-element
        <img
          src={logoUrl}
          alt={`${brandName} logo`}
          className="h-10 w-10 shrink-0 object-contain"
        />
      ) : (
        <WeCaresMark className={cn("h-9 w-9 shrink-0", markColor)} />
      )}
      {!compact ? (
        <span className="flex flex-col leading-none">
          <span
            className={cn(
              "font-display text-[1.35rem] font-semibold tracking-tight sm:text-2xl",
              wordColor,
            )}
          >
            {brandName}
          </span>
          <span
            className={cn(
              "mt-0.5 text-[9px] font-medium uppercase tracking-[0.22em]",
              variant === "dark" ? "text-gold-soft/80" : "text-moss",
            )}
          >
            {tagline}
          </span>
        </span>
      ) : null}
    </span>
  );
}
