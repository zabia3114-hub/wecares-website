"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { Logo } from "@/components/Logo";
import { WhatsAppIcon } from "@/components/WhatsAppButton";
import { HELLO_MESSAGE, buildWhatsAppLink } from "@/lib/whatsapp";
import { useSettings } from "@/components/SettingsProvider";

const COLLECTION_LINKS = [
  { href: "/collections/majoon-wellness", label: "Majoon & Wellness" },
  { href: "/collections/herbal-oils", label: "Herbal Oils" },
  { href: "/collections/mens-care", label: "Men's Care" },
  { href: "/shop", label: "All Products" },
];

const INFO_LINKS = [
  { href: "/shop", label: "Cash on delivery" },
  { href: "/shop", label: "Nationwide delivery" },
  { href: "/checkout", label: "Checkout" },
];

export function SiteFooter() {
  const pathname = usePathname();
  const settings = useSettings();

  // Admin screens are a private back office, not part of the storefront.
  if (pathname?.startsWith("/admin")) return null;

  return (
    <footer className="mt-20 border-t border-gold/20 bg-forest-900 text-cream">
      <div className="mx-auto max-w-7xl px-4 py-14 sm:px-6 lg:px-8">
        <div className="grid gap-10 lg:grid-cols-[1.5fr_1fr_1fr_1.3fr]">
          {/* Brand */}
          <div>
            <Logo variant="dark" />
            <p className="mt-5 max-w-sm text-sm leading-relaxed text-cream/70">
              {settings.footerAbout}
            </p>
            <p className="mt-5 text-[11px] leading-relaxed text-gold-soft/70">
              Our products are herbal preparations. They are not intended to
              diagnose, treat, cure or prevent any disease. Please read the pack
              label and consult a qualified healthcare professional before use.
            </p>
          </div>

          {/* Collections */}
          <nav aria-label="Collections">
            <h3 className="text-[11px] font-semibold uppercase tracking-[0.2em] text-gold">
              Products
            </h3>
            <ul className="mt-4 space-y-2.5 text-sm text-cream/75">
              {COLLECTION_LINKS.map((link) => (
                <li key={link.label}>
                  <Link href={link.href} className="transition hover:text-gold">
                    {link.label}
                  </Link>
                </li>
              ))}
            </ul>
          </nav>

          {/* Ordering */}
          <nav aria-label="Ordering">
            <h3 className="text-[11px] font-semibold uppercase tracking-[0.2em] text-gold">
              Ordering
            </h3>
            <ul className="mt-4 space-y-2.5 text-sm text-cream/75">
              {INFO_LINKS.map((link) => (
                <li key={link.label}>
                  <Link href={link.href} className="transition hover:text-gold">
                    {link.label}
                  </Link>
                </li>
              ))}
            </ul>
          </nav>

          {/* Contact */}
          <div>
            <h3 className="text-[11px] font-semibold uppercase tracking-[0.2em] text-gold">
              Contact &amp; Orders
            </h3>
            <ul className="mt-4 space-y-3 text-sm">
              <li>
                <a
                  href={buildWhatsAppLink(settings.whatsappNumber, HELLO_MESSAGE)}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-2.5 font-semibold text-cream transition hover:text-gold"
                >
                  <WhatsAppIcon className="h-4 w-4 text-[#25D366]" />
                  {settings.whatsappDisplay}
                </a>
              </li>
              <li>
                <a
                  href={`tel:+${settings.whatsappNumber}`}
                  className="flex items-center gap-2.5 text-cream/75 transition hover:text-gold"
                >
                  <span aria-hidden className="text-gold">
                    ☎
                  </span>
                  {settings.phoneNumber}
                </a>
              </li>
              <li>
                <a
                  href={`mailto:${settings.email}`}
                  className="flex items-center gap-2.5 text-cream/75 transition hover:text-gold"
                >
                  <span aria-hidden className="text-gold">
                    ✉
                  </span>
                  {settings.email}
                </a>
              </li>
              <li className="flex items-start gap-2.5 text-cream/75">
                <span aria-hidden className="mt-0.5 text-gold">
                  ⌖
                </span>
                Pakistan · nationwide delivery
              </li>
            </ul>

            <div className="mt-5 rounded-2xl border border-gold/25 bg-forest-800/60 p-4">
              <p className="text-[11px] font-semibold uppercase tracking-[0.16em] text-gold">
                Order hours
              </p>
              <p className="mt-1.5 text-xs text-cream/70">
                WhatsApp orders accepted daily, {settings.orderHours}.
              </p>
            </div>
          </div>
        </div>

        <div className="gold-rule mt-12" />

        <div className="mt-6 flex flex-col gap-3 text-[11px] text-cream/55 sm:flex-row sm:items-center sm:justify-between">
          <p>© {new Date().getFullYear()} We Cares. All rights reserved.</p>
          <p className="flex flex-wrap gap-x-5 gap-y-2">
            <span>Nature&apos;s Care, With You</span>
            <span>Cash on delivery available</span>
            <span>Made in Pakistan</span>
          </p>
        </div>
      </div>
    </footer>
  );
}
