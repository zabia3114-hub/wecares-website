"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { useMemo, useState } from "react";
import { useCart } from "@/components/cart/CartProvider";
import { ProductImage } from "@/components/ProductImage";

import { WhatsAppButton, WhatsAppIcon } from "@/components/WhatsAppButton";
import {
  cn,
  computeTotals,
  formatPkr,
  isValidPkMobile,
  normalizePkMobile,
  FREE_DELIVERY_THRESHOLD_PAISA,
  DELIVERY_EXPRESS_PAISA,
  DELIVERY_STANDARD_PAISA,
  type ShippingMethod,
} from "@/lib/format";
import { HELLO_MESSAGE, orderMessage } from "@/lib/whatsapp";
import { useSettings } from "@/components/SettingsProvider";

const STEPS = ["Your Details", "Delivery Address", "Order & Payment"] as const;

const PROVINCES = [
  "Punjab",
  "Sindh",
  "Khyber Pakhtunkhwa",
  "Balochistan",
  "Gilgit-Baltistan",
  "Azad Jammu & Kashmir",
  "Islamabad Capital Territory",
];

type Form = {
  customerName: string;
  mobile: string;
  address: string;
  city: string;
  province: string;
  orderDetails: string;
  paymentMethod: "cod" | "bank-transfer";
};

const EMPTY: Form = {
  customerName: "",
  mobile: "",
  address: "",
  city: "",
  province: "",
  orderDetails: "",
  paymentMethod: "cod",
};

export function CheckoutForm() {
  const { items, subtotalPaisa, clear, isHydrated } = useCart();
  const settings = useSettings();
  const rates = {
    standardPaisa: settings.shippingStandardRupees * 100,
    expressPaisa: settings.shippingExpressRupees * 100,
    freeOverPaisa: settings.freeShippingOverRupees * 100,
  };
  const router = useRouter();
  const [step, setStep] = useState(0);
  const [form, setForm] = useState<Form>(EMPTY);
  const [shippingMethod, setShippingMethod] =
    useState<ShippingMethod>("standard");
  const [error, setError] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);

  const totals = useMemo(
    () => computeTotals(subtotalPaisa, shippingMethod, rates),
    [subtotalPaisa, shippingMethod, rates.standardPaisa, rates.expressPaisa, rates.freeOverPaisa],
  );

  const update = (key: keyof Form, value: string) =>
    setForm((current) => ({ ...current, [key]: value }));

  function validate(current: number) {
    if (current === 0) {
      if (form.customerName.trim().length < 3)
        return "Please enter your full name.";
      if (!isValidPkMobile(form.mobile))
        return "Please enter a valid Pakistani mobile number (e.g. 03001234567).";
    }
    if (current === 1) {
      if (form.address.trim().length < 10)
        return "Please enter your complete delivery address (house, street, area).";
      if (form.city.trim().length < 2) return "Please enter your city.";
    }
    return null;
  }

  function next() {
    const problem = validate(step);
    if (problem) {
      setError(problem);
      return;
    }
    setError(null);
    setStep((value) => Math.min(STEPS.length - 1, value + 1));
  }

  async function placeOrder(event: React.FormEvent) {
    event.preventDefault();
    setError(null);
    setSubmitting(true);
    try {
      const response = await fetch("/api/orders", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          ...form,
          mobile: normalizePkMobile(form.mobile),
          shippingMethod,
          items: items.map((item) => ({
            slug: item.slug,
            quantity: item.quantity,
          })),
        }),
      });
      const payload = (await response.json()) as {
        orderNumber?: string;
        error?: string;
      };
      if (!response.ok || !payload.orderNumber) {
        throw new Error(payload.error ?? "We could not place your order.");
      }
      clear();
      router.push(`/orders/${payload.orderNumber}`);
    } catch (submitError) {
      setError(
        submitError instanceof Error
          ? submitError.message
          : "Something went wrong. Please try again.",
      );
      setSubmitting(false);
    }
  }

  const waMessage = orderMessage({
    items: items.map((item) => ({
      name: item.name,
      quantity: item.quantity,
      lineTotal: formatPkr(item.pricePaisa * item.quantity),
    })),
    total: formatPkr(totals.totalPaisa),
    customerName: form.customerName,
    city: form.city,
  });

  if (isHydrated && items.length === 0) {
    return (
      <div className="rounded-[1.5rem] border border-dashed border-sand bg-white px-6 py-16 text-center">
        <span className="mx-auto grid h-16 w-16 place-items-center rounded-full bg-forest-800 text-gold">
          <svg viewBox="0 0 24 24" className="h-7 w-7" aria-hidden>
            <path
              d="M6 8h12l-1 12H7L6 8zm3 0a3 3 0 016 0"
              stroke="currentColor"
              strokeWidth="1.4"
              strokeLinecap="round"
              fill="none"
            />
          </svg>
        </span>
        <h2 className="mt-5 font-display text-3xl text-forest-900">
          Your cart is empty
        </h2>
        <p className="mx-auto mt-3 max-w-sm text-sm text-ink/65">
          Add a product to continue, or order directly on WhatsApp at{" "}
          {settings.whatsappDisplay}.
        </p>
        <div className="mt-7 flex flex-col items-center justify-center gap-3 sm:flex-row">
          <Link
            href="/shop"
            className="rounded-full bg-forest-800 px-7 py-3.5 text-sm font-semibold text-cream transition hover:bg-forest-700"
          >
            View Products
          </Link>
          <WhatsAppButton message={HELLO_MESSAGE} />
        </div>
      </div>
    );
  }

  return (
    <form onSubmit={placeOrder} className="grid gap-8 lg:grid-cols-[1.35fr_1fr]">
      <div>
        {/* Step indicator */}
        <ol className="flex items-center gap-2.5">
          {STEPS.map((label, index) => (
            <li key={label} className="flex flex-1 items-center gap-2.5">
              <button
                type="button"
                onClick={() => index < step && setStep(index)}
                className={cn(
                  "grid h-9 w-9 shrink-0 place-items-center rounded-full text-xs font-bold transition",
                  index === step
                    ? "bg-forest-800 text-gold"
                    : index < step
                      ? "bg-moss text-cream"
                      : "bg-white text-ink/40",
                )}
              >
                {index < step ? "✓" : index + 1}
              </button>
              <span
                className={cn(
                  "hidden text-[11px] font-semibold uppercase tracking-[0.14em] sm:block",
                  index === step ? "text-forest-900" : "text-ink/45",
                )}
              >
                {label}
              </span>
              {index < STEPS.length - 1 ? (
                <span className="hidden h-px flex-1 bg-sand sm:block" />
              ) : null}
            </li>
          ))}
        </ol>

        <div className="mt-7 rounded-[1.5rem] border border-sand bg-white p-5 sm:p-7">
          {step === 0 ? (
            <div className="animate-fade-up space-y-5">
              <h2 className="font-display text-2xl text-forest-900">
                Your details
              </h2>
              <p className="text-sm text-ink/60">
                We use this to confirm your order and contact the courier.
              </p>
              <Field
                label="Full name"
                value={form.customerName}
                onChange={(value) => update("customerName", value)}
                placeholder="e.g. Ahmed Raza"
                autoComplete="name"
              />
              <Field
                label="Mobile number"
                value={form.mobile}
                onChange={(value) => update("mobile", value)}
                placeholder="03001234567"
                inputMode="tel"
                autoComplete="tel"
                hint="Please enter a Pakistani mobile number, for example 03001234567."
              />
            </div>
          ) : null}

          {step === 1 ? (
            <div className="animate-fade-up space-y-5">
              <h2 className="font-display text-2xl text-forest-900">
                Delivery address
              </h2>
              <Field
                label="Complete address"
                value={form.address}
                onChange={(value) => update("address", value)}
                placeholder="House / flat, street, block, area, nearest landmark"
                autoComplete="street-address"
                hint="Please include your house or flat number, street and area so the courier can find you easily."
              />
              <div className="grid gap-5 sm:grid-cols-2">
                <Field
                  label="City"
                  value={form.city}
                  onChange={(value) => update("city", value)}
                  placeholder="e.g. Lahore"
                  autoComplete="address-level2"
                />
                <label className="block text-[11px] font-semibold uppercase tracking-[0.14em] text-ink/55">
                  Province
                  <select
                    value={form.province}
                    onChange={(event) => update("province", event.target.value)}
                    className="mt-2 w-full rounded-2xl border border-sand bg-white px-4 py-3.5 text-sm font-normal normal-case tracking-normal text-ink transition focus:border-gold focus:outline-none"
                  >
                    <option value="">Select province</option>
                    {PROVINCES.map((province) => (
                      <option key={province} value={province}>
                        {province}
                      </option>
                    ))}
                  </select>
                </label>
              </div>
            </div>
          ) : null}

          {step === 2 ? (
            <div className="animate-fade-up space-y-6">
              <h2 className="font-display text-2xl text-forest-900">
                Order details &amp; payment
              </h2>

              <label className="block text-[11px] font-semibold uppercase tracking-[0.14em] text-ink/55">
                Order details / notes (optional)
                <textarea
                  rows={3}
                  value={form.orderDetails}
                  onChange={(event) => update("orderDetails", event.target.value)}
                  placeholder="Any delivery instructions, preferred time, or gift note"
                  className="mt-2 w-full rounded-2xl border border-sand bg-white px-4 py-3.5 text-sm font-normal normal-case tracking-normal text-ink transition focus:border-gold focus:outline-none"
                />
              </label>

              <div className="space-y-3">
                <p className="text-[11px] font-semibold uppercase tracking-[0.14em] text-ink/55">
                  Delivery speed
                </p>
                {(
                  [
                    {
                      value: "standard",
                      title: "Standard · 2–4 working days",
                      copy:
                        subtotalPaisa >= FREE_DELIVERY_THRESHOLD_PAISA
                          ? "Free on this order"
                          : subtotalPaisa >= settings.freeShippingOverRupees * 100
                            ? "Free on this order"
                            : `${formatPkr(settings.shippingStandardRupees * 100)} — free over ${formatPkr(settings.freeShippingOverRupees * 100)}`,
                    },
                    {
                      value: "express",
                      title: "Express · 1–2 working days",
                      copy: formatPkr(settings.shippingExpressRupees * 100),
                    },
                  ] as const
                ).map((option) => (
                  <button
                    key={option.value}
                    type="button"
                    onClick={() => setShippingMethod(option.value)}
                    className={cn(
                      "flex w-full items-center justify-between gap-4 rounded-2xl border px-5 py-4 text-left transition",
                      shippingMethod === option.value
                        ? "border-forest-800 bg-cream-deep"
                        : "border-sand bg-white hover:border-gold",
                    )}
                  >
                    <span>
                      <span className="block text-sm font-semibold text-forest-900">
                        {option.title}
                      </span>
                      <span className="block text-xs text-ink/60">
                        {option.copy}
                      </span>
                    </span>
                    <span
                      className={cn(
                        "grid h-5 w-5 shrink-0 place-items-center rounded-full border text-[10px]",
                        shippingMethod === option.value
                          ? "border-forest-800 bg-forest-800 text-gold"
                          : "border-sand",
                      )}
                    >
                      {shippingMethod === option.value ? "✓" : ""}
                    </span>
                  </button>
                ))}
              </div>

              <div className="space-y-3">
                <p className="text-[11px] font-semibold uppercase tracking-[0.14em] text-ink/55">
                  Payment method
                </p>
                {(
                  [
                    settings.codEnabled
                      ? {
                          value: "cod" as const,
                          title: "Cash on Delivery",
                          copy: "Pay in cash when your parcel arrives.",
                        }
                      : null,
                    settings.bankTransferEnabled
                      ? {
                          value: "bank-transfer" as const,
                          title: "Bank Transfer",
                          copy: "We will share account details on WhatsApp after you order.",
                        }
                      : null,
                  ].filter(Boolean) as Array<{
                    value: "cod" | "bank-transfer";
                    title: string;
                    copy: string;
                  }>
                ).map((option) => (
                  <button
                    key={option.value}
                    type="button"
                    onClick={() => update("paymentMethod", option.value)}
                    className={cn(
                      "flex w-full items-center justify-between gap-4 rounded-2xl border px-5 py-4 text-left transition",
                      form.paymentMethod === option.value
                        ? "border-forest-800 bg-cream-deep"
                        : "border-sand bg-white hover:border-gold",
                    )}
                  >
                    <span>
                      <span className="block text-sm font-semibold text-forest-900">
                        {option.title}
                      </span>
                      <span className="block text-xs text-ink/60">
                        {option.copy}
                      </span>
                    </span>
                    <span
                      className={cn(
                        "grid h-5 w-5 shrink-0 place-items-center rounded-full border text-[10px]",
                        form.paymentMethod === option.value
                          ? "border-forest-800 bg-forest-800 text-gold"
                          : "border-sand",
                      )}
                    >
                      {form.paymentMethod === option.value ? "✓" : ""}
                    </span>
                  </button>
                ))}
              </div>
            </div>
          ) : null}

          {error ? (
            <p className="mt-6 rounded-2xl bg-moss/12 px-4 py-3 text-sm font-medium text-moss">
              {error}
            </p>
          ) : null}

          <div className="mt-7 flex flex-wrap items-center gap-3">
            {step > 0 ? (
              <button
                type="button"
                onClick={() => setStep((value) => value - 1)}
                className="rounded-full border border-sand bg-white px-6 py-3.5 text-sm font-semibold text-forest-800 transition hover:border-gold"
              >
                Back
              </button>
            ) : null}

            {step < STEPS.length - 1 ? (
              <button
                type="button"
                onClick={next}
                className="flex-1 rounded-full bg-forest-800 px-7 py-4 text-sm font-semibold text-cream transition hover:bg-forest-700 sm:flex-none"
              >
                Continue
              </button>
            ) : (
              <button
                type="submit"
                disabled={submitting}
                className="flex-1 rounded-full bg-gold px-7 py-4 text-sm font-semibold text-forest-950 transition hover:bg-gold-soft disabled:opacity-60 sm:flex-none"
              >
                {submitting
                  ? "Placing order…"
                  : `Place Order · ${formatPkr(totals.totalPaisa)}`}
              </button>
            )}
          </div>

          {step === STEPS.length - 1 ? (
            <div className="mt-5 rounded-2xl border border-gold/30 bg-cream p-4">
              <p className="flex items-center gap-2 text-xs font-semibold text-forest-900">
                <WhatsAppIcon className="h-4 w-4 text-[#25D366]" />
                Prefer WhatsApp?
              </p>
              <p className="mt-1.5 text-xs leading-relaxed text-ink/65">
                Send this order to us on {settings.whatsappDisplay} and we will
                confirm it manually.
              </p>
              <WhatsAppButton
                message={waMessage}
                size="sm"
                className="mt-3 w-full sm:w-auto"
              >
                Send order on WhatsApp
              </WhatsAppButton>
            </div>
          ) : null}
        </div>

        <p className="mt-4 text-center text-xs text-ink/55">
          By placing an order you agree to our terms. Herbal preparations —
          please read the pack label before use.
        </p>
      </div>

      {/* Order summary */}
      <aside className="lg:sticky lg:top-32 lg:self-start">
        <div className="rounded-[1.5rem] border border-sand bg-white p-6">
          <h2 className="font-display text-xl text-forest-900">Order summary</h2>
          <ul className="mt-5 space-y-4">
            {items.map((item) => (
              <li key={item.slug} className="flex gap-3">
                <div className="relative h-16 w-14 shrink-0 overflow-hidden rounded-xl bg-forest-800">
                  <ProductImage
                    src={item.image}
                    alt={item.name}
                    name={item.name}
                    sizes="56px"
                  />
                  <span className="absolute right-0.5 top-0.5 grid h-5 w-5 place-items-center rounded-full bg-forest-900 text-[10px] font-bold text-gold">
                    {item.quantity}
                  </span>
                </div>
                <div className="min-w-0 flex-1">
                  <p className="truncate text-sm font-semibold text-forest-900">
                    {item.name}
                  </p>
                  <p className="text-xs text-ink/55">
                    {formatPkr(item.pricePaisa)} each
                  </p>
                </div>
                <p className="shrink-0 text-sm font-semibold text-forest-900">
                  {formatPkr(item.pricePaisa * item.quantity)}
                </p>
              </li>
            ))}
          </ul>

          <dl className="mt-6 space-y-2 border-t border-sand pt-5 text-sm">
            <div className="flex justify-between text-ink/60">
              <dt>Subtotal</dt>
              <dd className="font-semibold text-forest-900">
                {formatPkr(subtotalPaisa)}
              </dd>
            </div>
            <div className="flex justify-between text-ink/60">
              <dt>Delivery</dt>
              <dd className="font-semibold text-forest-900">
                {totals.shippingPaisa === 0
                  ? "Free"
                  : formatPkr(totals.shippingPaisa)}
              </dd>
            </div>
            <div className="flex justify-between border-t border-sand pt-3">
              <dt className="text-base font-semibold text-forest-900">
                Total amount
              </dt>
              <dd className="font-display text-2xl font-semibold text-forest-900">
                {formatPkr(totals.totalPaisa)}
              </dd>
            </div>
          </dl>
          <p className="mt-2 text-[11px] text-ink/50">
            Inclusive of all applicable taxes.
          </p>

          <ul className="mt-6 space-y-2 text-xs text-ink/60">
            {[
              "Nationwide delivery across Pakistan",
              "Cash on delivery available",
              "Support on WhatsApp",
            ].map((line) => (
              <li key={line} className="flex items-center gap-2">
                <span className="text-moss">✓</span>
                {line}
              </li>
            ))}
          </ul>
        </div>
      </aside>
    </form>
  );
}

function Field({
  label,
  value,
  onChange,
  placeholder,
  hint,
  inputMode,
  autoComplete,
}: {
  label: string;
  value: string;
  onChange: (value: string) => void;
  placeholder?: string;
  hint?: string;
  inputMode?: "text" | "tel" | "numeric";
  autoComplete?: string;
}) {
  return (
    <label className="block text-[11px] font-semibold uppercase tracking-[0.14em] text-ink/55">
      {label}
      <input
        value={value}
        inputMode={inputMode}
        autoComplete={autoComplete}
        placeholder={placeholder}
        onChange={(event) => onChange(event.target.value)}
        className="mt-2 w-full rounded-2xl border border-sand bg-white px-4 py-3.5 text-sm font-normal normal-case tracking-normal text-ink transition focus:border-gold focus:outline-none"
      />
      {hint ? (
        <span className="mt-1.5 block text-[11px] font-normal normal-case tracking-normal text-ink/50">
          {hint}
        </span>
      ) : null}
    </label>
  );
}

