"use client";

import { createContext, useContext, type ReactNode } from "react";
import type { SiteSettings } from "@/lib/settings-types";

const SettingsContext = createContext<SiteSettings | null>(null);

/**
 * Supplies editable site settings to client components. The values are fetched
 * on the server (layout) and passed down, so no database code ever runs in the
 * browser bundle.
 */
export function SettingsProvider({
  settings,
  children,
}: {
  settings: SiteSettings;
  children: ReactNode;
}) {
  return (
    <SettingsContext.Provider value={settings}>
      {children}
    </SettingsContext.Provider>
  );
}

export function useSettings(): SiteSettings {
  const context = useContext(SettingsContext);
  // Fall back to defaults so a missing provider never crashes the UI.
  if (!context) {
    throw new Error("useSettings must be used inside SettingsProvider");
  }
  return context;
}
