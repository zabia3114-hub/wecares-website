import { sql } from "drizzle-orm";
import { db } from "@/db";
import { collections, products, reviews } from "@/db/schema";
import catalogJson from "@/data/catalog.json";

type SeedProduct = {
  slug: string;
  name: string;
  subtitle: string;
  description: string;
  howToUse: string;
  disclaimer?: string;
  collectionSlug: string;
  categoryLabel: string;
  pricePaisa: number;
  compareAtPaisa?: number;
  images: string[];
  highlights: string[];
  ingredients: string[];
  netWeight: string;
  suitability?: string;
  isFeatured?: boolean;
  isNew?: boolean;
  isBestseller?: boolean;
  stock?: number;
  sortOrder?: number;
};

type SeedCatalog = {
  collections: Array<{
    slug: string;
    name: string;
    tagline: string;
    description: string;
    image: string;
    sortOrder: number;
  }>;
  products: SeedProduct[];
};

const catalog = catalogJson as SeedCatalog;

// Stable key so concurrent serverless instances contend on the same lock.
const SEED_LOCK_KEY = 918273645;

export async function seedDatabase({ force = false }: { force?: boolean } = {}) {
  return db.transaction(async (tx) => {
    await tx.execute(sql`select pg_advisory_xact_lock(${SEED_LOCK_KEY})`);

    const existing = await tx
      .select({ count: sql<number>`count(*)::int` })
      .from(products);

    if ((existing[0]?.count ?? 0) > 0 && !force) {
      return { seeded: false, products: existing[0]?.count ?? 0 };
    }

    if (force) {
      await tx.execute(
        sql`truncate table ${products}, ${collections} restart identity cascade`,
      );
    }

    await tx
      .insert(collections)
      .values(catalog.collections)
      .onConflictDoNothing({ target: collections.slug });

    await tx
      .insert(products)
      .values(
        catalog.products.map((product) => ({
          slug: product.slug,
          name: product.name,
          subtitle: product.subtitle,
          description: product.description,
          howToUse: product.howToUse,
          disclaimer:
            product.disclaimer ??
            "A herbal preparation. Not intended to diagnose, treat, cure or prevent any disease. Full ingredient and usage information is printed on the pack label.",
          collectionSlug: product.collectionSlug,
          categoryLabel: product.categoryLabel,
          pricePaisa: product.pricePaisa,
          compareAtPaisa: product.compareAtPaisa ?? null,
          images: product.images,
          highlights: product.highlights,
          ingredients: product.ingredients,
          netWeight: product.netWeight,
          suitability: product.suitability ?? "For men & women",
          isFeatured: product.isFeatured ?? false,
          isNew: product.isNew ?? false,
          isBestseller: product.isBestseller ?? false,
          stock: product.stock ?? 50,
          sortOrder: product.sortOrder ?? 99,
        })),
      )
      .onConflictDoNothing({ target: products.slug });

    const allProducts = await tx
      .select({ id: products.id, slug: products.slug })
      .from(products);
    const idBySlug = new Map(allProducts.map((row) => [row.slug, row.id]));

    // Seed a small set of reviews. One is left pending so the moderation flow
    // is visible immediately in the admin panel.
    const seedReviews: Array<{
      slug: string;
      authorName: string;
      authorMobile: string;
      rating: number;
      title: string;
      body: string;
      status: "approved" | "pending";
      isVerifiedBuyer: boolean;
    }> = [
      {
        slug: "majoon-booster",
        authorName: "Kashif Mehmood",
        authorMobile: "03001234567",
        rating: 5,
        title: "Excellent quality and packaging",
        body: "The majoon arrived well sealed and fresh. Packaging is premium and the jar is easy to reseal. Delivery to Lahore took three days.",
        status: "approved",
        isVerifiedBuyer: true,
      },
      {
        slug: "majoon-booster",
        authorName: "Faisal Nadeem",
        authorMobile: "03217654321",
        rating: 4,
        title: "Good product, neat packing",
        body: "Taste is as expected for a traditional majoon and there is no artificial colour. Would have liked a slightly larger jar option.",
        status: "approved",
        isVerifiedBuyer: true,
      },
      {
        slug: "joint-pain-relief-oil",
        authorName: "Nadia Iqbal",
        authorMobile: "03339876543",
        rating: 5,
        title: "Easy to apply, no strong smell",
        body: "The bottle is small and travel friendly with a controlled applicator. Absorbs quickly and the fragrance is mild.",
        status: "approved",
        isVerifiedBuyer: false,
      },
      {
        slug: "the-original-8-men-oil",
        authorName: "Usman Tariq",
        authorMobile: "03451112233",
        rating: 4,
        title: "Neat and professional",
        body: "Ordering was simple and the team confirmed my order on WhatsApp quickly. Product arrived as described in the listing.",
        status: "approved",
        isVerifiedBuyer: true,
      },
      {
        slug: "the-original-8-men-oil",
        authorName: "Zeeshan Ali",
        authorMobile: "03115556677",
        rating: 5,
        title: "Waiting for approval",
        body: "This review is intentionally pending moderation so the approve and hide actions in the admin panel can be tested.",
        status: "pending",
        isVerifiedBuyer: false,
      },
    ];

    const reviewRows = seedReviews.flatMap((review) => {
      const productId = idBySlug.get(review.slug);
      if (!productId) return [];
      return [
        {
          productId,
          authorName: review.authorName,
          authorMobile: review.authorMobile,
          rating: review.rating,
          title: review.title,
          body: review.body,
          status: review.status,
          isVerifiedBuyer: review.isVerifiedBuyer,
        },
      ];
    });

    if (reviewRows.length > 0) {
      await tx.insert(reviews).values(reviewRows);
    }

    return { seeded: true, products: allProducts.length };
  });
}
