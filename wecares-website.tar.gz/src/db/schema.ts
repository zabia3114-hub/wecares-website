import {
  boolean,
  integer,
  jsonb,
  pgTable,
  serial,
  text,
  timestamp,
  uniqueIndex,
} from "drizzle-orm/pg-core";

/**
 * All monetary values are stored as integer minor units (paisa).
 * Rs. 6,500.00 => 650000
 */

export type OrderLineItem = {
  productId: number;
  slug: string;
  name: string;
  image: string;
  unitPricePaisa: number;
  quantity: number;
};

export const collections = pgTable(
  "collections",
  {
    id: serial("id").primaryKey(),
    slug: text("slug").notNull(),
    name: text("name").notNull(),
    tagline: text("tagline").notNull(),
    description: text("description").notNull(),
    image: text("image").notNull(),
    sortOrder: integer("sort_order").notNull().default(0),
  },
  (table) => [uniqueIndex("collections_slug_key").on(table.slug)],
);

export const products = pgTable(
  "products",
  {
    id: serial("id").primaryKey(),
    slug: text("slug").notNull(),
    name: text("name").notNull(),
    subtitle: text("subtitle").notNull(),
    description: text("description").notNull(),
    howToUse: text("how_to_use").notNull(),
    disclaimer: text("disclaimer").notNull().default(""),
    collectionSlug: text("collection_slug").notNull(),
    /** Legacy free-text label kept for compatibility with existing rows. */
    categoryLabel: text("category_label").notNull().default("Herbal Product"),
    /** Editable category reference. Null means "uncategorised". */
    categoryId: integer("category_id"),
    pricePaisa: integer("price_paisa").notNull(),
    compareAtPaisa: integer("compare_at_paisa"),
    images: jsonb("images").$type<string[]>().notNull().default([]),
    highlights: jsonb("highlights").$type<string[]>().notNull().default([]),
    ingredients: jsonb("ingredients").$type<string[]>().notNull().default([]),
    netWeight: text("net_weight").notNull(),
    suitability: text("suitability").notNull().default("For men & women"),
    isFeatured: boolean("is_featured").notNull().default(false),
    isNew: boolean("is_new").notNull().default(false),
    isBestseller: boolean("is_bestseller").notNull().default(false),
    /** When false the product is hidden from the storefront but kept in admin. */
    isActive: boolean("is_active").notNull().default(true),
    stock: integer("stock").notNull().default(50),
    sortOrder: integer("sort_order").notNull().default(0),
    createdAt: timestamp("created_at", { withTimezone: true })
      .notNull()
      .defaultNow(),
  },
  (table) => [uniqueIndex("products_slug_key").on(table.slug)],
);

export const orders = pgTable(
  "orders",
  {
    id: serial("id").primaryKey(),
    orderNumber: text("order_number").notNull(),
    customerName: text("customer_name").notNull(),
    mobile: text("mobile").notNull(),
    address: text("address").notNull(),
    city: text("city").notNull(),
    province: text("province").notNull().default(""),
    orderDetails: text("order_details").notNull().default(""),
    paymentMethod: text("payment_method").notNull().default("cod"),
    shippingMethod: text("shipping_method").notNull().default("standard"),
    items: jsonb("items").$type<OrderLineItem[]>().notNull().default([]),
    subtotalPaisa: integer("subtotal_paisa").notNull(),
    shippingPaisa: integer("shipping_paisa").notNull().default(0),
    totalPaisa: integer("total_paisa").notNull(),
    status: text("status").notNull().default("new"),
    createdAt: timestamp("created_at", { withTimezone: true })
      .notNull()
      .defaultNow(),
  },
  (table) => [uniqueIndex("orders_order_number_key").on(table.orderNumber)],
);

/**
 * Customer reviews. `status` controls storefront visibility so the owner can
 * moderate before publishing: pending -> approved | hidden.
 */
export const reviews = pgTable("reviews", {
  id: serial("id").primaryKey(),
  productId: integer("product_id")
    .notNull()
    .references(() => products.id, { onDelete: "cascade" }),
  authorName: text("author_name").notNull(),
  authorMobile: text("author_mobile").notNull().default(""),
  rating: integer("rating").notNull(),
  title: text("title").notNull().default(""),
  body: text("body").notNull(),
  /** pending | approved | hidden */
  status: text("status").notNull().default("pending"),
  isVerifiedBuyer: boolean("is_verified_buyer").notNull().default(false),
  createdAt: timestamp("created_at", { withTimezone: true })
    .notNull()
    .defaultNow(),
});

/**
 * Admin accounts. Passwords are stored as scrypt hashes (salt + derived key),
 * never as plain text.
 */
export const adminUsers = pgTable(
  "admin_users",
  {
    id: serial("id").primaryKey(),
    username: text("username").notNull(),
    passwordHash: text("password_hash").notNull(),
    createdAt: timestamp("created_at", { withTimezone: true })
      .notNull()
      .defaultNow(),
    lastLoginAt: timestamp("last_login_at", { withTimezone: true }),
  },
  (table) => [uniqueIndex("admin_users_username_key").on(table.username)],
);

export type Product = typeof products.$inferSelect;
export type Collection = typeof collections.$inferSelect;
export type Order = typeof orders.$inferSelect;
export type Review = typeof reviews.$inferSelect;
export type AdminUser = typeof adminUsers.$inferSelect;

/**
 * Site-wide editable settings (brand, theme, fonts, contact, shipping).
 * Stored as a simple key/value pair so the owner can change them from the
 * admin panel without touching code.
 */
export const settings = pgTable("settings", {
  key: text("key").primaryKey(),
  value: text("value").notNull().default(""),
  updatedAt: timestamp("updated_at", { withTimezone: true })
    .notNull()
    .defaultNow(),
});

export type Setting = typeof settings.$inferSelect;

/**
 * In-app alerts for the store owner, e.g. a new order has been placed.
 * Created server-side when an order is written, cleared from the admin bell.
 */
export const notifications = pgTable("notifications", {
  id: serial("id").primaryKey(),
  type: text("type").notNull().default("new-order"),
  title: text("title").notNull(),
  body: text("body").notNull().default(""),
  orderNumber: text("order_number"),
  isRead: boolean("is_read").notNull().default(false),
  createdAt: timestamp("created_at", { withTimezone: true })
    .notNull()
    .defaultNow(),
});

export type Notification = typeof notifications.$inferSelect;

/**
 * Uploaded product images, stored as bytes in the database.
 * Writing into `public/` at runtime does not work on most hosts (the static
 * file list is captured at build time), so uploads are served through
 * /api/images/[id] instead.
 */
export const images = pgTable(
  "images",
  {
    id: serial("id").primaryKey(),
    filename: text("filename").notNull(),
    mimeType: text("mime_type").notNull(),
    /** Base64-encoded image bytes. */
    data: text("data").notNull(),
    byteSize: integer("byte_size").notNull(),
    createdAt: timestamp("created_at", { withTimezone: true })
      .notNull()
      .defaultNow(),
  },
  (table) => [uniqueIndex("images_filename_key").on(table.filename)],
);

export type StoredImage = typeof images.$inferSelect;

/**
 * Editable storefront categories/segments. Managed in the admin panel; products
 * reference these by id so renaming a category updates the storefront
 * automatically without touching any product row.
 */
export const categories = pgTable(
  "categories",
  {
    id: serial("id").primaryKey(),
    slug: text("slug").notNull(),
    name: text("name").notNull(),
    description: text("description").notNull().default(""),
    /** Optional image URL (uploaded via /api/admin/upload or a path). */
    image: text("image").notNull().default(""),
    /** Disabled categories are hidden from the storefront but kept here. */
    isActive: boolean("is_active").notNull().default(true),
    sortOrder: integer("sort_order").notNull().default(0),
    createdAt: timestamp("created_at", { withTimezone: true })
      .notNull()
      .defaultNow(),
  },
  (table) => [uniqueIndex("categories_slug_key").on(table.slug)],
);

export type Category = typeof categories.$inferSelect;
