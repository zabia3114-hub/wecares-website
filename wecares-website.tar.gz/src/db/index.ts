import { drizzle } from "drizzle-orm/node-postgres";
import { Pool } from "pg";

/**
 * Lazily-created Postgres pool.
 *
 * Creating the pool at import time (and throwing if DATABASE_URL is missing)
 * breaks `next build` on hosts such as Vercel, where static pages collect
 * their config before every environment variable is guaranteed to be present.
 * Resolving the pool on first *use* keeps the build safe while still failing
 * clearly at request time if the variable is genuinely missing.
 */
const globalForDb = globalThis as typeof globalThis & {
  __wecaresPool?: Pool;
  __wecaresDb?: ReturnType<typeof drizzle>;
};

function getPool() {
  if (globalForDb.__wecaresPool) return globalForDb.__wecaresPool;

  const databaseUrl = process.env.DATABASE_URL;
  if (!databaseUrl) {
    throw new Error(
      "DATABASE_URL is not set. Add it in your hosting provider's environment variables.",
    );
  }

  const pool = new Pool({
    connectionString: databaseUrl,
    // Managed providers (Neon, Supabase, Vercel Postgres) require TLS.
    ssl: /sslmode=require/.test(databaseUrl)
      ? { rejectUnauthorized: false }
      : undefined,
    max: 5,
  });

  globalForDb.__wecaresPool = pool;
  return pool;
}

export function getDb() {
  if (!globalForDb.__wecaresDb) {
    globalForDb.__wecaresDb = drizzle(getPool());
  }
  return globalForDb.__wecaresDb;
}

/** Lazy proxy so `import { db } from "@/db"` keeps working unchanged. */
export const db = new Proxy({} as ReturnType<typeof drizzle>, {
  get(_target, prop, receiver) {
    const real = getDb() as unknown as Record<string | symbol, unknown>;
    const value = Reflect.get(real, prop, receiver);
    return typeof value === "function" ? value.bind(real) : value;
  },
});

export { getPool };
