import Link from "next/link";
import { WeCaresMark } from "@/components/Logo";
import { WhatsAppButton } from "@/components/WhatsAppButton";
import { HELLO_MESSAGE, WHATSAPP_NUMBER_DISPLAY } from "@/lib/whatsapp";

/**
 * Segment-level not-found for order lookups. Rendering it here (rather than
 * only through the root boundary) is what makes the response carry a real 404
 * status, so invalid order references cannot be mistaken for valid pages.
 */
export default function OrderNotFound() {
  return (
    <div className="mx-auto flex max-w-2xl flex-col items-center px-4 py-20 text-center lg:py-28">
      <WeCaresMark className="h-14 w-14 text-gold" />
      <h1 className="mt-6 font-display text-3xl text-forest-900 sm:text-4xl">
        Order not found
      </h1>
      <p className="mt-4 max-w-md text-[15px] leading-relaxed text-ink/65">
        We could not find an order with that reference. Please check the order
        number in your confirmation, or contact us and we will look it up for
        you.
      </p>
      <div className="mt-8 flex w-full flex-col justify-center gap-3 sm:w-auto sm:flex-row">
        <Link
          href="/shop"
          className="rounded-full bg-forest-800 px-7 py-3.5 text-sm font-semibold text-cream transition hover:bg-forest-700"
        >
          Continue shopping
        </Link>
        <Link
          href="/"
          className="rounded-full border border-forest-800 px-7 py-3.5 text-sm font-semibold text-forest-800 transition hover:bg-forest-800 hover:text-cream"
        >
          Back to home
        </Link>
      </div>
      <p className="mt-8 text-xs text-ink/50">
        Need help? WhatsApp us on {WHATSAPP_NUMBER_DISPLAY}
      </p>
      <WhatsAppButton message={HELLO_MESSAGE} size="sm" className="mt-3" />
    </div>
  );
}
