import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { ProductImage } from "@/components/ProductImage";
import { Reveal } from "@/components/ui/Reveal";
import { WhatsAppButton } from "@/components/WhatsAppButton";
import { formatDate, formatPkr } from "@/lib/format";
import { getOrderByNumber } from "@/lib/queries";
import { normalizeOrderStatus, ORDER_STATUS_LABELS } from "@/lib/status";
import { WHATSAPP_NUMBER_DISPLAY } from "@/lib/whatsapp";

/** Customer-friendly copy for each order status. */
const STATUS_MESSAGES: Record<string, string> = {
  new: "We have received your order and will confirm it shortly.",
  confirmed: "Your order is confirmed and is being prepared.",
  processing: "Your order is being packed for dispatch.",
  shipped: "Your order has been dispatched and is on its way.",
  delivered: "Your order has been delivered. Thank you for shopping with us.",
  cancelled: "This order has been cancelled. Contact us on WhatsApp if this looks wrong.",
};

export const dynamic = "force-dynamic";

type Params = Promise<{ orderNumber: string }>;

export async function generateMetadata({
  params,
}: {
  params: Params;
}): Promise<Metadata> {
  const { orderNumber } = await params;
  const order = await getOrderByNumber(orderNumber);

  // Raising the 404 here (not only in the page body) makes the HTTP status
  // correct — otherwise the not-found UI renders with a 200 status, which
  // makes order-reference enumeration ambiguous to crawlers and monitoring.
  if (!order) notFound();

  return {
    title: "Order Confirmed",
    description: "Your We Cares order has been received.",
    robots: { index: false, follow: false },
  };
}

export default async function OrderPage({ params }: { params: Params }) {
  const { orderNumber } = await params;
  const order = await getOrderByNumber(orderNumber);
  if (!order) notFound();

  const paymentLabel =
    order.paymentMethod === "bank-transfer" ? "Bank Transfer" : "Cash on Delivery";
  const status = normalizeOrderStatus(order.status);

  const waMessage = [
    "Assalam o Alaikum! I have placed an order on the We Cares website.",
    "",
    `Order ref: ${order.orderNumber}`,
    `Name: ${order.customerName}`,
    `Mobile: ${order.mobile}`,
    `City: ${order.city}`,
    `Total: ${formatPkr(order.totalPaisa)}`,
    "",
    "Please confirm my order. Thank you!",
  ].join("\n");

  return (
    <div className="mx-auto max-w-4xl px-4 py-12 sm:px-6 lg:px-8 lg:py-16">
      <Reveal className="rounded-[1.75rem] border border-gold/30 bg-white p-7 text-center sm:p-11">
        <span className="mx-auto grid h-16 w-16 place-items-center rounded-full bg-moss/15 text-2xl text-moss">
          ✓
        </span>
        <p className="mt-6 text-[11px] font-semibold uppercase tracking-[0.28em] text-moss">
          Order received
        </p>
        <h1 className="mt-3 font-display text-3xl text-forest-900 sm:text-5xl">
          Thank you, {order.customerName.split(" ")[0]}!
        </h1>
        <p className="mx-auto mt-4 max-w-lg text-[15px] leading-relaxed text-ink/70">
          Your order has been recorded. We will contact you on{" "}
          <span className="font-semibold text-forest-900">{order.mobile}</span>{" "}
          to confirm the details and arrange delivery.
        </p>

        {/* Live order status, updated from the database */}
        <div className="mx-auto mt-8 max-w-xl rounded-2xl border border-gold/30 bg-cream px-5 py-4">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <p className="text-[10px] font-semibold uppercase tracking-[0.16em] text-moss">
              Order status
            </p>
            <span className="rounded-full bg-forest-800 px-3 py-1 text-[10px] font-bold uppercase tracking-[0.12em] text-gold-soft">
              {ORDER_STATUS_LABELS[status]}
            </span>
          </div>
          <p className="mt-2 text-sm leading-relaxed text-ink/70">
            {STATUS_MESSAGES[status]}
          </p>
        </div>

        <dl className="mx-auto mt-8 grid max-w-xl gap-3 text-left sm:grid-cols-3">
          <div className="rounded-2xl bg-cream px-4 py-3">
            <dt className="text-[10px] font-semibold uppercase tracking-[0.16em] text-ink/50">
              Order reference
            </dt>
            <dd className="mt-1 text-sm font-bold text-forest-900">
              {order.orderNumber}
            </dd>
          </div>
          <div className="rounded-2xl bg-cream px-4 py-3">
            <dt className="text-[10px] font-semibold uppercase tracking-[0.16em] text-ink/50">
              Placed on
            </dt>
            <dd className="mt-1 text-sm font-bold text-forest-900">
              {formatDate(order.createdAt)}
            </dd>
          </div>
          <div className="rounded-2xl bg-cream px-4 py-3">
            <dt className="text-[10px] font-semibold uppercase tracking-[0.16em] text-ink/50">
              Total amount
            </dt>
            <dd className="mt-1 text-sm font-bold text-forest-900">
              {formatPkr(order.totalPaisa)}
            </dd>
          </div>
        </dl>

        <div className="mt-8 flex flex-col items-center justify-center gap-3 sm:flex-row">
          <WhatsAppButton
            size="lg"
            message={waMessage}
            label={`Confirm order ${order.orderNumber} on WhatsApp`}
            className="w-full sm:w-auto"
          >
            Confirm on WhatsApp
          </WhatsAppButton>
          <Link
            href="/shop"
            className="inline-flex w-full items-center justify-center rounded-full border border-forest-800 px-7 py-4 text-[15px] font-semibold text-forest-800 transition hover:bg-forest-800 hover:text-cream sm:w-auto"
          >
            Continue shopping
          </Link>
        </div>
      </Reveal>

      <Reveal delay={100} className="mt-7 grid gap-7 lg:grid-cols-[1.3fr_1fr]">
        <div className="rounded-[1.5rem] border border-sand bg-white p-6">
          <h2 className="font-display text-xl text-forest-900">Your order</h2>
          <ul className="mt-5 space-y-4">
            {order.items.map((item) => (
              <li key={item.slug} className="flex items-center gap-4">
                <Link
                  href={`/products/${item.slug}`}
                  className="relative h-20 w-16 shrink-0 overflow-hidden rounded-2xl bg-forest-800"
                >
                  <ProductImage
                    src={item.image}
                    alt={item.name}
                    name={item.name}
                    sizes="64px"
                  />
                </Link>
                <div className="min-w-0 flex-1">
                  <Link
                    href={`/products/${item.slug}`}
                    className="text-sm font-semibold text-forest-900 transition hover:text-moss"
                  >
                    {item.name}
                  </Link>
                  <p className="text-xs text-ink/55">
                    Qty {item.quantity} · {formatPkr(item.unitPricePaisa)} each
                  </p>
                </div>
                <p className="shrink-0 text-sm font-semibold text-forest-900">
                  {formatPkr(item.unitPricePaisa * item.quantity)}
                </p>
              </li>
            ))}
          </ul>

          <dl className="mt-6 space-y-2 border-t border-sand pt-5 text-sm">
            <div className="flex justify-between text-ink/60">
              <dt>Subtotal</dt>
              <dd className="font-semibold text-forest-900">
                {formatPkr(order.subtotalPaisa)}
              </dd>
            </div>
            <div className="flex justify-between text-ink/60">
              <dt>
                Delivery ({order.shippingMethod === "express" ? "Express" : "Standard"})
              </dt>
              <dd className="font-semibold text-forest-900">
                {order.shippingPaisa === 0
                  ? "Free"
                  : formatPkr(order.shippingPaisa)}
              </dd>
            </div>
            <div className="flex justify-between border-t border-sand pt-3">
              <dt className="text-base font-semibold text-forest-900">
                Total amount
              </dt>
              <dd className="font-display text-2xl font-semibold text-forest-900">
                {formatPkr(order.totalPaisa)}
              </dd>
            </div>
          </dl>
          <p className="mt-2 text-[11px] text-ink/50">
            Inclusive of all applicable taxes.
          </p>
        </div>

        <div className="space-y-6">
          <div className="rounded-[1.5rem] border border-sand bg-white p-6">
            <h2 className="font-display text-xl text-forest-900">
              Delivery details
            </h2>
            <address className="mt-3 text-sm not-italic leading-relaxed text-ink/70">
              <span className="font-semibold text-forest-900">
                {order.customerName}
              </span>
              <br />
              {order.mobile}
              <br />
              {order.address}
              <br />
              {order.city}
              {order.province ? `, ${order.province}` : ""}
            </address>
            <div className="mt-5 space-y-2 border-t border-sand pt-4 text-xs text-ink/60">
              <p>
                <span className="font-semibold text-forest-900">Payment:</span>{" "}
                {paymentLabel}
              </p>
              {order.orderDetails ? (
                <p>
                  <span className="font-semibold text-forest-900">
                    Order details:
                  </span>{" "}
                  {order.orderDetails}
                </p>
              ) : null}
            </div>
          </div>

          <div className="rounded-[1.5rem] border border-gold/25 bg-cream-deep p-6">
            <p className="text-[11px] font-semibold uppercase tracking-[0.16em] text-moss">
              Need to change something?
            </p>
            <p className="mt-2 text-sm leading-relaxed text-ink/70">
              Message us on {WHATSAPP_NUMBER_DISPLAY} with your order reference
              and we will help you.
            </p>
          </div>
        </div>
      </Reveal>
    </div>
  );
}
