import type { Metadata } from "next";
import Image from "next/image";
import Link from "next/link";
import { notFound } from "next/navigation";
import { Suspense } from "react";
import { ProductCard } from "@/components/ProductCard";
import { Reveal } from "@/components/ui/Reveal";
import { WhatsAppButton } from "@/components/WhatsAppButton";
import {
  getCollectionBySlug,
  getCollections,
  getProducts,
  type SortKey,
} from "@/lib/queries";
import { HELLO_MESSAGE } from "@/lib/whatsapp";

export const dynamic = "force-dynamic";

type Params = Promise<{ slug: string }>;
type SearchParams = Promise<Record<string, string | string[] | undefined>>;

function single(value: string | string[] | undefined) {
  return Array.isArray(value) ? value[0] : value;
}

export async function generateMetadata({
  params,
}: {
  params: Params;
}): Promise<Metadata> {
  const { slug } = await params;
  const collection = await getCollectionBySlug(slug);
  if (!collection) notFound();
  return {
    title: collection.name,
    description: collection.description,
  };
}

export default async function CollectionPage({
  params,
  searchParams,
}: {
  params: Params;
  searchParams: SearchParams;
}) {
  const [{ slug }, query] = await Promise.all([params, searchParams]);
  const collection = await getCollectionBySlug(slug);
  if (!collection) notFound();

  const sort = (single(query.sort) ?? "featured") as SortKey;
  const category = single(query.category);
  const search = single(query.q);
  const maxParam = Number(single(query.max));
  const maxPriceFilter =
    Number.isFinite(maxParam) && maxParam > 0 ? maxParam : undefined;

  const [products, allCollections] = await Promise.all([
    getProducts({ collection: slug, category, search, sort, maxPrice: maxPriceFilter }),
    getCollections(),
  ]);

  return (
    <div>
      <section className="relative overflow-hidden border-b border-sand">
        <div className="absolute inset-0">
          <Image
            src={collection.image}
            alt=""
            fill
            priority
            sizes="100vw"
            className="object-cover opacity-25"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-forest-950 via-forest-950/90 to-forest-900/55" />
        </div>
        <div className="relative mx-auto max-w-7xl px-4 py-14 text-cream sm:px-6 lg:px-8 lg:py-20">
          <nav className="flex flex-wrap items-center gap-2 text-xs text-cream/50">
            <Link href="/" className="transition hover:text-gold">
              Home
            </Link>
            <span aria-hidden>/</span>
            <Link href="/collections" className="transition hover:text-gold">
              Collections
            </Link>
            <span aria-hidden>/</span>
            <span className="font-semibold text-gold-soft">
              {collection.name}
            </span>
          </nav>
          <h1 className="mt-5 font-display text-4xl sm:text-5xl lg:text-6xl">
            {collection.name}
          </h1>
          <p className="mt-3 font-display text-lg text-gold sm:text-xl">
            {collection.tagline}
          </p>
          <p className="mt-4 max-w-xl text-[15px] leading-relaxed text-cream/75">
            {collection.description}
          </p>
        </div>
      </section>

      <div className="mx-auto max-w-7xl px-4 py-10 sm:px-6 lg:px-8">
        <div className="mb-7 flex flex-wrap items-center justify-between gap-3">
          <p className="text-sm text-ink/60">
            <span className="font-semibold text-forest-900">
              {products.length}
            </span>{" "}
            {products.length === 1 ? "product" : "products"} in this collection
          </p>
          <div className="flex flex-wrap gap-2">
            {allCollections.map((item) => (
              <Link
                key={item.slug}
                href={`/collections/${item.slug}`}
                className={
                  item.slug === slug
                    ? "rounded-full bg-forest-800 px-4 py-2 text-xs font-semibold text-cream"
                    : "rounded-full border border-sand bg-white px-4 py-2 text-xs font-semibold text-ink/65 transition hover:border-gold hover:text-moss"
                }
              >
                {item.name}
              </Link>
            ))}
          </div>
        </div>

        {products.length === 0 ? (
          <div className="rounded-[1.5rem] border border-dashed border-sand bg-white px-6 py-16 text-center">
            <h2 className="font-display text-2xl text-forest-900">
              Nothing matches those filters
            </h2>
            <Link
              href={`/collections/${slug}`}
              className="mt-6 inline-flex rounded-full bg-forest-800 px-6 py-3.5 text-sm font-semibold text-cream transition hover:bg-forest-700"
            >
              Reset filters
            </Link>
          </div>
        ) : (
          <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
            {products.map((product, index) => (
              <Reveal key={product.id} delay={index * 80}>
                <ProductCard product={product} priority={index < 3} />
              </Reveal>
            ))}
          </div>
        )}

        <Reveal className="mt-12 rounded-[1.5rem] border border-gold/25 bg-cream-deep p-6 text-center sm:p-8">
          <h2 className="font-display text-2xl text-forest-900 sm:text-3xl">
            Questions about this collection?
          </h2>
          <p className="mx-auto mt-3 max-w-lg text-sm leading-relaxed text-ink/70">
            Send us a message and we will help you choose the right product.
          </p>
          <WhatsAppButton message={HELLO_MESSAGE} className="mt-6" size="lg" />
        </Reveal>
      </div>
    </div>
  );
}
