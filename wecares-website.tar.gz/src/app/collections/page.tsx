import type { Metadata } from "next";
import Image from "next/image";
import Link from "next/link";
import { Reveal } from "@/components/ui/Reveal";
import { getCollections } from "@/lib/queries";

export const dynamic = "force-dynamic";

export const metadata: Metadata = {
  title: "Collections",
  description:
    "Explore We Cares collections: Majoon & Wellness, Herbal Oils and Men's Care.",
};

export default async function CollectionsPage() {
  const collections = await getCollections();

  return (
    <div>
      <section className="panel-dark py-12 text-cream lg:py-16">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <nav className="flex items-center gap-2 text-xs text-cream/50">
            <Link href="/" className="transition hover:text-gold">
              Home
            </Link>
            <span aria-hidden>/</span>
            <span className="font-semibold text-gold-soft">Collections</span>
          </nav>
          <h1 className="mt-5 font-display text-4xl sm:text-5xl">Collections</h1>
          <p className="mt-4 max-w-2xl text-[15px] leading-relaxed text-cream/70 sm:text-base">
            Our range is organised into three focused collections, each prepared
            to the same sourcing and quality standard.
          </p>
        </div>
      </section>

      <div className="mx-auto max-w-7xl px-4 py-12 sm:px-6 lg:px-8">
        <div className="grid gap-6 lg:grid-cols-3">
          {collections.map((collection, index) => (
            <Reveal key={collection.id} delay={index * 90}>
              <Link
                href={`/collections/${collection.slug}`}
                className="group flex h-full flex-col overflow-hidden rounded-[1.75rem] border border-sand bg-white transition hover:-translate-y-1.5 hover:border-gold/60 hover:shadow-card"
              >
                <div className="relative aspect-[16/10] overflow-hidden bg-forest-800">
                  <Image
                    src={collection.image}
                    alt={collection.name}
                    fill
                    sizes="(max-width: 1024px) 100vw, 33vw"
                    className="object-cover transition duration-700 group-hover:scale-105"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-forest-950/70 to-transparent" />
                  <span className="absolute bottom-3 left-3 rounded-full bg-cream/95 px-3 py-1.5 text-[10px] font-bold uppercase tracking-[0.16em] text-forest-800">
                    {collection.productCount}{" "}
                    {collection.productCount === 1 ? "product" : "products"}
                  </span>
                </div>
                <div className="flex flex-1 flex-col p-6">
                  <h2 className="font-display text-2xl text-forest-900">
                    {collection.name}
                  </h2>
                  <p className="mt-1.5 text-sm font-semibold text-moss">
                    {collection.tagline}
                  </p>
                  <p className="mt-3 flex-1 text-sm leading-relaxed text-ink/65">
                    {collection.description}
                  </p>
                  <span className="mt-5 inline-flex items-center gap-2 text-sm font-semibold text-forest-800 transition group-hover:gap-3.5 group-hover:text-moss">
                    View collection <span aria-hidden>→</span>
                  </span>
                </div>
              </Link>
            </Reveal>
          ))}
        </div>
      </div>
    </div>
  );
}
