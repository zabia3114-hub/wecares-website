"use client";

import { useEffect } from "react";
import Link from "next/link";
import { WeCaresMark } from "@/components/Logo";
import { HELLO_MESSAGE, WHATSAPP_NUMBER_DISPLAY } from "@/lib/whatsapp";
import { WhatsAppButton } from "@/components/WhatsAppButton";

/**
 * Root error boundary. Renders instead of a blank screen or a raw stack trace
 * whenever a page throws at render time.
 */
export default function GlobalError({
  error,
  reset,
}: {
  error: Error & { digest?: string };
  reset: () => void;
}) {
  useEffect(() => {
    // Surfaced in server logs for diagnosis; never shown to the customer.
    console.error("render error", error);
  }, [error]);

  return (
    <div className="mx-auto flex max-w-2xl flex-col items-center px-4 py-24 text-center">
      <WeCaresMark className="h-14 w-14 text-gold" />
      <h1 className="mt-6 font-display text-3xl text-forest-900 sm:text-4xl">
        Something went wrong
      </h1>
      <p className="mt-4 max-w-md text-[15px] leading-relaxed text-ink/65">
        We could not load this page right now. Please try again — your cart and
        any order you have placed are safe.
      </p>

      <div className="mt-8 flex w-full flex-col justify-center gap-3 sm:w-auto sm:flex-row">
        <button
          type="button"
          onClick={reset}
          className="rounded-full bg-forest-800 px-7 py-3.5 text-sm font-semibold text-cream transition hover:bg-forest-700"
        >
          Try again
        </button>
        <Link
          href="/"
          className="rounded-full border border-forest-800 px-7 py-3.5 text-sm font-semibold text-forest-800 transition hover:bg-forest-800 hover:text-cream"
        >
          Back to home
        </Link>
      </div>

      <p className="mt-8 text-xs text-ink/50">
        Still stuck? WhatsApp us on {WHATSAPP_NUMBER_DISPLAY}
      </p>
      <WhatsAppButton message={HELLO_MESSAGE} size="sm" className="mt-3" />
    </div>
  );
}
