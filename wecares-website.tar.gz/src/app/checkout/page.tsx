import type { Metadata } from "next";
import Link from "next/link";
import { CheckoutForm } from "@/components/checkout/CheckoutForm";

export const metadata: Metadata = {
  title: "Checkout",
  description:
    "Complete your We Cares order. Cash on delivery available across Pakistan.",
};

export default function CheckoutPage() {
  return (
    <div className="mx-auto max-w-6xl px-4 py-10 sm:px-6 lg:px-8 lg:py-12">
      <nav className="flex items-center gap-2 text-xs text-ink/50">
        <Link href="/" className="transition hover:text-moss">
          Home
        </Link>
        <span aria-hidden>/</span>
        <Link href="/shop" className="transition hover:text-moss">
          Products
        </Link>
        <span aria-hidden>/</span>
        <span className="font-semibold text-forest-900">Checkout</span>
      </nav>

      <header className="mt-5 max-w-2xl">
        <h1 className="font-display text-4xl text-forest-900 sm:text-5xl">
          Checkout
        </h1>
        <p className="mt-3 text-[15px] leading-relaxed text-ink/65">
          Three quick steps. We only ask for what we need to deliver your order.
        </p>
      </header>

      <div className="mt-9">
        <CheckoutForm />
      </div>
    </div>
  );
}
