import type { ReactNode } from "react";
import "./globals.css";
import { CartProvider } from "@/components/cart/CartProvider";
import { SettingsProvider } from "@/components/SettingsProvider";
import { CartDrawer } from "@/components/cart/CartDrawer";
import { SiteHeader } from "@/components/SiteHeader";
import { SiteFooter } from "@/components/SiteFooter";
import { WhatsAppFloat } from "@/components/WhatsAppFloat";
import {
  buildFontHref,
  fontStack,
  getSiteSettings,
  getTheme,
} from "@/lib/settings";

export const dynamic = "force-dynamic";

export async function generateMetadata() {
  const settings = await getSiteSettings();
  return {
    title: {
      default: `${settings.brandName} — ${settings.tagline}`,
      template: `%s · ${settings.brandName}`,
    },
    description: settings.heroSubtitle,
    openGraph: {
      type: "website" as const,
      siteName: settings.brandName,
      title: `${settings.brandName} — ${settings.tagline}`,
      description: settings.heroSubtitle,
      images: ["/images/brand-hero.jpg"],
    },
    twitter: { card: "summary_large_image" },
  };
}

export const viewport = {
  themeColor: "#072018",
  width: "device-width",
  initialScale: 1,
};

export default async function RootLayout({ children }: { children: ReactNode }) {
  const settings = await getSiteSettings();
  const theme = getTheme(settings.theme);

  // Override the Tailwind theme variables at runtime so the chosen palette and
  // fonts apply across every component without a rebuild.
  const themeCss = `:root{${Object.entries(theme.vars)
    .map(([key, value]) => `${key}:${value}`)
    .join(";")};--font-display:${fontStack(settings.fontHeading, '"Cormorant Garamond", Georgia, serif')};--font-sans:${fontStack(settings.fontBody, '"Inter", system-ui, sans-serif')};--font-price:${fontStack(settings.fontPrice, '"Cormorant Garamond", Georgia, serif')};}`;

  return (
    <html lang="en">
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link
          rel="preconnect"
          href="https://fonts.gstatic.com"
          crossOrigin="anonymous"
        />
        <link
          href={buildFontHref([
            settings.fontHeading,
            settings.fontBody,
            settings.fontPrice,
          ])}
          rel="stylesheet"
        />
        <style dangerouslySetInnerHTML={{ __html: themeCss }} />
      </head>
      <body className="min-h-screen bg-cream text-ink antialiased">
        <CartProvider>
          <SettingsProvider settings={settings}>
          <SiteHeader />
          <main>{children}</main>
          <SiteFooter />
          <CartDrawer />
          <WhatsAppFloat />
          </SettingsProvider>
        </CartProvider>
      </body>
    </html>
  );
}
