import Link from "next/link";
import { WeCaresMark } from "@/components/Logo";
import { WhatsAppButton } from "@/components/WhatsAppButton";
import { HELLO_MESSAGE, WHATSAPP_NUMBER_DISPLAY } from "@/lib/whatsapp";

export default function NotFound() {
  return (
    <div className="mx-auto flex max-w-2xl flex-col items-center px-4 py-20 text-center lg:py-28">
      <WeCaresMark className="h-16 w-16 text-gold" />
      <h1 className="mt-7 font-display text-4xl text-forest-900 sm:text-5xl">
        Page not found
      </h1>
      <p className="mt-4 max-w-md text-[15px] leading-relaxed text-ink/65">
        The page you are looking for has moved or is no longer available. Our
        products are all still here.
      </p>
      <div className="mt-8 flex w-full flex-col justify-center gap-3 sm:w-auto sm:flex-row">
        <Link
          href="/shop"
          className="rounded-full bg-forest-800 px-7 py-3.5 text-sm font-semibold text-cream transition hover:bg-forest-700"
        >
          View Products
        </Link>
        <Link
          href="/"
          className="rounded-full border border-forest-800 px-7 py-3.5 text-sm font-semibold text-forest-800 transition hover:bg-forest-800 hover:text-cream"
        >
          Back to home
        </Link>
      </div>
      <p className="mt-8 text-xs text-ink/55">
        Need help? WhatsApp us on {WHATSAPP_NUMBER_DISPLAY}
      </p>
      <WhatsAppButton message={HELLO_MESSAGE} size="sm" className="mt-4" />
    </div>
  );
}
