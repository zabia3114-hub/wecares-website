import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { ProductBuyBox } from "@/components/ProductBuyBox";
import { ProductCard } from "@/components/ProductCard";
import { ProductImage } from "@/components/ProductImage";
import { Reveal } from "@/components/ui/Reveal";
import { WhatsAppButton } from "@/components/WhatsAppButton";
import { WhatsAppIcon } from "@/components/WhatsAppButton";
import { WeCaresMark } from "@/components/Logo";
import { ProductReviews } from "@/components/ProductReviews";
import { getCollectionBySlug, getProductBySlug, getProducts } from "@/lib/queries";
import { getApprovedProductReviews, getProductRatingSummary } from "@/lib/reviews";
import { discountPercent, formatPkr } from "@/lib/format";
import { HELLO_MESSAGE, WHATSAPP_NUMBER_DISPLAY } from "@/lib/whatsapp";

export const dynamic = "force-dynamic";

type Params = Promise<{ slug: string }>;

export async function generateMetadata({
  params,
}: {
  params: Params;
}): Promise<Metadata> {
  const { slug } = await params;
  const product = await getProductBySlug(slug);
  if (!product) notFound();
  return {
    title: product.name,
    description: product.subtitle,
    openGraph: {
      title: `${product.name} · We Cares`,
      description: product.subtitle,
      images: product.images[0] ? [product.images[0]] : undefined,
    },
  };
}

export default async function ProductPage({ params }: { params: Params }) {
  const { slug } = await params;
  const product = await getProductBySlug(slug);
  if (!product) notFound();

  const [collection, related, productReviews, rating] = await Promise.all([
    getCollectionBySlug(product.collectionSlug),
    getProducts({ collection: product.collectionSlug, limit: 4 }),
    getApprovedProductReviews(product.id),
    getProductRatingSummary(product.id),
  ]);

  const others = related.filter((item) => item.id !== product.id).slice(0, 3);
  const off = discountPercent(product.pricePaisa, product.compareAtPaisa);

  return (
    <div>
      <div className="mx-auto max-w-7xl px-4 py-8 sm:px-6 lg:px-8 lg:py-10">
        <nav className="flex flex-wrap items-center gap-2 text-xs text-ink/50">
          <Link href="/" className="transition hover:text-moss">
            Home
          </Link>
          <span aria-hidden>/</span>
          <Link href="/shop" className="transition hover:text-moss">
            Products
          </Link>
          {collection ? (
            <>
              <span aria-hidden>/</span>
              <Link
                href={`/collections/${collection.slug}`}
                className="transition hover:text-moss"
              >
                {collection.name}
              </Link>
            </>
          ) : null}
          <span aria-hidden>/</span>
          <span className="font-semibold text-forest-900">{product.name}</span>
        </nav>

        <div className="mt-7 grid gap-9 lg:grid-cols-2 lg:gap-14">
          {/* Gallery */}
          <div className="lg:sticky lg:top-32 lg:self-start">
            <div className="relative aspect-square overflow-hidden rounded-[1.75rem] border border-sand bg-forest-800">
              <ProductImage
                src={product.images[0]}
                alt={product.name}
                name={product.name}
                netWeight={product.netWeight}
                priority
                showError
                sizes="(max-width: 1024px) 100vw, 46vw"
              />
              {off > 0 ? (
                <span className="absolute left-4 top-4 rounded-full bg-gold px-3.5 py-2 text-[11px] font-bold uppercase tracking-[0.14em] text-forest-950">
                  Save {off}%
                </span>
              ) : null}
            </div>

            <div className="mt-4 grid grid-cols-3 gap-3">
              {product.highlights.slice(0, 3).map((highlight) => (
                <div
                  key={highlight}
                  className="rounded-2xl border border-sand bg-white px-3 py-3 text-center text-[11px] font-medium leading-snug text-forest-800"
                >
                  {highlight}
                </div>
              ))}
            </div>
          </div>

          {/* Details */}
          <div>
            <div className="flex flex-wrap items-center gap-2.5">
              {collection ? (
                <Link
                  href={`/collections/${collection.slug}`}
                  className="rounded-full bg-cream-deep px-3 py-1.5 text-[10px] font-bold uppercase tracking-[0.16em] text-forest-800 transition hover:bg-sand"
                >
                  {collection.name}
                </Link>
              ) : null}
              <span className="text-[11px] font-semibold uppercase tracking-[0.16em] text-ink/50">
                {product.categoryLabel} · Net {product.netWeight}
              </span>
            </div>

            <h1 className="mt-4 text-balance font-display text-3xl leading-tight text-forest-900 sm:text-4xl lg:text-[2.75rem]">
              {product.name}
            </h1>
            <p className="mt-3 text-base text-ink/70">{product.subtitle}</p>
            <p className="mt-1.5 text-sm font-medium text-moss">
              {product.suitability}
            </p>

            {/* Prices */}
            <div className="mt-6 rounded-[1.5rem] border border-gold/30 bg-cream-deep p-5">
              <div className="flex flex-wrap items-baseline gap-3">
                <span className="font-display text-4xl font-semibold text-forest-900">
                  {formatPkr(product.pricePaisa)}
                </span>
                {product.compareAtPaisa ? (
                  <span className="text-lg text-ink/45 line-through">
                    {formatPkr(product.compareAtPaisa)}
                  </span>
                ) : null}
                {off > 0 ? (
                  <span className="rounded-full bg-moss px-3 py-1 text-xs font-bold text-cream">
                    {off}% OFF
                  </span>
                ) : null}
              </div>
              <p className="mt-2 text-xs text-ink/60">
                Prices in Pakistani Rupees, inclusive of all applicable taxes.
                Cash on delivery available.
              </p>
            </div>

            <p className="mt-6 text-[15px] leading-relaxed text-ink/75">
              {product.description}
            </p>

            <ProductBuyBox
              slug={product.slug}
              name={product.name}
              image={product.images[0]}
              pricePaisa={product.pricePaisa}
              netWeight={product.netWeight}
              stock={product.stock}
            />

            {/* Trust row */}
            <div className="mt-8 grid grid-cols-2 gap-3 sm:grid-cols-4">
              {[
                ["🚚", "Nationwide"],
                ["💵", "Cash on delivery"],
                ["🌿", "Herbal"],
                ["📞", "WhatsApp support"],
              ].map(([icon, label]) => (
                <div
                  key={label}
                  className="rounded-2xl border border-sand bg-white px-3 py-3 text-center text-[11px] font-semibold text-forest-800"
                >
                  <span className="mr-1" aria-hidden>
                    {icon}
                  </span>
                  {label}
                </div>
              ))}
            </div>

            {/* Details accordion */}
            <div className="mt-8 divide-y divide-sand border-y border-sand">
              <details className="group py-4" open>
                <summary className="flex cursor-pointer items-center justify-between text-sm font-semibold text-forest-900">
                  How to use
                  <span className="text-moss transition group-open:rotate-45">
                    +
                  </span>
                </summary>
                <p className="mt-3 text-sm leading-relaxed text-ink/70">
                  {product.howToUse}
                </p>
              </details>

              <details className="group py-4">
                <summary className="flex cursor-pointer items-center justify-between text-sm font-semibold text-forest-900">
                  Ingredients &amp; specification
                  <span className="text-moss transition group-open:rotate-45">
                    +
                  </span>
                </summary>
                <div className="mt-3 space-y-2.5 text-sm text-ink/70">
                  <ul className="space-y-1.5">
                    {product.ingredients.map((ingredient) => (
                      <li key={ingredient} className="flex gap-2">
                        <span className="text-moss" aria-hidden>
                          —
                        </span>
                        {ingredient}
                      </li>
                    ))}
                  </ul>
                  <dl className="mt-3 grid grid-cols-2 gap-3 rounded-2xl bg-cream p-4 text-xs">
                    <div>
                      <dt className="text-ink/50">Net weight</dt>
                      <dd className="mt-0.5 font-semibold text-forest-900">
                        {product.netWeight}
                      </dd>
                    </div>
                    <div>
                      <dt className="text-ink/50">Suitable for</dt>
                      <dd className="mt-0.5 font-semibold text-forest-900">
                        {product.suitability}
                      </dd>
                    </div>
                  </dl>
                </div>
              </details>

              <details className="group py-4">
                <summary className="flex cursor-pointer items-center justify-between text-sm font-semibold text-forest-900">
                  Delivery &amp; returns
                  <span className="text-moss transition group-open:rotate-45">
                    +
                  </span>
                </summary>
                <p className="mt-3 text-sm leading-relaxed text-ink/70">
                  Orders are dispatched within 24 hours of confirmation. Standard
                  delivery is Rs. 250 and free on orders over{" "}
                  {formatPkr(500000)}; express delivery is Rs. 500. Cash on
                  delivery is available nationwide. If your parcel arrives
                  damaged, contact us on {WHATSAPP_NUMBER_DISPLAY} within 48
                  hours and we will arrange a replacement.
                </p>
              </details>
            </div>

            {/* Disclaimer */}
            <div className="mt-7 rounded-[1.5rem] border border-sand bg-white p-5">
              <div className="flex items-start gap-3">
                <WeCaresMark className="mt-0.5 h-7 w-7 shrink-0 text-gold" />
                <div>
                  <p className="text-[11px] font-semibold uppercase tracking-[0.16em] text-moss">
                    Important information
                  </p>
                  <p className="mt-2 text-xs leading-relaxed text-ink/65">
                    {product.disclaimer}
                  </p>
                </div>
              </div>
            </div>

            {/* WhatsApp help */}
            <div className="mt-5 rounded-[1.5rem] border border-gold/25 bg-cream-deep p-5">
              <div className="flex flex-wrap items-center justify-between gap-4">
                <div className="flex items-center gap-3">
                  <span className="grid h-10 w-10 shrink-0 place-items-center rounded-full bg-[#25D366]/15">
                    <WhatsAppIcon className="h-5 w-5 text-[#25D366]" />
                  </span>
                  <div>
                    <p className="text-sm font-semibold text-forest-900">
                      Have a question?
                    </p>
                    <p className="text-xs text-ink/60">
                      WhatsApp {WHATSAPP_NUMBER_DISPLAY}
                    </p>
                  </div>
                </div>
                <WhatsAppButton
                  size="sm"
                  message={HELLO_MESSAGE}
                  variant="outline"
                >
                  Message us
                </WhatsAppButton>
              </div>
            </div>
          </div>
        </div>

        <ProductReviews
          productId={product.id}
          productSlug={product.slug}
          reviews={productReviews}
          average={rating.average}
          total={rating.total}
        />

        {others.length > 0 ? (
          <section className="mt-16">
            <Reveal className="flex flex-wrap items-end justify-between gap-4">
              <h2 className="font-display text-2xl text-forest-900 sm:text-3xl">
                You may also like
              </h2>
              <Link
                href="/shop"
                className="text-sm font-semibold text-forest-800 underline decoration-gold decoration-2 underline-offset-8 transition hover:text-moss"
              >
                View all products
              </Link>
            </Reveal>
            <div className="mt-8 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
              {others.map((item, index) => (
                <Reveal key={item.id} delay={index * 80}>
                  <ProductCard product={item} />
                </Reveal>
              ))}
            </div>
          </section>
        ) : null}
      </div>
    </div>
  );
}
