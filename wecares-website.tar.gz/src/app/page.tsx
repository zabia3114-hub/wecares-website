import Image from "next/image";
import Link from "next/link";
import { ProductCard } from "@/components/ProductCard";
import { Reveal } from "@/components/ui/Reveal";
import { WeCaresMark } from "@/components/Logo";
import { WhatsAppButton, WhatsAppIcon } from "@/components/WhatsAppButton";
import { getCollections, getProducts } from "@/lib/queries";
import { formatPkr } from "@/lib/format";
import { HELLO_MESSAGE, buildWhatsAppLink } from "@/lib/whatsapp";
import { getSiteSettings } from "@/lib/settings";

export const dynamic = "force-dynamic";

const WHY_US = [
  {
    title: "Carefully sourced ingredients",
    copy: "Botanicals and raw materials are selected from trusted suppliers and checked before they enter our preparation process.",
    icon: "🌿",
  },
  {
    title: "Traditional preparation",
    copy: "Our majoon and herbal oils follow time-honoured methods, prepared in controlled small batches for consistency.",
    icon: "⚖️",
  },
  {
    title: "Honest, clear labelling",
    copy: "Net weight, ingredients and usage directions are printed on every pack, so you always know what you are buying.",
    icon: "📜",
  },
  {
    title: "Support that answers",
    copy: "Real people on WhatsApp, ready to help with your order, delivery status or product questions.",
    icon: "💬",
  },
];

const VALUES = [
  {
    label: "Natural First",
    copy: "Herbal preparations built on botanicals, with no artificial colours in our majoon.",
  },
  {
    label: "Made in Pakistan",
    copy: "Prepared locally with ingredients sourced from established suppliers.",
  },
  {
    label: "Quality Controlled",
    copy: "Each batch is checked for consistency before it is packed and sealed.",
  },
  {
    label: "Fair Pricing",
    copy: "Straightforward prices with no inflated claims and no hidden charges.",
  },
];

const ORDER_STEPS = [
  {
    step: "01",
    title: "Choose your product",
    copy: "Add to cart, or order directly on WhatsApp — whichever you prefer.",
  },
  {
    step: "02",
    title: "Share your details",
    copy: "Name, mobile number, complete address and city. That is all we need.",
  },
  {
    step: "03",
    title: "Receive your order",
    copy: "Delivered nationwide with cash on delivery available on request.",
  },
];

export default async function HomePage() {
  const settings = await getSiteSettings();
  const [products, collections] = await Promise.all([
    getProducts({ sort: "featured" }),
    getCollections(),
  ]);

  const themeVars = {
    ["--theme-header-from" as string]: "var(--theme-header-from)",
    ["--theme-header-via" as string]: "var(--theme-header-via)",
    ["--theme-header-to" as string]: "var(--theme-header-to)",
  };

  return (
    <>
      {/* ---------------- 1. HERO ---------------- */}
      <section className="relative overflow-hidden bg-forest-900 text-cream">
        <div className="absolute inset-0">
          <Image
            src="/images/brand-hero.jpg"
            alt=""
            fill
            priority
            sizes="100vw"
            className="object-cover opacity-35"
          />
          <div className="absolute inset-0" style={{ background: "linear-gradient(to right, var(--theme-header-from), var(--theme-header-via), var(--theme-header-to))" }} />
        </div>

        <div className="relative mx-auto max-w-7xl px-4 py-16 sm:px-6 sm:py-20 lg:px-8 lg:py-28">
          <div className="max-w-2xl">
            <div className="animate-fade-up flex items-center gap-3">
              <WeCaresMark className="h-11 w-11 text-gold" />
              <span className="text-[10px] font-semibold uppercase tracking-[0.3em] text-gold-soft sm:text-[11px]">
                {settings.heroBadge}
              </span>
            </div>

            <h1 className="animate-fade-up mt-7 text-balance font-display text-[2.6rem] leading-[1.04] sm:text-6xl lg:text-[4.2rem] [animation-delay:80ms]">
              {settings.heroTitle}
              <span className="block italic text-gold">{settings.heroHighlight}</span>
            </h1>

            <p className="animate-fade-up mt-6 max-w-xl text-base leading-relaxed text-cream/80 sm:text-lg [animation-delay:160ms]">
              {settings.heroSubtitle}
            </p>

            <div className="animate-fade-up mt-9 flex flex-col gap-3 sm:flex-row sm:flex-wrap [animation-delay:240ms]">
              <Link
                href="/shop"
                className="group inline-flex items-center justify-center gap-2 rounded-full bg-gold px-7 py-4 text-sm font-semibold text-forest-950 transition hover:bg-gold-soft active:scale-[0.98]"
              >
                Shop Products
                <span className="transition group-hover:translate-x-1">→</span>
              </Link>
              <WhatsAppButton
                size="lg"
                variant="outline"
                message={HELLO_MESSAGE}
                className="border-gold/50 text-gold-soft hover:bg-gold/10"
              >
                Order on WhatsApp
              </WhatsAppButton>
            </div>

            <dl className="animate-fade-up mt-12 grid max-w-lg grid-cols-3 gap-5 border-t border-gold/20 pt-6 [animation-delay:320ms]">
              {[
                ["3", "Signature products"],
                ["24h", "Order processing"],
                ["COD", "Cash on delivery"],
              ].map(([value, label]) => (
                <div key={label}>
                  <dt className="font-display text-2xl text-gold sm:text-3xl">
                    {value}
                  </dt>
                  <dd className="mt-1 text-[11px] leading-snug text-cream/60 sm:text-xs">
                    {label}
                  </dd>
                </div>
              ))}
            </dl>
          </div>
        </div>

        <div className="gold-rule relative" />
      </section>

      {/* ---------------- 3. FEATURED PRODUCTS ---------------- */}
      <section id="products" className="bg-cream-deep py-16 lg:py-24">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <Reveal className="max-w-2xl">
            <p className="text-[11px] font-semibold uppercase tracking-[0.28em] text-moss">
              Featured Products
            </p>
            <h2 className="mt-4 font-display text-3xl text-forest-900 sm:text-4xl lg:text-5xl">
              Our signature range
            </h2>
            <p className="mt-4 text-[15px] leading-relaxed text-ink/70 sm:text-base">
              Three products, each prepared to the same standard. Every price is
              in Pakistani Rupees, inclusive of all applicable taxes.
            </p>
          </Reveal>

          <div className="mt-10 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
            {products.map((product, index) => (
              <Reveal key={product.id} delay={index * 90}>
                <ProductCard product={product} priority={index < 3} />
              </Reveal>
            ))}
          </div>

          <Reveal className="mt-10 flex flex-col items-center gap-3 sm:flex-row sm:justify-center">
            <Link
              href="/shop"
              className="rounded-full bg-forest-800 px-7 py-4 text-sm font-semibold text-cream transition hover:bg-forest-700"
            >
              Browse all products
            </Link>
            <p className="text-xs text-ink/60">
              Free standard delivery on orders over {formatPkr(500000)}
            </p>
          </Reveal>
        </div>
      </section>

      {/* ---------------- 4. WHY CHOOSE WE CARES ---------------- */}
      <section className="panel-dark relative py-16 text-cream lg:py-24">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <Reveal className="max-w-2xl">
            <p className="text-[11px] font-semibold uppercase tracking-[0.28em] text-gold">
              Why Choose We Cares
            </p>
            <h2 className="mt-4 font-display text-3xl sm:text-4xl lg:text-5xl">
              Four reasons customers come back
            </h2>
          </Reveal>

          <div className="mt-10 grid gap-5 sm:grid-cols-2">
            {WHY_US.map((item, index) => (
              <Reveal
                key={item.title}
                delay={index * 80}
                className="rounded-2xl border border-gold/20 bg-forest-800/60 p-6 transition hover:border-gold/45 sm:p-7"
              >
                <span className="text-2xl">{item.icon}</span>
                <h3 className="mt-4 font-display text-xl text-cream sm:text-2xl">
                  {item.title}
                </h3>
                <p className="mt-2.5 text-sm leading-relaxed text-cream/70">
                  {item.copy}
                </p>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      {/* ---------------- 5. BRAND VALUES ---------------- */}
      <section className="mx-auto max-w-7xl px-4 py-16 sm:px-6 lg:px-8 lg:py-24">
        <Reveal className="mx-auto max-w-2xl text-center">
          <p className="text-[11px] font-semibold uppercase tracking-[0.28em] text-moss">
            Our Values
          </p>
          <h2 className="mt-4 font-display text-3xl text-forest-900 sm:text-4xl lg:text-5xl">
            Natural, herbal, and honest
          </h2>
          <div className="gold-rule mx-auto mt-6 w-40" />
        </Reveal>

        <div className="mt-12 grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
          {VALUES.map((value, index) => (
            <Reveal
              key={value.label}
              delay={index * 70}
              className="rounded-[1.5rem] border border-sand bg-white p-6 text-center transition hover:border-gold/50 hover:shadow-card"
            >
              <span className="mx-auto grid h-12 w-12 place-items-center rounded-full bg-forest-800 text-gold">
                <WeCaresMark className="h-7 w-7" />
              </span>
              <h3 className="mt-5 font-display text-xl text-forest-900">
                {value.label}
              </h3>
              <p className="mt-2.5 text-sm leading-relaxed text-ink/70">
                {value.copy}
              </p>
            </Reveal>
          ))}
        </div>

        {/* collections */}
        <div className="mt-16 grid gap-5 sm:grid-cols-3">
          {collections.map((collection, index) => (
            <Reveal key={collection.id} delay={index * 80}>
              <Link
                href={`/collections/${collection.slug}`}
                className="group flex h-full flex-col justify-between rounded-[1.5rem] border border-sand bg-cream-deep p-6 transition hover:-translate-y-1 hover:border-gold/50"
              >
                <div>
                  <p className="text-[10px] font-semibold uppercase tracking-[0.2em] text-moss">
                    {collection.productCount}{" "}
                    {collection.productCount === 1 ? "product" : "products"}
                  </p>
                  <h3 className="mt-3 font-display text-2xl text-forest-900">
                    {collection.name}
                  </h3>
                  <p className="mt-1.5 text-sm font-medium text-moss">
                    {collection.tagline}
                  </p>
                  <p className="mt-3 text-sm leading-relaxed text-ink/65">
                    {collection.description}
                  </p>
                </div>
                <span className="mt-6 inline-flex items-center gap-2 text-sm font-semibold text-forest-800 transition group-hover:gap-3.5 group-hover:text-moss">
                  Explore <span aria-hidden>→</span>
                </span>
              </Link>
            </Reveal>
          ))}
        </div>
      </section>

      {/* ---------------- 6. TRUST / HOW TO ORDER ---------------- */}
      <section className="border-y border-sand bg-white py-16 lg:py-24">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <Reveal className="max-w-2xl">
            <p className="text-[11px] font-semibold uppercase tracking-[0.28em] text-moss">
              Ordering From Us
            </p>
            <h2 className="mt-4 font-display text-3xl text-forest-900 sm:text-4xl lg:text-5xl">
              Simple, safe and nationwide
            </h2>
          </Reveal>

          <div className="mt-10 grid gap-6 lg:grid-cols-3">
            {ORDER_STEPS.map((step, index) => (
              <Reveal key={step.step} delay={index * 90}>
                <div className="flex h-full gap-4 rounded-[1.5rem] border border-sand bg-cream p-6">
                  <span className="grid h-11 w-11 shrink-0 place-items-center rounded-xl bg-forest-800 font-display text-base text-gold">
                    {step.step}
                  </span>
                  <div>
                    <h3 className="font-display text-xl text-forest-900">
                      {step.title}
                    </h3>
                    <p className="mt-2 text-sm leading-relaxed text-ink/70">
                      {step.copy}
                    </p>
                  </div>
                </div>
              </Reveal>
            ))}
          </div>

          <Reveal className="mt-10 grid gap-4 rounded-[1.5rem] border border-gold/25 bg-cream-deep p-6 sm:grid-cols-2 lg:grid-cols-4 lg:p-8">
            {[
              ["Cash on delivery", "Pay when your parcel arrives"],
              ["Nationwide delivery", "All cities and towns in Pakistan"],
              ["Secure checkout", "Your details are stored securely"],
              ["WhatsApp support", "Real help, when you need it"],
            ].map(([title, copy]) => (
              <div key={title} className="flex gap-3">
                <span className="mt-0.5 text-moss" aria-hidden>
                  ✓
                </span>
                <div>
                  <p className="text-sm font-semibold text-forest-900">{title}</p>
                  <p className="mt-0.5 text-xs leading-relaxed text-ink/60">
                    {copy}
                  </p>
                </div>
              </div>
            ))}
          </Reveal>
        </div>
      </section>

      {/* ---------------- 7. WHATSAPP CTA ---------------- */}
      <section className="relative overflow-hidden bg-forest-900 text-cream">
        <div className="absolute inset-0">
          <Image
            src="/images/brand-cta.jpg"
            alt=""
            fill
            sizes="100vw"
            className="object-cover opacity-25"
          />
          <div className="absolute inset-0" style={{ background: "linear-gradient(to top, var(--theme-header-from), var(--theme-header-via), var(--theme-header-to))" }} />
        </div>

        <div className="relative mx-auto max-w-4xl px-4 py-16 text-center sm:px-6 lg:py-24">
          <Reveal>
            <span className="mx-auto grid h-16 w-16 place-items-center rounded-full bg-[#25D366]/15">
              <WhatsAppIcon className="h-8 w-8 text-[#25D366]" />
            </span>
            <h2 className="mt-7 text-balance font-display text-3xl sm:text-4xl lg:text-5xl">
              Prefer to order on WhatsApp?
            </h2>
            <p className="mx-auto mt-5 max-w-xl text-[15px] leading-relaxed text-cream/75 sm:text-base">
              Message us on {settings.whatsappDisplay} and we will confirm your
              order, total and delivery details — usually within minutes during
              order hours.
            </p>
            <div className="mt-9 flex flex-col items-center justify-center gap-3 sm:flex-row">
              <WhatsAppButton
                size="lg"
                message={HELLO_MESSAGE}
                className="w-full sm:w-auto"
              >
                Chat on WhatsApp
              </WhatsAppButton>
              <a
                href={`tel:+${settings.whatsappNumber}`}
                className="inline-flex w-full items-center justify-center rounded-full border border-gold/45 px-7 py-4 text-[15px] font-semibold text-gold-soft transition hover:bg-gold/10 sm:w-auto"
              >
                Call {settings.whatsappDisplay}
              </a>
            </div>
            <p className="mt-6 text-[11px] uppercase tracking-[0.2em] text-cream/45">
              Order hours: {settings.orderHours}
            </p>
          </Reveal>
        </div>
      </section>

      {/* ---------------- 8. ABOUT WE CARES (bottom of homepage) ---------------- */}
      <section className="mx-auto max-w-7xl px-4 py-16 sm:px-6 lg:px-8 lg:py-20">
        <div className="grid items-center gap-10 lg:grid-cols-2 lg:gap-16">
          <Reveal>
            <p className="text-[11px] font-semibold uppercase tracking-[0.28em] text-moss">
              About We Cares
            </p>
            <h2 className="mt-4 text-balance font-display text-3xl leading-tight text-forest-900 sm:text-4xl lg:text-[2.9rem]">
              A Pakistani herbal wellness brand built on trust
            </h2>
            <div className="mt-6 space-y-4 text-[15px] leading-relaxed text-ink/75 sm:text-base">
              <p>
                We Cares exists to bring dependable herbal preparations to
                households across Pakistan. Every product we sell carries our
                name, so we treat sourcing, preparation and packaging as a
                matter of reputation rather than convenience.
              </p>
              <p>
                Our range is deliberately small. Instead of a long list of
                products, we focus on a handful of well-prepared items — a
                traditional majoon and two herbal oils — each with clear
                labelling, honest pricing and straightforward usage directions.
              </p>
              <p>
                We do not make medical promises. We make good products, label
                them properly, and let the quality speak for itself.
              </p>
            </div>
            <Link
              href="/shop"
              className="mt-8 inline-flex items-center gap-2 rounded-full border border-forest-800 px-6 py-3.5 text-sm font-semibold text-forest-800 transition hover:bg-forest-800 hover:text-cream"
            >
              View our products
              <span aria-hidden>→</span>
            </Link>
          </Reveal>

          <Reveal delay={120} className="relative">
            <div className="relative aspect-[4/3] overflow-hidden rounded-[2rem] border border-gold/25 shadow-lift">
              <Image
                src="/images/brand-values.jpg"
                alt="Herbal botanicals and ingredients used in We Cares preparations"
                fill
                sizes="(max-width: 1024px) 100vw, 46vw"
                className="object-cover"
              />
            </div>
            <div className="animate-float absolute -bottom-5 left-4 rounded-2xl border border-gold/30 bg-forest-900 px-5 py-4 text-cream shadow-lift sm:left-6">
              <p className="text-[10px] font-semibold uppercase tracking-[0.2em] text-gold">
                Nature&apos;s Care
              </p>
              <p className="mt-1 font-display text-lg">With You</p>
            </div>
          </Reveal>
        </div>
      </section>

    </>
  );
}
