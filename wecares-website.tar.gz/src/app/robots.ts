import type { MetadataRoute } from "next";

export default function robots(): MetadataRoute.Robots {
  const raw = process.env.NEXT_PUBLIC_SITE_URL?.trim();
  const base = (raw && raw.length > 0 ? raw : "http://localhost:3000").replace(
    /\/$/,
    "",
  );

  return {
    rules: [
      {
        userAgent: "*",
        allow: "/",
        disallow: ["/admin", "/admin/", "/checkout", "/orders/", "/api/"],
      },
    ],
    sitemap: `${base}/sitemap.xml`,
  };
}
