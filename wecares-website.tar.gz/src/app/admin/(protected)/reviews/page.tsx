import type { Metadata } from "next";
import { ReviewsManager } from "@/components/admin/ReviewsManager";
import { getAllReviewsForAdmin } from "@/lib/admin-queries";

export const dynamic = "force-dynamic";

export const metadata: Metadata = {
  title: "Reviews",
  robots: { index: false, follow: false },
};

export default async function AdminReviewsPage() {
  const reviews = await getAllReviewsForAdmin();

  return (
    <ReviewsManager
      reviews={reviews.map((review) => ({
        id: review.id,
        productId: review.productId,
        productName: review.productName,
        productSlug: review.productSlug,
        authorName: review.authorName,
        authorMobile: review.authorMobile,
        rating: review.rating,
        title: review.title,
        body: review.body,
        status: review.status,
        isVerifiedBuyer: review.isVerifiedBuyer,
        createdAt: review.createdAt.toISOString(),
      }))}
    />
  );
}
