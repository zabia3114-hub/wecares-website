import type { Metadata } from "next";
import { OrdersInbox } from "@/components/admin/OrdersInbox";
import { getAllOrders } from "@/lib/admin-queries";

export const dynamic = "force-dynamic";

export const metadata: Metadata = {
  title: "Orders",
  robots: { index: false, follow: false, nocache: true },
};

export default async function AdminOrdersPage() {
  const orders = await getAllOrders();

  return (
    <OrdersInbox
      orders={orders.map((order) => ({
        id: order.id,
        orderNumber: order.orderNumber,
        customerName: order.customerName,
        mobile: order.mobile,
        address: order.address,
        city: order.city,
        province: order.province,
        orderDetails: order.orderDetails,
        paymentMethod: order.paymentMethod,
        shippingMethod: order.shippingMethod,
        status: order.status,
        items: order.items,
        subtotalPaisa: order.subtotalPaisa,
        shippingPaisa: order.shippingPaisa,
        totalPaisa: order.totalPaisa,
        createdAt: order.createdAt.toISOString(),
      }))}
    />
  );
}
