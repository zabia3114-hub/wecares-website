import type { Metadata } from "next";
import { SettingsManager } from "@/components/admin/SettingsManager";
import { getSiteSettings } from "@/lib/settings";
import { usingDefaultAdminCredentials } from "@/lib/admin-auth";

export const dynamic = "force-dynamic";

export const metadata: Metadata = {
  title: "Settings",
  robots: { index: false, follow: false },
};

export default async function AdminSettingsPage() {
  const settings = await getSiteSettings();
  const usingDefaults = usingDefaultAdminCredentials();

  return <SettingsManager initial={settings} usingDefaultPassword={usingDefaults} />;
}
