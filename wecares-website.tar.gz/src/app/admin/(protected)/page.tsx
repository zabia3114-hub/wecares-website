import Link from "next/link";
import { formatPkr, formatDate } from "@/lib/format";
import {
  getAllOrders,
  getAllProductsForAdmin,
  getDashboardStats,
} from "@/lib/admin-queries";
import { getUnreadNotifications } from "@/lib/notifications";
import { normalizeOrderStatus, ORDER_STATUS_LABELS } from "@/lib/status";

export const dynamic = "force-dynamic";

export default async function AdminDashboard() {
  const [stats, products, orders, alerts] = await Promise.all([
    getDashboardStats(),
    getAllProductsForAdmin(),
    getAllOrders(),
    getUnreadNotifications(3),
  ]);

  const lowStock = products.filter((product) => product.stock <= 10);
  const recent = orders.slice(0, 6);

  const cards = [
    {
      label: "Total Products",
      value: String(stats.totalProducts),
      hint: `${stats.activeProducts} live in store`,
      href: "/admin/products",
    },
    {
      label: "Total Orders",
      value: String(stats.totalOrders),
      hint: `${stats.cancelledOrders} cancelled`,
      href: "/admin/orders",
    },
    {
      label: "Pending Orders",
      value: String(stats.pendingOrders),
      hint: "Awaiting action",
      href: "/admin/orders",
    },
    {
      label: "Completed Orders",
      value: String(stats.completedOrders),
      hint: "Delivered",
      href: "/admin/orders",
    },
    {
      label: "Total Reviews",
      value: String(stats.totalReviews),
      hint: `${stats.pendingReviews} awaiting approval`,
      href: "/admin/reviews",
    },
    {
      label: "Average Rating",
      value: stats.totalReviews > 0 ? `${stats.averageRating} / 5` : "—",
      hint: "Approved reviews only",
      href: "/admin/reviews",
    },
    {
      label: "Total Sales",
      value: formatPkr(stats.totalRevenue),
      hint: "Excludes cancelled",
      href: "/admin/orders",
    },
    {
      label: "Delivered Revenue",
      value: formatPkr(stats.completedRevenue),
      hint: "From completed orders",
      href: "/admin/orders",
    },
  ];

  return (
    <div className="space-y-8">
      <div>
        <h1 className="font-display text-3xl text-forest-900 sm:text-4xl">
          Dashboard
        </h1>
        <p className="mt-2 text-sm text-ink/60">
          Live figures from your store database.
        </p>
      </div>

      {alerts.unreadCount > 0 ? (
        <Link
          href="/admin/orders"
          className="flex flex-wrap items-center justify-between gap-3 rounded-2xl border border-[#25D366] bg-[#25D366]/12 px-5 py-4 transition hover:bg-[#25D366]/20"
        >
          <span className="text-sm font-semibold text-forest-900">
            🔔 {alerts.unreadCount} new order alert
            {alerts.unreadCount === 1 ? "" : "s"} waiting for you
          </span>
          <span className="rounded-full bg-forest-800 px-4 py-2 text-xs font-semibold text-cream">
            Review now
          </span>
        </Link>
      ) : null}

      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {cards.map((card) => (
          <Link
            key={card.label}
            href={card.href}
            className="rounded-[1.5rem] border border-sand bg-white p-5 transition hover:border-gold/60 hover:shadow-card"
          >
            <p className="text-[10px] font-semibold uppercase tracking-[0.18em] text-moss">
              {card.label}
            </p>
            <p className="mt-2.5 font-display text-2xl text-forest-900 sm:text-3xl">
              {card.value}
            </p>
            <p className="mt-1.5 text-[11px] text-ink/50">{card.hint}</p>
          </Link>
        ))}
      </div>

      <div className="grid gap-6 lg:grid-cols-2">
        {/* Recent orders */}
        <section className="rounded-[1.5rem] border border-sand bg-white p-6">
          <div className="flex items-center justify-between gap-3">
            <h2 className="font-display text-xl text-forest-900">
              Recent orders
            </h2>
            <Link
              href="/admin/orders"
              className="text-xs font-semibold text-moss underline underline-offset-4"
            >
              View all
            </Link>
          </div>

          {recent.length === 0 ? (
            <div className="mt-5 rounded-2xl bg-cream px-4 py-8 text-center">
              <p className="text-sm font-medium text-forest-900">
                No orders yet
              </p>
              <p className="mt-1 text-xs text-ink/55">
                Orders placed at checkout appear here automatically.
              </p>
            </div>
          ) : (
            <ul className="mt-5 divide-y divide-sand">
              {recent.map((order) => {
                const status = normalizeOrderStatus(order.status);
                return (
                  <li key={order.id} className="flex items-center gap-3 py-3">
                    <div className="min-w-0 flex-1">
                      <p className="truncate text-sm font-semibold text-forest-900">
                        {order.customerName}
                      </p>
                      <p className="text-xs text-ink/55">
                        {order.orderNumber} · {order.city} ·{" "}
                        {formatDate(order.createdAt)}
                      </p>
                    </div>
                    <div className="shrink-0 text-right">
                      <p className="text-sm font-semibold text-forest-900">
                        {formatPkr(order.totalPaisa)}
                      </p>
                      <p className="text-[10px] font-semibold uppercase tracking-[0.1em] text-moss">
                        {ORDER_STATUS_LABELS[status]}
                      </p>
                    </div>
                  </li>
                );
              })}
            </ul>
          )}
        </section>

        {/* Stock + quick actions */}
        <section className="rounded-[1.5rem] border border-sand bg-white p-6">
          <div className="flex items-center justify-between gap-3">
            <h2 className="font-display text-xl text-forest-900">Stock alerts</h2>
            <Link
              href="/admin/products"
              className="text-xs font-semibold text-moss underline underline-offset-4"
            >
              Manage
            </Link>
          </div>

          {lowStock.length === 0 ? (
            <p className="mt-5 rounded-2xl bg-cream px-4 py-8 text-center text-sm text-ink/55">
              All products have healthy stock levels.
            </p>
          ) : (
            <ul className="mt-5 space-y-3">
              {lowStock.map((product) => (
                <li
                  key={product.id}
                  className="flex items-center justify-between gap-3 rounded-2xl bg-cream px-4 py-3"
                >
                  <span className="min-w-0 truncate text-sm font-medium text-forest-900">
                    {product.name}
                  </span>
                  <span className="shrink-0 rounded-full bg-[#8a6a12]/15 px-2.5 py-1 text-[11px] font-bold text-[#8a6a12]">
                    {product.stock} left
                  </span>
                </li>
              ))}
            </ul>
          )}

          <div className="mt-6 space-y-2.5 border-t border-sand pt-5">
            <Link
              href="/admin/products/new"
              className="block rounded-full bg-forest-800 px-5 py-3.5 text-center text-sm font-semibold text-cream transition hover:bg-forest-700"
            >
              + Add new product
            </Link>
            {stats.pendingReviews > 0 ? (
              <Link
                href="/admin/reviews"
                className="block rounded-full border border-gold bg-gold/10 px-5 py-3.5 text-center text-sm font-semibold text-forest-900 transition hover:bg-gold/20"
              >
                {stats.pendingReviews} review
                {stats.pendingReviews === 1 ? "" : "s"} awaiting approval
              </Link>
            ) : null}
          </div>
        </section>
      </div>
    </div>
  );
}
