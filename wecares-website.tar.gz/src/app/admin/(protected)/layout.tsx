import type { ReactNode } from "react";
import Link from "next/link";
import { Logo } from "@/components/Logo";
import { AdminNav } from "@/components/admin/AdminNav";
import {
  getAdminSession,
  usingDefaultAdminCredentials,
} from "@/lib/admin-auth";
import { redirect } from "next/navigation";
import { headers } from "next/headers";

export const dynamic = "force-dynamic";

export default async function AdminLayout({
  children,
}: {
  children: ReactNode;
}) {
  const session = await getAdminSession();
  if (!session) redirect("/admin/login");

  // Warn the owner while the panel is still on its built-in credentials.
  const usingDefaults = usingDefaultAdminCredentials();

  return (
    <div className="min-h-screen bg-cream">
      <header className="border-b border-sand bg-forest-900 text-cream">
        <div className="mx-auto flex max-w-7xl flex-wrap items-center justify-between gap-3 px-4 py-3.5 sm:px-6 lg:px-8">
          <Link href="/admin" className="flex items-center gap-3">
            <Logo variant="dark" compact />
            <span className="rounded-full border border-gold/40 px-3 py-1 text-[10px] font-bold uppercase tracking-[0.16em] text-gold">
              Admin
            </span>
          </Link>
          <AdminNav username={session.username} />
        </div>
      </header>

      {usingDefaults ? (
        <div className="bg-[#8a6a12] px-4 py-2.5 text-center text-xs font-medium text-cream">
          <strong className="font-bold">Setup required:</strong> no admin
          password is configured yet, so signing in is disabled. Set{" "}
          <code className="rounded bg-black/20 px-1.5 py-0.5">
            ADMIN_USERNAME
          </code>{" "}
          and{" "}
          <code className="rounded bg-black/20 px-1.5 py-0.5">
            ADMIN_PASSWORD
          </code>{" "}
          in your hosting environment variables, then redeploy. You can change
          the password afterwards from Settings → Password.
        </div>
      ) : null}

      <div className="mx-auto max-w-7xl px-4 py-8 sm:px-6 lg:px-8">{children}</div>
    </div>
  );
}
