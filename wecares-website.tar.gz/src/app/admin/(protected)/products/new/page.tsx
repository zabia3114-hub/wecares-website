import type { Metadata } from "next";
import { ProductEditor } from "@/components/admin/ProductEditor";
import { getCollectionsAdmin } from "@/lib/admin-queries";
import { ensureDefaultCategories, listCategories } from "@/lib/categories";

export const dynamic = "force-dynamic";

export const metadata: Metadata = {
  title: "Add product",
  robots: { index: false, follow: false },
};

export default async function NewProductPage() {
  const [collections, categories] = await Promise.all([
    getCollectionsAdmin(),
    (async () => {
      await ensureDefaultCategories();
      return listCategories(false);
    })(),
  ]);

  return (
    <ProductEditor
      mode="create"
      collections={collections.map((collection) => ({
        slug: collection.slug,
        name: collection.name,
      }))}
      categories={categories.map((category) => ({
        id: category.id,
        name: category.name,
      }))}
      initial={{
        slug: "",
        name: "",
        subtitle: "",
        description: "",
        howToUse: "",
        disclaimer: "",
        collectionSlug: collections[0]?.slug ?? "",
        categoryLabel: "Herbal Product",
        priceRupees: "",
        compareAtRupees: "",
        image: "",
        highlights: "",
        ingredients: "",
        netWeight: "",
        suitability: "For men & women",
        isFeatured: true,
        isBestseller: false,
        isActive: true,
        stock: 50,
        sortOrder: 10,
      }}
    />
  );
}
