import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { db } from "@/db";
import { products } from "@/db/schema";
import { eq } from "drizzle-orm";
import { ProductEditor } from "@/components/admin/ProductEditor";
import { getCollectionsAdmin } from "@/lib/admin-queries";
import { listCategories } from "@/lib/categories";

export const dynamic = "force-dynamic";

export const metadata: Metadata = {
  title: "Edit product",
  robots: { index: false, follow: false },
};

type Params = Promise<{ id: string }>;

export default async function EditProductPage({ params }: { params: Params }) {
  const { id } = await params;
  const productId = Number(id);
  if (!Number.isFinite(productId)) notFound();

  const [rows, collections, categories] = await Promise.all([
    db.select().from(products).where(eq(products.id, productId)).limit(1),
    getCollectionsAdmin(),
    listCategories(false),
  ]);

  const product = rows[0];
  if (!product) notFound();

  return (
    <ProductEditor
      mode="edit"
      productId={product.id}
      collections={collections.map((collection) => ({
        slug: collection.slug,
        name: collection.name,
      }))}
      categories={categories.map((category) => ({
        id: category.id,
        name: category.name,
      }))}
      initial={{
        slug: product.slug,
        name: product.name,
        subtitle: product.subtitle,
        description: product.description,
        howToUse: product.howToUse,
        disclaimer: product.disclaimer,
        collectionSlug: product.collectionSlug,
        categoryLabel: product.categoryLabel,
        priceRupees: product.pricePaisa / 100,
        compareAtRupees: product.compareAtPaisa
          ? product.compareAtPaisa / 100
          : "",
        image: product.images[0] ?? "",
        highlights: product.highlights.join("\n"),
        ingredients: product.ingredients.join("\n"),
        netWeight: product.netWeight,
        suitability: product.suitability,
        isFeatured: product.isFeatured,
        isBestseller: product.isBestseller,
        isActive: product.isActive,
        stock: product.stock,
        sortOrder: product.sortOrder,
        categoryId: product.categoryId ?? "",
      }}
    />
  );
}
