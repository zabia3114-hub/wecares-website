import type { Metadata } from "next";
import { ProductsManager } from "@/components/admin/ProductsManager";
import { getAllProductsForAdmin, getCollectionsAdmin } from "@/lib/admin-queries";
import { listCategories } from "@/lib/categories";

export const dynamic = "force-dynamic";

export const metadata: Metadata = {
  title: "Products",
  robots: { index: false, follow: false, nocache: true },
};

export default async function AdminProductsPage() {
  const [products, collections, categories] = await Promise.all([
    getAllProductsForAdmin(),
    getCollectionsAdmin(),
    listCategories(false),
  ]);

  return (
    <ProductsManager
      products={products.map((product) => ({
        id: product.id,
        slug: product.slug,
        name: product.name,
        subtitle: product.subtitle,
        description: product.description,
        howToUse: product.howToUse,
        disclaimer: product.disclaimer,
        collectionSlug: product.collectionSlug,
        categoryLabel: product.categoryLabel,
        categoryId: product.categoryId ?? "",
        priceRupees: product.pricePaisa / 100,
        compareAtRupees: product.compareAtPaisa
          ? product.compareAtPaisa / 100
          : null,
        image: product.images[0] ?? "",
        highlights: product.highlights,
        ingredients: product.ingredients,
        netWeight: product.netWeight,
        suitability: product.suitability,
        isFeatured: product.isFeatured,
        isBestseller: product.isBestseller,
        isActive: product.isActive,
        stock: product.stock,
        sortOrder: product.sortOrder,
      }))}
      collections={collections.map((collection) => ({
        slug: collection.slug,
        name: collection.name,
      }))}
    />
  );
}
