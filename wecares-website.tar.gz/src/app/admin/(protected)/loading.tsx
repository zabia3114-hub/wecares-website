/** Shown while admin data is being fetched. */
export default function AdminLoading() {
  return (
    <div className="space-y-6">
      <div>
        <div className="skeleton h-9 w-56 rounded-2xl" />
        <div className="skeleton mt-3 h-4 w-72 rounded-full" />
      </div>

      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {Array.from({ length: 4 }).map((_, index) => (
          <div
            key={index}
            className="rounded-[1.5rem] border border-sand bg-white p-6"
          >
            <div className="skeleton h-3 w-20 rounded-full" />
            <div className="skeleton mt-4 h-8 w-24 rounded-xl" />
            <div className="skeleton mt-3 h-3 w-32 rounded-full" />
          </div>
        ))}
      </div>

      <div className="rounded-[1.5rem] border border-sand bg-white p-6">
        <div className="skeleton h-5 w-40 rounded-full" />
        <div className="mt-5 space-y-3">
          {Array.from({ length: 4 }).map((_, index) => (
            <div key={index} className="flex items-center gap-4">
              <div className="skeleton h-12 w-12 rounded-xl" />
              <div className="flex-1 space-y-2">
                <div className="skeleton h-4 w-1/3 rounded-full" />
                <div className="skeleton h-3 w-1/2 rounded-full" />
              </div>
              <div className="skeleton h-4 w-20 rounded-full" />
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
