import type { Metadata } from "next";
import { CategoriesManager } from "@/components/admin/CategoriesManager";
import { ensureDefaultCategories, listCategories } from "@/lib/categories";

export const dynamic = "force-dynamic";

export const metadata: Metadata = {
  title: "Categories",
  robots: { index: false, follow: false },
};

export default async function AdminCategoriesPage() {
  await ensureDefaultCategories();
  const categories = await listCategories(false);

  return (
    <CategoriesManager
      categories={categories.map((category) => ({
        id: category.id,
        name: category.name,
        slug: category.slug,
        description: category.description,
        image: category.image,
        isActive: category.isActive,
        sortOrder: category.sortOrder,
        productCount: category.productCount,
      }))}
    />
  );
}
