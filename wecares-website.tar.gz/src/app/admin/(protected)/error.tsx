"use client";

import Link from "next/link";
import { useEffect } from "react";

/**
 * Admin error boundary. Keeps the operator inside the admin shell with a way
 * back to the dashboard instead of dropping them on a dead page.
 */
export default function AdminError({
  error,
  reset,
}: {
  error: Error & { digest?: string };
  reset: () => void;
}) {
  useEffect(() => {
    console.error("admin error", error);
  }, [error]);

  return (
    <div className="rounded-[1.5rem] border border-sand bg-white px-6 py-16 text-center">
      <h1 className="font-display text-2xl text-forest-900 sm:text-3xl">
        Could not load this page
      </h1>
      <p className="mx-auto mt-3 max-w-md text-sm leading-relaxed text-ink/65">
        Something went wrong while loading admin data. Your products, orders and
        reviews are unaffected — try again below.
      </p>
      <div className="mt-7 flex flex-col justify-center gap-3 sm:flex-row">
        <button
          type="button"
          onClick={reset}
          className="rounded-full bg-forest-800 px-7 py-3.5 text-sm font-semibold text-cream transition hover:bg-forest-700"
        >
          Try again
        </button>
        <Link
          href="/admin"
          className="rounded-full border border-sand bg-white px-7 py-3.5 text-sm font-semibold text-forest-800 transition hover:border-gold"
        >
          Back to dashboard
        </Link>
      </div>
    </div>
  );
}
