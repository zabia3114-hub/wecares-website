import {
  getAdminSession,
  hashPassword,
  verifyCredentials,
} from "@/lib/admin-auth";
import { db } from "@/db";
import { adminUsers } from "@/db/schema";
import { eq } from "drizzle-orm";

export const dynamic = "force-dynamic";

/**
 * Lets the signed-in admin change their own password.
 * The current password must be supplied, and the new one is stored as a
 * salted scrypt hash — never plain text.
 */
export async function POST(request: Request) {
  const session = await getAdminSession();
  if (!session) return Response.json({ error: "Unauthorized" }, { status: 401 });

  let body: { currentPassword?: string; newPassword?: string };
  try {
    body = (await request.json()) as {
      currentPassword?: string;
      newPassword?: string;
    };
  } catch {
    return Response.json({ error: "Invalid request" }, { status: 400 });
  }

  const currentPassword = body.currentPassword ?? "";
  const newPassword = body.newPassword ?? "";

  if (newPassword.length < 8) {
    return Response.json(
      { error: "New password must be at least 8 characters." },
      { status: 400 },
    );
  }
  if (newPassword.length > 128) {
    return Response.json(
      { error: "Password is too long (max 128 characters)." },
      { status: 400 },
    );
  }

  // Confirm the operator knows the existing password.
  const authorised = await verifyCredentials(session.username, currentPassword);
  if (!authorised) {
    await new Promise((resolve) => setTimeout(resolve, 300));
    return Response.json(
      { error: "Current password is incorrect." },
      { status: 401 },
    );
  }

  const passwordHash = hashPassword(newPassword);

  try {
    const existing = await db
      .select({ id: adminUsers.id })
      .from(adminUsers)
      .where(eq(adminUsers.username, session.username))
      .limit(1);

    if (existing[0]) {
      await db
        .update(adminUsers)
        .set({ passwordHash })
        .where(eq(adminUsers.id, existing[0].id));
    } else {
      await db
        .insert(adminUsers)
        .values({ username: session.username, passwordHash });
    }
  } catch (error) {
    console.error("password update failed", error);
    return Response.json({ error: "Could not update password" }, { status: 500 });
  }

  return Response.json({ ok: true });
}
