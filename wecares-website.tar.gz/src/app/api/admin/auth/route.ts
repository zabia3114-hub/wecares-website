import {
  clearAdminCookie,
  ensureAdminAccount,
  recordSuccessfulLogin,
  setAdminCookie,
  verifyCredentials,
} from "@/lib/admin-auth";

export const dynamic = "force-dynamic";

export async function POST(request: Request) {
  let body: { username?: string; password?: string };
  try {
    body = (await request.json()) as { username?: string; password?: string };
  } catch {
    return Response.json({ error: "Invalid request" }, { status: 400 });
  }

  const username = body.username?.trim() ?? "";
  const password = body.password ?? "";

  if (!username || !password) {
    return Response.json(
      { error: "Enter your username and password." },
      { status: 400 },
    );
  }

  // verifyCredentials is async (it reads the hashed account from the database),
  // so it must be awaited — otherwise the Promise itself is truthy and every
  // password would be accepted.
  if (!(await verifyCredentials(username, password))) {
    // Small delay to blunt brute-force attempts.
    await new Promise((resolve) => setTimeout(resolve, 400));
    return Response.json(
      { error: "Incorrect username or password." },
      { status: 401 },
    );
  }

  // Store a salted hash for this account so a password changed later from the
  // admin panel keeps working. Only the hash is persisted, never the password.
  await ensureAdminAccount(username.trim(), password);
  await recordSuccessfulLogin(username.trim());

  await setAdminCookie(username.trim());
  return Response.json({ ok: true });
}

export async function DELETE() {
  await clearAdminCookie();
  return Response.json({ ok: true });
}
