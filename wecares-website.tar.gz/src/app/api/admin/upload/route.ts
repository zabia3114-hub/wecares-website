import { promises as fs } from "node:fs";
import path from "node:path";
import { getAdminSession } from "@/lib/admin-auth";
import { db } from "@/db";
import { images } from "@/db/schema";

export const dynamic = "force-dynamic";

const ALLOWED = new Map<string, string>([
  ["image/jpeg", "jpg"],
  ["image/jpg", "jpg"],
  ["image/pjpeg", "jpg"],
  ["image/png", "png"],
  ["image/webp", "webp"],
  ["image/avif", "avif"],
  ["image/gif", "gif"],
  ["image/bmp", "bmp"],
  ["image/heic", "heic"],
  ["image/heif", "heif"],
  // Some Android browsers report HEIC this way.
  ["image/heic-sequence", "heic"],
]);

const MAX_BYTES = 6 * 1024 * 1024; // 6 MB

/**
 * Stores an uploaded product image in the DATABASE and returns its serving URL.
 *
 * We deliberately do not write into `public/`: that directory's contents are
 * snapshotted at build time, so files written at runtime are never served
 * (they return 404), and the folder is read-only on serverless hosts such as
 * Vercel. Storing bytes in Postgres makes uploads work on every host.
 */
export async function POST(request: Request) {
  const session = await getAdminSession();
  if (!session) {
    return Response.json({ error: "Unauthorized" }, { status: 401 });
  }

  let form: FormData;
  try {
    form = await request.formData();
  } catch {
    return Response.json({ error: "Invalid upload" }, { status: 400 });
  }

  const file = form.get("file");
  if (!(file instanceof File)) {
    return Response.json({ error: "No file received" }, { status: 400 });
  }

  let extension = ALLOWED.get(file.type);

  // Fallback: trust the file extension when the browser sends an unfamiliar
  // MIME type (common with phone cameras reporting HEIC/HEIF).
  if (!extension) {
    const ext = path.extname(file.name).replace(".", "").toLowerCase();
    if (["jpg", "jpeg", "png", "webp", "avif", "gif", "bmp", "heic", "heif"].includes(ext)) {
      extension = ext === "jpeg" ? "jpg" : ext;
    }
  }

  if (!extension || !file.type.startsWith("image/")) {
    return Response.json(
      {
        error:
          "That file is not a supported image. Please use a JPG, PNG, WebP or HEIC photo.",
      },
      { status: 400 },
    );
  }
  if (file.size > MAX_BYTES) {
    return Response.json(
      { error: "Image is too large. Please use a file under 6 MB." },
      { status: 400 },
    );
  }

  const requested = String(form.get("filename") ?? "").trim();
  const base = (requested || path.basename(file.name, path.extname(file.name)))
    .toLowerCase()
    .replace(/"/g, "")
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "")
    .slice(0, 60);

  if (!base) {
    return Response.json(
      { error: "Could not determine a file name." },
      { status: 400 },
    );
  }

  const filename = `${base}.${extension}`;
  const buffer = Buffer.from(await file.arrayBuffer());

  try {
    await db
      .insert(images)
      .values({
        filename,
        mimeType: file.type,
        data: buffer.toString("base64"),
        byteSize: buffer.byteLength,
      })
      .onConflictDoUpdate({
        target: images.filename,
        set: {
          mimeType: file.type,
          data: buffer.toString("base64"),
          byteSize: buffer.byteLength,
        },
      });
  } catch (error) {
    console.error("image save failed", error);
    return Response.json(
      { error: "Could not save the image. Try again." },
      { status: 500 },
    );
  }

  // Best-effort mirror into public/ for hosts where it does work. Failures are
  // ignored because the database copy is the one actually served.
  try {
    const dir = path.join(process.cwd(), "public", "images", "products");
    await fs.mkdir(dir, { recursive: true });
    await fs.writeFile(path.join(dir, filename), buffer);
  } catch {
    /* read-only filesystem — the database copy still works */
  }

  return Response.json({ ok: true, filename, url: `/api/images/${filename}` });
}
