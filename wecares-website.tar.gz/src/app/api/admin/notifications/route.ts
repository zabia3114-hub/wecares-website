import { getAdminSession } from "@/lib/admin-auth";
import {
  getUnreadNotifications,
  markNotificationsRead,
} from "@/lib/notifications";

export const dynamic = "force-dynamic";

export async function GET() {
  const session = await getAdminSession();
  if (!session) return Response.json({ error: "Unauthorized" }, { status: 401 });

  const summary = await getUnreadNotifications();
  return Response.json({ ok: true, ...summary });
}

export async function POST(request: Request) {
  const session = await getAdminSession();
  if (!session) return Response.json({ error: "Unauthorized" }, { status: 401 });

  let body: { ids?: number[] } = {};
  try {
    body = (await request.json()) as { ids?: number[] };
  } catch {
    body = {};
  }

  const ok = await markNotificationsRead(body.ids);
  if (!ok) return Response.json({ error: "Could not update" }, { status: 500 });

  const summary = await getUnreadNotifications();
  return Response.json({ ok: true, ...summary });
}
