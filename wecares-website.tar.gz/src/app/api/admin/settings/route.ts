import { getAdminSession } from "@/lib/admin-auth";
import { getSiteSettings, saveSiteSettings, getTheme } from "@/lib/settings";

export const dynamic = "force-dynamic";

export async function GET() {
  const session = await getAdminSession();
  if (!session) return Response.json({ error: "Unauthorized" }, { status: 401 });

  const settings = await getSiteSettings();
  return Response.json({ ok: true, settings });
}

export async function POST(request: Request) {
  const session = await getAdminSession();
  if (!session) return Response.json({ error: "Unauthorized" }, { status: 401 });

  let body: Record<string, unknown>;
  try {
    body = (await request.json()) as Record<string, unknown>;
  } catch {
    return Response.json({ error: "Invalid request body" }, { status: 400 });
  }

  // Only allow known theme ids through.
  if (typeof body.theme === "string") {
    const theme = getTheme(body.theme);
    body.theme = theme.id;
  }

  try {
    const { saved } = await saveSiteSettings(body);
    const settings = await getSiteSettings();
    return Response.json({ ok: true, saved, settings });
  } catch (error) {
    console.error("save settings failed", error);
    return Response.json({ error: "Could not save settings" }, { status: 500 });
  }
}
