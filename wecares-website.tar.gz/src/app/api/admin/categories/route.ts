import { getAdminSession } from "@/lib/admin-auth";
import {
  assignProductCategory,
  createCategory,
  deleteCategory,
  ensureDefaultCategories,
  listCategories,
  renameCategory,
  setCategoryActive,
  updateCategory,
} from "@/lib/categories";

export const dynamic = "force-dynamic";

export async function GET() {
  const session = await getAdminSession();
  if (!session) return Response.json({ error: "Unauthorized" }, { status: 401 });

  try {
    await ensureDefaultCategories();
    const categories = await listCategories(false);
    return Response.json({ ok: true, categories });
  } catch (error) {
    console.error("list categories failed", error);
    return Response.json({ error: "Could not load categories" }, { status: 500 });
  }
}

type Body = {
  action?: string;
  id?: number;
  categoryId?: number | null;
  productId?: number;
  name?: string;
  description?: string;
  image?: string;
  isActive?: boolean;
  sortOrder?: number;
};

export async function POST(request: Request) {
  const session = await getAdminSession();
  if (!session) return Response.json({ error: "Unauthorized" }, { status: 401 });

  let body: Body;
  try {
    body = (await request.json()) as Body;
  } catch {
    return Response.json({ error: "Invalid request body" }, { status: 400 });
  }

  const id = Number(body.id);

  try {
    switch (body.action) {
      case "create":
      case "add": {
        const row = await createCategory({
          name: body.name ?? "",
          description: body.description,
          image: body.image,
          isActive: body.isActive,
          sortOrder: body.sortOrder,
        });
        return Response.json({ ok: true, category: row }, { status: 201 });
      }

      case "update":
      case "edit": {
        if (!Number.isFinite(id)) {
          return Response.json({ error: "Missing category id" }, { status: 400 });
        }
        const row = await updateCategory(id, {
          name: body.name ?? "",
          description: body.description,
          image: body.image,
          isActive: body.isActive,
          sortOrder: body.sortOrder,
        });
        if (!row) return Response.json({ error: "Category not found" }, { status: 404 });
        return Response.json({ ok: true, category: row });
      }

      case "rename": {
        if (!Number.isFinite(id) || !body.name) {
          return Response.json({ error: "Missing id or name" }, { status: 400 });
        }
        const row = await renameCategory(id, body.name);
        if (!row) return Response.json({ error: "Category not found" }, { status: 404 });
        return Response.json({ ok: true, category: row });
      }

      case "toggle-active": {
        if (!Number.isFinite(id)) {
          return Response.json({ error: "Missing category id" }, { status: 400 });
        }
        const row = await setCategoryActive(id, Boolean(body.isActive));
        if (!row) return Response.json({ error: "Category not found" }, { status: 404 });
        return Response.json({ ok: true, category: row });
      }

      case "delete": {
        if (!Number.isFinite(id)) {
          return Response.json({ error: "Missing category id" }, { status: 400 });
        }
        const row = await deleteCategory(id);
        if (!row) return Response.json({ error: "Category not found" }, { status: 404 });
        return Response.json({ ok: true, deleted: row });
      }

      case "assign-product": {
        const productId = Number(body.productId);
        const categoryId =
          body.categoryId == null ? null : Number(body.categoryId);
        if (!Number.isFinite(productId)) {
          return Response.json({ error: "Missing product id" }, { status: 400 });
        }
        const row = await assignProductCategory(productId, categoryId);
        if (!row) return Response.json({ error: "Product not found" }, { status: 404 });
        return Response.json({ ok: true, product: row });
      }

      default:
        return Response.json({ error: "Unknown action" }, { status: 400 });
    }
  } catch (error) {
    console.error("category mutation failed", error);
    return Response.json(
      {
        error:
          error instanceof Error ? error.message : "Could not update categories",
      },
      { status: 400 },
    );
  }
}
