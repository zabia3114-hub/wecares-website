import { getAdminSession } from "@/lib/admin-auth";
import {
  createProduct,
  deleteOrder,
  deleteProduct,
  deleteReview,
  setReviewStatus,
  toggleProductActive,
  updateOrderStatus,
  updateProduct,
  updateProductPrice,
  type ProductInput,
} from "@/lib/admin-queries";

export const dynamic = "force-dynamic";

async function guard() {
  const session = await getAdminSession();
  if (!session) return { error: Response.json({ error: "Unauthorized" }, { status: 401 }) };
  return { session };
}

type Payload = {
  action?: string;
  id?: number;
  isActive?: boolean;
  status?: string;
  priceRupees?: number;
  compareAtRupees?: number | null;
  product?: Partial<ProductInput>;
};

/** Parses a list-ish field that may arrive as an array or newline text. */
function toList(value: unknown): string[] {
  if (Array.isArray(value)) {
    return value.map((item) => String(item).trim()).filter(Boolean);
  }
  if (typeof value === "string") {
    return value
      .split("\n")
      .map((line) => line.replace(/^[-•*]\s*/, "").trim())
      .filter(Boolean);
  }
  return [];
}

export async function POST(request: Request) {
  const gate = await guard();
  if (gate.error) return gate.error;

  let body: Payload;
  try {
    body = (await request.json()) as Payload;
  } catch {
    return Response.json({ error: "Invalid request body" }, { status: 400 });
  }

  const id = Number(body.id);

  // Accept a few forgiving aliases so an older cached admin bundle can never
  // produce "Unknown action". Only these map onto real actions; anything else
  // is still rejected.
  const ACTION_ALIASES: Record<string, string> = {
    create: "create",
    add: "create",
    new: "create",
    update: "update",
    edit: "update",
    save: "update",
    "product-update": "update",
    "product-create": "create",
  };

  const rawAction = typeof body.action === "string" ? body.action.trim() : "";
  const action = ACTION_ALIASES[rawAction.toLowerCase()] ?? rawAction;
  if (body.action !== undefined) body.action = action as Payload["action"];

  try {
    switch (body.action) {
      case "toggle-active": {
        if (!Number.isFinite(id)) {
          return Response.json({ error: "Missing product id" }, { status: 400 });
        }
        const row = await toggleProductActive(id, Boolean(body.isActive));
        if (!row) return Response.json({ error: "Product not found" }, { status: 404 });
        return Response.json({ ok: true, product: row });
      }

      case "update-price": {
        const price = Number(body.priceRupees);
        if (!Number.isFinite(price) || price <= 0) {
          return Response.json({ error: "Enter a valid sale price" }, { status: 400 });
        }
        const compareAt =
          body.compareAtRupees == null || Number(body.compareAtRupees) === 0
            ? null
            : Number(body.compareAtRupees);
        if (compareAt != null && compareAt <= price) {
          return Response.json(
            { error: "Original price must be higher than the sale price." },
            { status: 400 },
          );
        }
        const row = await updateProductPrice(id, price, compareAt);
        if (!row) return Response.json({ error: "Product not found" }, { status: 404 });
        return Response.json({ ok: true, product: row });
      }

      case "order-status": {
        if (!Number.isFinite(id) || !body.status) {
          return Response.json({ error: "Missing order id or status" }, { status: 400 });
        }
        const row = await updateOrderStatus(id, body.status);
        if (!row) return Response.json({ error: "Order not found" }, { status: 404 });
        return Response.json({ ok: true, order: row });
      }

      case "review-status": {
        if (!Number.isFinite(id) || !body.status) {
          return Response.json(
            { error: "Missing review id or status" },
            { status: 400 },
          );
        }
        const row = await setReviewStatus(id, body.status);
        if (!row) return Response.json({ error: "Review not found" }, { status: 404 });
        return Response.json({ ok: true, review: row });
      }

      case "order-delete": {
        if (!Number.isFinite(id)) {
          return Response.json({ error: "Missing order id" }, { status: 400 });
        }
        const row = await deleteOrder(id);
        if (!row) return Response.json({ error: "Order not found" }, { status: 404 });
        return Response.json({ ok: true, deleted: row });
      }

      case "review-delete": {
        if (!Number.isFinite(id)) {
          return Response.json({ error: "Missing review id" }, { status: 400 });
        }
        const row = await deleteReview(id);
        if (!row) return Response.json({ error: "Review not found" }, { status: 404 });
        return Response.json({ ok: true, deleted: row });
      }

      case "delete": {
        if (!Number.isFinite(id)) {
          return Response.json({ error: "Missing product id" }, { status: 400 });
        }
        const row = await deleteProduct(id);
        if (!row) return Response.json({ error: "Product not found" }, { status: 404 });
        return Response.json({ ok: true, deleted: row });
      }

      case "create":
      case "update": {
        const p = body.product ?? {};
        const name = p.name?.trim() ?? "";
        if (name.length < 3) {
          return Response.json({ error: "Product name is required." }, { status: 400 });
        }
        const price = Number(p.priceRupees);
        if (!Number.isFinite(price) || price <= 0) {
          return Response.json({ error: "Enter a valid sale price." }, { status: 400 });
        }
        if (!p.collectionSlug) {
          return Response.json({ error: "Choose a collection." }, { status: 400 });
        }

        const input: ProductInput = {
          name,
          subtitle: p.subtitle?.trim() || name,
          description: p.description?.trim() || p.subtitle?.trim() || name,
          howToUse: p.howToUse?.trim() || "Use as directed on the pack label.",
          disclaimer: p.disclaimer?.trim(),
          collectionSlug: p.collectionSlug,
          categoryLabel: p.categoryLabel?.trim() || "Herbal Product",
          priceRupees: price,
          compareAtRupees:
            p.compareAtRupees == null || Number(p.compareAtRupees) === 0
              ? null
              : Number(p.compareAtRupees),
          image: p.image?.trim() ?? "",
          categoryId:
            p.categoryId == null ||
            String(p.categoryId) === "" ||
            Number(p.categoryId) === 0
              ? null
              : Number(p.categoryId),
          highlights: toList(p.highlights),
          ingredients: toList(p.ingredients),
          netWeight: p.netWeight?.trim() || "—",
          suitability: p.suitability?.trim() || "For men & women",
          isFeatured: Boolean(p.isFeatured),
          isBestseller: Boolean(p.isBestseller),
          isActive: p.isActive ?? true,
          stock: Number.isFinite(Number(p.stock)) ? Math.max(0, Number(p.stock)) : 0,
          sortOrder: Number.isFinite(Number(p.sortOrder))
            ? Number(p.sortOrder)
            : 99,
        };

        if (body.action === "create") {
          const row = await createProduct(input);
          return Response.json({ ok: true, product: row }, { status: 201 });
        }

        if (!Number.isFinite(id)) {
          return Response.json({ error: "Missing product id" }, { status: 400 });
        }
        const row = await updateProduct(id, input);
        if (!row) return Response.json({ error: "Product not found" }, { status: 404 });
        return Response.json({ ok: true, product: row });
      }

      default:
        return Response.json({ error: "Unknown action" }, { status: 400 });
    }
  } catch (error) {
    console.error("admin mutation failed", error);
    const message =
      error instanceof Error ? error.message : "Something went wrong.";
    return Response.json({ error: message }, { status: 500 });
  }
}
