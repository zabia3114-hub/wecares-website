import { createOrder } from "@/lib/queries";
import {
  isValidPkMobile,
  normalizePkMobile,
  type ShippingMethod,
} from "@/lib/format";

export const dynamic = "force-dynamic";

type Body = {
  customerName?: string;
  mobile?: string;
  address?: string;
  city?: string;
  province?: string;
  orderDetails?: string;
  paymentMethod?: "cod" | "bank-transfer";
  shippingMethod?: ShippingMethod;
  items?: Array<{ slug?: string; quantity?: number }>;
};

export async function POST(request: Request) {
  let body: Body;
  try {
    body = (await request.json()) as Body;
  } catch {
    return Response.json({ error: "Invalid request body" }, { status: 400 });
  }

  const customerName = body.customerName?.trim() ?? "";
  const mobileRaw = body.mobile?.trim() ?? "";
  const address = body.address?.trim() ?? "";
  const city = body.city?.trim() ?? "";

  const missing: string[] = [];
  if (customerName.length < 3) missing.push("full name");
  if (!isValidPkMobile(mobileRaw)) missing.push("valid Pakistani mobile number");
  if (address.length < 10) missing.push("complete delivery address");
  if (city.length < 2) missing.push("city");

  if (missing.length > 0) {
    return Response.json(
      { error: `Please provide: ${missing.join(", ")}.` },
      { status: 400 },
    );
  }

  const items = (body.items ?? [])
    .filter((item): item is { slug: string; quantity: number } =>
      Boolean(item?.slug) && typeof item?.quantity === "number",
    )
    .map((item) => ({
      slug: item.slug,
      quantity: Math.round(item.quantity),
    }));

  if (items.length === 0) {
    return Response.json({ error: "Your cart is empty" }, { status: 400 });
  }

  // Prices and stock are always resolved on the server, so the browser can
  // never dictate an order total or buy an item that is not really available.
  const result = await createOrder({
    customerName,
    mobile: normalizePkMobile(mobileRaw),
    address,
    city,
    province: body.province?.trim() ?? "",
    orderDetails: body.orderDetails?.slice(0, 600) ?? "",
    paymentMethod:
      body.paymentMethod === "bank-transfer" ? "bank-transfer" : "cod",
    shippingMethod: (body.shippingMethod === "express"
      ? "express"
      : "standard") as ShippingMethod,
    items,
    subtotalPaisa: 0,
    shippingPaisa: 0,
    totalPaisa: 0,
  });

  if (!result.ok) {
    // 409 signals "state conflict" — sold out, unavailable, or bad quantity.
    return Response.json(
      { error: result.error, slug: result.slug },
      { status: 409 },
    );
  }

  return Response.json(
    {
      orderNumber: result.order.orderNumber,
      totalPaisa: result.order.totalPaisa,
    },
    { status: 201 },
  );
}
