import { submitProductReview } from "@/lib/reviews";
import { getProductBySlug } from "@/lib/queries";
import { isValidPkMobile, normalizePkMobile } from "@/lib/format";

/** Resolves a product slug to its database id, or null when unknown. */
async function getProductIdBySlug(slug: string) {
  const product = await getProductBySlug(slug);
  return product?.id ?? null;
}

export const dynamic = "force-dynamic";

type Body = {
  authorName?: string;
  authorMobile?: string;
  rating?: number;
  title?: string;
  body?: string;
};

/** Strips markup/control characters and collapses whitespace. */
function sanitize(value: string, maxLength: number) {
  return value
    .replace(/<[^>]*>/g, "")
    // eslint-disable-next-line no-control-regex
    .replace(/[\u0000-\u001F\u007F]/g, " ")
    .replace(/\s+/g, " ")
    .trim()
    .slice(0, maxLength);
}

export async function POST(
  request: Request,
  { params }: { params: Promise<{ slug: string }> },
) {
  const { slug } = await params;

  let payload: Body;
  try {
    payload = (await request.json()) as Body;
  } catch {
    return Response.json({ error: "Invalid request" }, { status: 400 });
  }

  const authorName = sanitize(payload.authorName ?? "", 60);
  const authorMobile = normalizePkMobile(payload.authorMobile ?? "");
  const body = sanitize(payload.body ?? "", 900);
  const title = sanitize(payload.title ?? "", 90);
  const rating = Math.round(Number(payload.rating));

  const errors: string[] = [];
  if (authorName.length < 2) errors.push("your name");
  if (!isValidPkMobile(authorMobile)) errors.push("a valid Pakistani mobile number");
  if (body.length < 10) errors.push("a review of at least 10 characters");
  if (!Number.isFinite(rating) || rating < 1 || rating > 5) {
    errors.push("a rating between 1 and 5 stars");
  }

  if (errors.length > 0) {
    return Response.json(
      { error: `Please provide ${errors.join(", ")}.` },
      { status: 400 },
    );
  }

  const productId = await getProductIdBySlug(slug);
  if (!productId) {
    return Response.json({ error: "Product not found" }, { status: 404 });
  }

  const created = await submitProductReview({
    productId,
    authorName,
    authorMobile,
    rating,
    title,
    body,
  });

  if (!created) {
    return Response.json({ error: "Product not found" }, { status: 404 });
  }

  // Reviews are held for moderation, so we return 202 Accepted.
  return Response.json({ ok: true, pending: true }, { status: 202 });
}
