import { eq } from "drizzle-orm";
import { db } from "@/db";
import { images } from "@/db/schema";

export const dynamic = "force-dynamic";

/**
 * Serves a stored image straight from the database.
 * Works on every host because it does not depend on the filesystem.
 */
export async function GET(
  _request: Request,
  { params }: { params: Promise<{ filename: string }> },
) {
  const { filename } = await params;

  if (
    !/^[a-z0-9-]+\.(jpg|jpeg|png|webp|avif|gif|bmp|heic|heif)$/i.test(filename)
  ) {
    return new Response("Not found", { status: 404 });
  }

  const rows = await db
    .select({ mimeType: images.mimeType, data: images.data })
    .from(images)
    .where(eq(images.filename, filename))
    .limit(1);

  const row = rows[0];
  if (!row) {
    return new Response("Not found", { status: 404 });
  }

  const bytes = Buffer.from(row.data, "base64");

  return new Response(new Uint8Array(bytes), {
    status: 200,
    headers: {
      "Content-Type": row.mimeType,
      "Content-Length": String(bytes.byteLength),
      // Browsers should revalidate but can cache, keeping pages fast.
      "Cache-Control": "public, max-age=3600, must-revalidate",
    },
  });
}
