import { seedDatabase } from "@/db/seed";
import { getAdminSession } from "@/lib/admin-auth";

export const dynamic = "force-dynamic";

/**
 * Seeds or reseeds the catalogue.
 *
 * This endpoint can DESTROY the catalogue (`?force=1` truncates products,
 * collections and reviews), so it must never be callable by strangers.
 * Access now requires a signed-in admin session. A SEED_SECRET query token is
 * still accepted for one-off use from a terminal or CI job.
 */
async function authorize(request: Request) {
  const session = await getAdminSession();
  if (session) return true;

  const secret = process.env.SEED_SECRET?.trim();
  if (!secret) return false; // No secret configured -> admin session required.

  const url = new URL(request.url);
  const provided =
    request.headers.get("x-seed-secret") ?? url.searchParams.get("token") ?? "";
  return provided === secret;
}

export async function POST(request: Request) {
  if (!(await authorize(request))) {
    return Response.json(
      { ok: false, error: "Unauthorized. Sign in to the admin panel first." },
      { status: 401 },
    );
  }

  const url = new URL(request.url);
  const force = url.searchParams.get("force") === "1";

  try {
    const result = await seedDatabase({ force });
    return Response.json({ ok: true, ...result });
  } catch (error) {
    console.error("seed failed", error);
    return Response.json({ ok: false, error: "Seed failed" }, { status: 500 });
  }
}

export async function GET(request: Request) {
  return POST(request);
}
