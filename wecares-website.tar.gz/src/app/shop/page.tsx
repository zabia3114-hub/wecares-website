import type { Metadata } from "next";
import Link from "next/link";
import { Suspense } from "react";
import { ProductCard } from "@/components/ProductCard";
import { Reveal } from "@/components/ui/Reveal";
import { ShopControls } from "@/components/shop/ShopControls";
import { getCollections, getFacets, getProducts, type SortKey } from "@/lib/queries";
import { formatPkr } from "@/lib/format";
import { WhatsAppButton } from "@/components/WhatsAppButton";
import { HELLO_MESSAGE, WHATSAPP_NUMBER_DISPLAY } from "@/lib/whatsapp";

export const dynamic = "force-dynamic";

export const metadata: Metadata = {
  title: "All Products",
  description:
    "Browse the We Cares herbal wellness range: traditional majoon and herbal oils, delivered across Pakistan with cash on delivery.",
};

type SearchParams = Promise<Record<string, string | string[] | undefined>>;

function single(value: string | string[] | undefined) {
  return Array.isArray(value) ? value[0] : value;
}

export default async function ShopPage({
  searchParams,
}: {
  searchParams: SearchParams;
}) {
  const params = await searchParams;
  const collection = single(params.collection);
  const category = single(params.category);
  const search = single(params.q);
  const sort = (single(params.sort) ?? "featured") as SortKey;
  const maxParam = Number(single(params.max));
  const maxPriceFilter =
    Number.isFinite(maxParam) && maxParam > 0 ? maxParam : undefined;

  const [products, facets, collections] = await Promise.all([
    getProducts({ collection, category, search, sort, maxPrice: maxPriceFilter }),
    getFacets(),
    getCollections(),
  ]);

  return (
    <div>
      <section className="panel-dark py-12 text-cream lg:py-16">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <nav className="flex items-center gap-2 text-xs text-cream/50">
            <Link href="/" className="transition hover:text-gold">
              Home
            </Link>
            <span aria-hidden>/</span>
            <span className="font-semibold text-gold-soft">Products</span>
          </nav>
          <h1 className="mt-5 font-display text-4xl sm:text-5xl">
            All Products
          </h1>
          <p className="mt-4 max-w-2xl text-[15px] leading-relaxed text-cream/70 sm:text-base">
            Every We Cares product, with honest pricing in Pakistani Rupees.
            Free standard delivery on orders over {formatPkr(500000)}.
          </p>
        </div>
      </section>

      <div className="mx-auto max-w-7xl px-4 py-10 sm:px-6 lg:px-8">
        <div className="grid gap-8 lg:grid-cols-[260px_1fr]">
          <Suspense fallback={<div className="hidden lg:block" />}>
            <ShopControls
              categories={facets.categories}
              collections={collections.map((item) => ({
                slug: item.slug,
                name: item.name,
                productCount: item.productCount,
              }))}
              maxPrice={facets.maxPrice}
              total={products.length}
            />
          </Suspense>

          <div>
            {products.length === 0 ? (
              <div className="rounded-[1.5rem] border border-dashed border-sand bg-white px-6 py-16 text-center">
                <h2 className="font-display text-2xl text-forest-900">
                  No products match those filters
                </h2>
                <p className="mx-auto mt-2 max-w-sm text-sm text-ink/60">
                  Try clearing a filter, or message us on WhatsApp and we will
                  help you choose.
                </p>
                <Link
                  href="/shop"
                  className="mt-6 inline-flex rounded-full bg-forest-800 px-6 py-3.5 text-sm font-semibold text-cream transition hover:bg-forest-700"
                >
                  Reset filters
                </Link>
              </div>
            ) : (
              <div
                key={products.map((p) => p.id).join("-")}
                className="grid gap-6 sm:grid-cols-2 xl:grid-cols-3"
              >
                {products.map((product, index) => (
                  <Reveal
                    key={product.id}
                    delay={Math.min(index, 6) * 70}
                    className="animate-fade-up"
                  >
                    <ProductCard product={product} priority={index < 3} />
                  </Reveal>
                ))}
              </div>
            )}

            <Reveal className="mt-12 rounded-[1.5rem] border border-gold/25 bg-cream-deep p-6 text-center sm:p-8">
              <h2 className="font-display text-2xl text-forest-900 sm:text-3xl">
                Need help choosing?
              </h2>
              <p className="mx-auto mt-3 max-w-lg text-sm leading-relaxed text-ink/70">
                Message us on WhatsApp at {WHATSAPP_NUMBER_DISPLAY} and we will
                help you select the right product and confirm delivery to your
                city.
              </p>
              <WhatsAppButton
                message={HELLO_MESSAGE}
                className="mt-6"
                size="lg"
              />
            </Reveal>
          </div>
        </div>
      </div>
    </div>
  );
}
