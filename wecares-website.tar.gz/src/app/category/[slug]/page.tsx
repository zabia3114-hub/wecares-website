import type { Metadata } from "next";
import Image from "next/image";
import Link from "next/link";
import { notFound } from "next/navigation";
import { ProductCard } from "@/components/ProductCard";
import { Reveal } from "@/components/ui/Reveal";
import { WhatsAppButton } from "@/components/WhatsAppButton";
import { getProducts } from "@/lib/queries";
import { getActiveCategories, ensureDefaultCategories } from "@/lib/categories";
import { HELLO_MESSAGE } from "@/lib/whatsapp";

export const dynamic = "force-dynamic";

type Params = Promise<{ slug: string }>;

async function findCategory(slug: string) {
  await ensureDefaultCategories();
  const list = await getActiveCategories();
  return list.find((category) => category.slug === slug) ?? null;
}

export async function generateMetadata({
  params,
}: {
  params: Params;
}): Promise<Metadata> {
  const { slug } = await params;
  const category = await findCategory(slug);
  if (!category) notFound();
  return {
    title: category.name,
    description: category.description || `Shop ${category.name} products at We Cares.`,
  };
}

export default async function CategoryPage({ params }: { params: Params }) {
  const { slug } = await params;
  const category = await findCategory(slug);
  if (!category) notFound();

  // Products assigned to this category (or, for legacy rows, matching its slug).
  const [assigned, allCategories] = await Promise.all([
    getProducts({ categoryId: category.id, categorySlug: category.slug }),
    getActiveCategories(),
  ]);

  return (
    <div>
      <section className="relative overflow-hidden border-b border-sand">
        <div
          className="absolute inset-0"
          style={{
            background:
              "linear-gradient(to right, var(--theme-header-from), var(--theme-header-via), var(--theme-header-to))",
          }}
        />
        <div className="relative mx-auto max-w-7xl px-4 py-14 text-cream sm:px-6 lg:px-8 lg:py-20">
          <nav className="flex flex-wrap items-center gap-2 text-xs text-cream/50">
            <Link href="/" className="transition hover:text-gold">
              Home
            </Link>
            <span aria-hidden>/</span>
            <span className="font-semibold text-gold-soft">{category.name}</span>
          </nav>
          <h1 className="mt-5 font-display text-4xl sm:text-5xl lg:text-6xl">
            {category.name}
          </h1>
          {category.description ? (
            <p className="mt-3 font-display text-lg text-gold sm:text-xl">
              {category.description}
            </p>
          ) : null}
          <p className="mt-4 text-[15px] text-cream/70">
            {assigned.length} {assigned.length === 1 ? "product" : "products"} in
            this category
          </p>
        </div>
      </section>

      <div className="mx-auto max-w-7xl px-4 py-10 sm:px-6 lg:px-8">
        <div className="mb-7 flex flex-wrap gap-2">
          {allCategories.map((item) => (
            <Link
              key={item.id}
              href={`/category/${item.slug}`}
              className={
                item.id === category.id
                  ? "rounded-full bg-forest-800 px-4 py-2 text-xs font-semibold text-cream"
                  : "rounded-full border border-sand bg-white px-4 py-2 text-xs font-semibold text-ink/65 transition hover:border-gold hover:text-moss"
              }
            >
              {item.name}
            </Link>
          ))}
        </div>

        {category.image ? (
          <div className="mb-8 aspect-[16/6] overflow-hidden rounded-[1.75rem] border border-sand">
            <Image
              src={category.image}
              alt={category.name}
              width={1600}
              height={600}
              className="h-full w-full object-cover"
              unoptimized
            />
          </div>
        ) : null}

        {assigned.length === 0 ? (
          <div className="rounded-[1.5rem] border border-dashed border-sand bg-white px-6 py-16 text-center">
            <h2 className="font-display text-2xl text-forest-900">
              No products in this category yet
            </h2>
            <p className="mx-auto mt-2 max-w-md text-sm text-ink/55">
              Products assigned to {category.name} in the admin panel will appear
              here automatically.
            </p>
            <Link
              href="/shop"
              className="mt-6 inline-flex rounded-full bg-forest-800 px-6 py-3.5 text-sm font-semibold text-cream transition hover:bg-forest-700"
            >
              Browse all products
            </Link>
          </div>
        ) : (
          <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
            {assigned.map((product, index) => (
              <Reveal key={product.id} delay={index * 70}>
                <ProductCard product={product} priority={index < 3} />
              </Reveal>
            ))}
          </div>
        )}

        <Reveal className="mt-12 rounded-[1.5rem] border border-gold/25 bg-cream-deep p-6 text-center sm:p-8">
          <h2 className="font-display text-2xl text-forest-900 sm:text-3xl">
            Need help choosing?
          </h2>
          <WhatsAppButton message={HELLO_MESSAGE} className="mt-6" size="lg" />
        </Reveal>
      </div>
    </div>
  );
}
