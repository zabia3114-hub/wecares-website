import type { Config } from "drizzle-kit";

/**
 * Drizzle config for production databases.
 * Reads DATABASE_URL from the environment so credentials are never committed.
 *
 * Usage:
 *   DATABASE_URL="postgres://..." npx drizzle-kit push --config=drizzle.prod.config.ts
 */
export default {
  dialect: "postgresql",
  schema: "./src/db/schema.ts",
  out: "./drizzle",
  dbCredentials: {
    url: process.env.DATABASE_URL ?? "",
  },
} satisfies Config;
